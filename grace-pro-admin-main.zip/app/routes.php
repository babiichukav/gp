<?php

// Routes

$app->get('/', '\App\Controllers\DashboardController:getSignIn')->add(new \App\Middleware\RedirectIfAuthenticated);
$app->post('/', '\App\Controllers\DashboardController:postSignIn')->add(new \App\Middleware\RedirectIfAuthenticated);

$app->group('/dashboard', function () {
	
	$this->get('/auth/', '\App\Controllers\AuthController:getIndex');
	$this->get('/logout/', '\App\Controllers\DashboardController:getLogout');
	$this->get('/download/{dir}/{file}/', '\App\Controllers\DashboardController:getDownload');
	
    $this->group('/products', function () {
        $this->get('/', '\App\Controllers\ProductsController:getIndex');
        $this->get('/add/', '\App\Controllers\ProductsController:getAdd');
        $this->post('/add/', '\App\Controllers\ProductsController:postAdd');

        $this->group('/{brand}', function () {

            $this->get('/', '\App\Controllers\BrandController:getIndex');
			$this->get('/add/', '\App\Controllers\BrandController:getAdd');
			$this->post('/add/', '\App\Controllers\BrandController:postAdd');
			
/*
				$this->group('/params', function () {
					$this->get('/edit/', '\App\Controllers\ParamsController:getEdit');
					$this->post('/edit/', '\App\Controllers\ParamsController:postEdit');
					$this->get('/delete/', '\App\Controllers\ParamsController:getDelete');
				});
*/		
				    $this->group('/procedures', function () {
        $this->get('/', '\App\Controllers\ProceduresController:getIndex');
        $this->get('/add/', '\App\Controllers\ProceduresController:getAdd');
        $this->post('/add/', '\App\Controllers\ProceduresController:postAdd');

        $this->group('/{news_id}', function () {
            $this->get('/', '\App\Controllers\ProceduresController:getDetails');
            $this->get('/edit/', '\App\Controllers\ProceduresController:getEdit');
            $this->post('/edit/', '\App\Controllers\ProceduresController:postEdit');
            $this->get('/delete/', '\App\Controllers\ProceduresController:getDelete');
        });
    });
    
				
				$this->group('/buyTogether', function () {
					$this->get('/', '\App\Controllers\BuyTogetherController:getIndex');
					$this->get('/edit/', '\App\Controllers\BuyTogetherController:getEdit');
					$this->post('/edit/', '\App\Controllers\BuyTogetherController:postEdit');
					$this->group('/{id}', function () {
					$this->get('/delete/', '\App\Controllers\BuyTogetherController:getDelete');
					});
				});
            
            	$this->group('/{id}', function () {
	            	$this->get('/', '\App\Controllers\BrandController:getDetails');
					$this->get('/edit/', '\App\Controllers\BrandController:getEdit');
					$this->post('/edit/', '\App\Controllers\BrandController:postEdit');
					$this->get('/delete/', '\App\Controllers\BrandController:getDelete');
                    
                    $this->group('/istop', function () {
                        
                        
                        $this->group('/{br}', function () {
                        $this->get('/accept/', '\App\Controllers\BrandController:getAccept');
                        $this->get('/reject/', '\App\Controllers\BrandController:getReject');
                        });
                    });
					
					
					$this->group('/params', function () {
					$this->get('/edit/', '\App\Controllers\ParamsController:getEdit');
					$this->post('/edit/', '\App\Controllers\ParamsController:postEdit');
					
					$this->group('/{param_id}', function () {
					$this->get('/delete/', '\App\Controllers\ParamsController:getDelete');
					$this->get('/edit/', '\App\Controllers\ParamsController:getEdit');
					$this->post('/edit/', '\App\Controllers\ParamsController:post');
					});
            	});   

            	});

            	
         	
        });        
        
    });
    
    

    
    $this->group('/news', function () {
        $this->get('/', '\App\Controllers\NewsController:getIndex');
        $this->get('/add/', '\App\Controllers\NewsController:getAdd');
        $this->post('/add/', '\App\Controllers\NewsController:postAdd');

        $this->group('/{news_id}', function () {
            $this->get('/', '\App\Controllers\NewsController:getDetails');
            $this->get('/edit/', '\App\Controllers\NewsController:getEdit');
            $this->post('/edit/', '\App\Controllers\NewsController:postEdit');
            $this->get('/delete/', '\App\Controllers\NewsController:getDelete');
        });
    });
    
        $this->group('/tariffs', function () {
        $this->get('/', '\App\Controllers\TariffsController:getIndex');
        $this->get('/add/', '\App\Controllers\TariffsController:getAdd');
        $this->post('/add/', '\App\Controllers\TariffsController:postAdd');

        $this->group('/{tariff_id}', function () {
            $this->get('/', '\App\Controllers\TariffsController:getDetails');
            $this->get('/edit/', '\App\Controllers\TariffsController:getEdit');
            $this->post('/edit/', '\App\Controllers\TariffsController:postEdit');
            $this->get('/delete/', '\App\Controllers\TariffsController:getDelete');
        });
    });

    
    $this->group('/users', function () {
        $this->get('/', '\App\Controllers\UsersController:getIndex');
        $this->get('/add/', '\App\Controllers\UsersController:getAdd');
        $this->post('/add/', '\App\Controllers\UsersController:postAdd');

        $this->group('/{id}', function () {
            $this->get('/', '\App\Controllers\UsersController:getDetails');
            $this->get('/edit/', '\App\Controllers\UsersController:getEdit');
            $this->post('/edit/', '\App\Controllers\UsersController:postEdit');
            $this->get('/delete/', '\App\Controllers\UsersController:getDelete');
            
            
            $this->group('/subusers', function () {
					$this->get('/', '\App\Controllers\SubusersController:getIndex');
					$this->get('/edit/', '\App\Controllers\SubusersController:getEdit');
					$this->post('/edit/', '\App\Controllers\SubusersController:postEdit');
					$this->group('/{user_id}', function () {
					$this->get('/delete/', '\App\Controllers\SubusersController:getDelete');
					});
				});
            
            $this->group('/np', function () {
					$this->get('/edit/', '\App\Controllers\NPController:getEdit');
					$this->post('/edit/', '\App\Controllers\NPController:postEdit');
					
					$this->group('/{np_id}', function () {
					$this->get('/delete/', '\App\Controllers\NPController:getDelete');
					});
            });
            
            $this->group('/addresses', function () {
					$this->get('/edit/', '\App\Controllers\AddressesController:getEdit');
					$this->post('/edit/', '\App\Controllers\AddressesController:postEdit');
					
					$this->group('/{addresses_id}', function () {
					$this->get('/delete/', '\App\Controllers\AddressesController:getDelete');
					});
            });
        });
    });
    
    
    $this->group('/managers', function () {
        $this->get('/', '\App\Controllers\ManagersController:getIndex');
        $this->get('/add/', '\App\Controllers\ManagersController:getAdd');
        $this->post('/add/', '\App\Controllers\ManagersController:postAdd');

        $this->group('/{id}', function () {
            $this->get('/', '\App\Controllers\ManagersController:getDetails');
            $this->get('/edit/', '\App\Controllers\ManagersController:getEdit');
            $this->post('/edit/', '\App\Controllers\ManagersController:postEdit');
            $this->get('/delete/', '\App\Controllers\ManagersController:getDelete');
            
            
/*
            $this->group('/np', function () {
					$this->get('/edit/', '\App\Controllers\NPController:getEdit');
					$this->post('/edit/', '\App\Controllers\NPController:postEdit');
					
					$this->group('/{np_id}', function () {
					$this->get('/delete/', '\App\Controllers\NPController:getDelete');
					});
            });
            
            $this->group('/addresses', function () {
					$this->get('/edit/', '\App\Controllers\AddressesController:getEdit');
					$this->post('/edit/', '\App\Controllers\AddressesController:postEdit');
					
					$this->group('/{addresses_id}', function () {
					$this->get('/delete/', '\App\Controllers\AddressesController:getDelete');
					});
            });
*/
        });
    });
    
    
    
    $this->group('/history', function () {
        $this->get('/', '\App\Controllers\HistoryController:getIndex');

        $this->group('/{userID}/{id}', function () {
            $this->get('/', '\App\Controllers\HistoryController:getDetails');
        });
    });

    
   
		
	
})->add(new \App\Middleware\RedirectIfNotAuthenticated);