<?php
use App\App;

if (!function_exists('app')) {
    /**
     * Get application container instance. Warning: Not the App instance itself.
     *
     * @param  string  $make
     * @param  array   $parameters
     * @return mixed | \Psr\Container\ContainerInterface
     */
    function app($key = null)
    {
        $container = App::getInstance()->getContainer();
        if (!is_null($key)) {
            return $container->get($key);
        }
        return $container;
    }
}

if (!function_exists('redirect')) {
    /**
     *
     *
     * @param  string  $to
     * @param  int     $status
     * @param  array   $headers
     * @return \Psr\Http\Message\ResponseInterface
     */
    function redirect($to = '/', int $status = 302, array $headers = [])
    {
        if (substr($to, -1) !== '/') {
            $to .= '/';
        }

        $response = app('response')->withRedirect($to, $status);
        foreach ($headers as $header => $value) {
            $response = $response->withHeader($header, $value);
        }
        return $response;
    }
}

if (!function_exists('back')) {
    /**
     * Redirect to previous location. Based on referer header or session value (url.previous)
     *
     *
     * @param  int  $status
     * @param  array  $headers
     * @return \Psr\Http\Message\ResponseInterface
     */
    function back(int $status = 302, array $headers = [])
    {
        $referer = app('request')->getHeader('referer')[0] ?? null;
        $uri = '/';
        if ($referer) {
            $uri = $referer;
        }
        $response = app('response')->withRedirect($uri, $status);
        foreach ($headers as $header => $value) {
            $response = $response->withHeader($header, $value);
        }
        return $response;
    }
}

if (!function_exists('pathclass')) {
    function pathclass($path, $output = null)
    {
        $request_path = app('request')->getUri()->getPath();
        $path = str_replace("*/", "(.*)", $path);
        if (preg_match('#^' . $path . '$#i', $request_path)) {
            return $output ? $output : true;
        } else {
            return false;
        }
    }
}

function parse_num($val)
{
    return (float) filter_var($val, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
}

function slugify($name)
{
    return preg_replace('/\s+/', '_', $name);
}

function unslugify($slug)
{
    return str_replace('_', ' ', $slug);
}
