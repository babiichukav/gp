<?php

namespace App\Models;

class Managers extends Model
{

    protected static $_path = '/Managers';

}
