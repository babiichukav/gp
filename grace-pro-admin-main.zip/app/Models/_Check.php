<?php

namespace App\Models;

class Check extends Model
{
    
    protected static $_path = '/Checks';



}
