<?php

namespace App\Models;

class Contract extends Model
{
    
    protected static $_path = '/Contracts';



}
