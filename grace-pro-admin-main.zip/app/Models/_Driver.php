<?php

namespace App\Models;

class Driver extends Model
{
    
    protected static $_path = '/Drivers';



}
