<?php

namespace App\Models;

class News extends Model
{

    protected static $_path = '/News';

}
