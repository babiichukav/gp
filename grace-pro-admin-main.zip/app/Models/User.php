<?php

namespace App\Models;

class User extends Model
{

    protected static $_path = '/Users';

}
