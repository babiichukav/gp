<?php

namespace App\Models;

class Brae extends Model
{

    protected static $_path = '/Products/Brae';

}
