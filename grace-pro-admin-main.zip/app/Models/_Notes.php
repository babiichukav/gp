<?php

namespace App\Models;

class Notes extends Model
{

    protected static $_path = '/Notes';

}