<?php

namespace App\Models;

class Truck extends Model
{

    protected static $_path = '/Trucks';

}
