<?php

namespace App\Models;

class Transactions extends Model
{

    protected static $_path = '/Transactions';

}
