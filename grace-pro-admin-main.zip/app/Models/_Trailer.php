<?php

namespace App\Models;

class Trailer extends Model
{

    protected static $_path = '/Trailers';

}
