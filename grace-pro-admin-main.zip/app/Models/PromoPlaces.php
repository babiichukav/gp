<?php

namespace App\Models;

class PromoPlaces extends Model
{

    protected static $_path = '/PromoPlaces';

}
