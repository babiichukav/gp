<?php

namespace App\Models;

class Procedures extends Model
{

    protected static $_path = '/Procedures';

}
