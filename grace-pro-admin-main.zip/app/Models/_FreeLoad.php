<?php

namespace App\Models;

class FreeLoad extends Model
{

    protected static $_path = '/FreeLoads';

}
