<?php
// DIC configuration

$container = $app->getContainer();

// Register provider
$container['flash'] = function () {
    return new \Slim\Flash\Messages();
};

$container['firebase'] = function ($c) {
    $settings = $c->get('settings')['firebase'];
    $service_account = ($_SERVER['SERVER_NAME'] == 'thudcorp.local') ? $settings['service_accounts']['local'] : $settings['service_accounts']['production'];
    $serviceAccount = \Kreait\Firebase\ServiceAccount::fromJsonFile($service_account);
    $firebase = (new \Kreait\Firebase\Factory)
        ->withServiceAccount($serviceAccount)
        ->create();
    return $firebase;
};

// view renderer
$container['view'] = function ($c) {
    $settings = $c->get('settings')['view'];
    $engine = new League\Plates\Engine($settings['template_path'], 'view.php');
    //if last arg to be true nginx must be configured
    $engine->loadExtension(new \League\Plates\Extension\Asset($_SERVER['DOCUMENT_ROOT'] . '/', false));
    return $engine;
};

// monolog
$container['logger'] = function ($c) {
    $settings = $c->get('settings')['logger'];
    $logger = new Monolog\Logger($settings['name']);
    $logger->pushProcessor(new Monolog\Processor\UidProcessor());
    $logger->pushHandler(new Monolog\Handler\StreamHandler($settings['path'], $settings['level']));
    return $logger;
};

$container['validator'] = function ($c) {
    return new \App\Support\Validation\Validator($c['flash']);
};

$container['notFoundHandler'] = function ($c) {
    return function ($request, $response) use ($c) {
        $controller = new \App\Controllers\DashboardController($c);
        return $controller->getPageNotFound($request, $response);
    };
};

$container['notAllowedHandler'] = function ($c) {
    return function ($request, $response) use ($c) {
        $controller = new \App\Controllers\DashboardController($c);
        return $controller->getPageNotFound($request, $response);
    };
};

$container['errorHandler'] = function ($c) {
    return function ($request, $response, $exception) {
        throw $exception;
    };
};

$container['phpErrorHandler'] = function ($c) {
    return function ($request, $response, $exception) {
        throw $exception;
    };
};
