<?php
namespace App\Controllers;

class AuthController extends Controller
{
    
    public function getIndex($request, $response)
    {

        return $this->render('auth/index');
        
    }

}
