<?php

namespace App\Controllers;

use App\Models\Contract;

class ContractsController extends Controller
{

    public function getIndex($request, $response)
    {
        $contracts = Contract::all();

        return $this->render('contracts/index', compact('contracts'));
    }

    public function getAdd($request, $response)
    {
        return $this->render('contracts/update');
    }

    public function postAdd($request, $response)
    {
        return $this->updateContractDetails($request);
    }

    public function getEdit($request, $response, $args)
    {
        $contractKey = unslugify($args['contract']);

        $contract = Contract::find($contractKey);

        if (empty($contract)) {
            return redirect("/dashboard/contracts");
        }

        return $this->render('contracts/update', compact('contract'));
    }

    public function postEdit($request, $response, $args)
    {
        return $this->updateContractDetails($request, true);
    }

    public function getDelete($request, $response, $args)
    {
        $contractKey = unslugify($args['contract']);

        Contract::remove($contractKey);

        $this->flash->addMessage('form_messages', ["Contract has been deleted."]);

        return redirect("/dashboard/contracts");
    }

    private function updateContractDetails($request, $edit = false)
    {
        $validator = $this->validate($request, [
            'contract.Company' => 'required',
        ]);

        if ($validator->failed()) {
            return back();
        }

        $contract = $request->getParam('contract');

        $contractCompany = $contract['Company'];
        $contractNumber = $contract['ContractNumber'];


        if (is_uploaded_file($_FILES['contract']['tmp_name']['PDF'])) {
            $filesystem = $this->storage->getFilesystem();
            $stream = fopen($_FILES['contract']['tmp_name']['PDF'], 'r+');
            $filename = md5(time()) . ".pdf";
            $filesystem->writeStream(
                'Contracts/' . $filename,
                $stream
            );
            fclose($stream);
            $contract['PDF'] = $filename;
        }

        if ($edit) {

            try {
                Contract::update($contractCompany, $contract);
            } catch (\Throwable $e) {
                $this->flash->addMessage('form_errors', ["Something went wrong. " . $e->getMessage()]);
                return back();
            }

        } else {

            try {
                Contract::create($contractCompany, $contract);
            } catch (\Throwable $e) {
                $this->flash->addMessage('form_errors', ["Something went wrong. " . $e->getMessage()]);
                return back();
            }

        }

        return redirect("/dashboard/contracts");

    }

}
