<?php

namespace App\Controllers;

use App\Models\Check;
use Dompdf\Dompdf;

class ChecksController extends Controller
{

    public function getIndex($request, $response)
    {
        $checks = Check::all();

        if (!empty($checks)) {
            foreach ($checks as $id => &$check) {
                $total = 0;
                if (!empty($check["Checks"])) {
                    foreach ($check["Checks"] as $id => $c) {
                        $total += $c["Total"];
                    }

                }

                $check["Total"] = $total;
            }
        }

        return $this->render('checks/index', compact('checks'));
    }

    public function getDetails($request, $response, $args)
    {
        $id = $args['id'];

        $check = Check::find($id);

        if (empty($check)) {
            return redirect("/dashboard/checks");
        }

        $total = 0;

        if (!empty($check["Checks"])) {

            foreach ($check["Checks"] as $id => $c) {
                $total += $c["Total"];
            }

            $check["Checks"] = array_reverse($check["Checks"]);

        }

        return $this->render('checks/details', compact('check', 'total'));
    }

    public function getAdd($request, $response)
    {
        return $this->render('checks/update');
    }

    public function postAdd($request, $response)
    {
        return $this->updateCheckDetails($request);
    }

    public function getDelete($request, $response, $args)
    {
        $id = $args['id'];

        Check::remove($id);

        $this->flash->addMessage('form_messages', ["Has been deleted."]);

        return redirect("/dashboard/checks");
    }

    private function updateCheckDetails($request, $edit = false)
    {
        $validator = $this->validate($request, [
            'check.Name' => 'required',
        ]);

        if ($validator->failed()) {
            return back();
        }

        $check = $request->getParam('check');

        $check["date_created"] = date("m/d/Y");

        $check["Checks"] = [];

        try {
            Check::create(md5($check["Name"]), $check);
        } catch (\Throwable $e) {
            $this->flash->addMessage('form_errors', ["Something went wrong. " . $e->getMessage()]);
            return back();
        }

        return redirect("/dashboard/checks/");

    }

    public function getCheckAdd($request, $response, $args)
    {

        $id = $args['id'];

        $check = Check::find($id);

        $check_num = 7000;

        if (is_file("check_num.txt")) {
            $check_num = @file_get_contents("check_num.txt");
        }

        if (empty($check)) {
            return redirect("/dashboard/checks");
        }

        $name = $check["Name"];

        return $this->render('checks/check_add', compact("name", "check_num"));
    }

    public function getCheckDelete($request, $response, $args)
    {
        $id = $args['id'];

        $check_id = $args['check_id'];

        $ref = $this->db->getReference('Checks/' . $id . '/Checks/' . $check_id);
        $ref->set(null);

        return redirect("/dashboard/checks/{$id}");
    }

    public function getDownload($request, $response, $args)
    {

        $path       = "Checks/{$args['id']}/" . $args['check_id'] . ".pdf";
        $filesystem = $this->storage->getFilesystem();
        if ($filesystem->has($path)) {
            $filename = isset($_GET['filename']) ? $_GET['filename'] : "doc.pdf";
            $contents = $filesystem->readStream($path);
            $stream   = new \Slim\Http\Stream($contents);
            return $response->withHeader('Content-Type', 'application/force-download')
                ->withHeader('Content-Type', 'application/octet-stream')
                ->withHeader('Content-Type', 'application/download')
                ->withHeader('Content-Description', 'File Transfer')
                ->withHeader('Content-Transfer-Encoding', 'binary')
                ->withHeader('Content-Disposition', 'attachment; filename="' . basename($filename) . '"')
                ->withHeader('Expires', '0')
                ->withHeader('Cache-Control', 'must-revalidate, post-check=0, pre-check=0')
                ->withHeader('Pragma', 'public')
                ->withBody($stream);
        } else {
            die("File not found");
        }
    }

    public function postCheckAdd($request, $response, $args)
    {

        $id = $args['id'];

        $check = Check::find($id);

        if (empty($check)) {
            return redirect("/dashboard/checks");
        }

        $name = $check["Name"];

        $check = $request->getParam('check');

        $check_only = true;

        $f                   = new \NumberFormatter("en", \NumberFormatter::SPELLOUT);
        $value               = floatval(preg_replace('/[^\d\.]+/', '', $check['total']));
        $check['total_text'] = $f->format($value);

        $im = imagecreatetruecolor(900, 60);
        $white = imagecolorallocate($im, 255, 255, 255);
        $black = imagecolorallocate($im, 0, 0, 0);
        imagefilledrectangle($im, 0, 0, 900, 59, $white);

        // The text to draw
        $text = "c00{$check['num']} a123000220a 153666656852c";
        // Replace path by your own font path
        $font = __DIR__ . '/../../public/fonts/micrenc.ttf';

        // Add the text
        imagettftext($im, 40, 0, 20, 40, $black, $font, $text);

        $check_font_image = "test.png";

        imagepng($im, __DIR__ . "/../../public/img/temp/" . $check_font_image, 0);
        imagedestroy($im);

        $print_check = true;

        $html = $this->render('check/template', compact('check', 'check_only', 'check_font_image', 'print_check'));

        $dompdf = new Dompdf();
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        $dompdf->set_option('defaultMediaType', 'all');
        $dompdf->set_option('isFontSubsettingEnabled', true);
        $dompdf->render();

        if (is_file("check_num.txt")) {
            $check_num = @file_get_contents("check_num.txt");
            file_put_contents("check_num.txt", ++$check_num);
        } else {
            file_put_contents("check_num.txt", 7000);
        }

        $filename = md5(time()) . ".pdf";

        $output = $dompdf->output();

        $filesystem = $this->storage->getFilesystem();
        $filesystem->put(
            "Checks/{$id}/" . $filename,
            $output
        );

        // $dompdf->stream($filename, array("Attachment" => false));
        // exit(0);

        $ref = $this->db->getReference('Checks/' . $id . '/Checks/' . str_replace(".pdf", "", $filename));
        $ref->set([
            "Total"        => $value,
            "date_created" => date("m/d/Y"),
            "CheckNum"     => $check["num"],
            "Notes"        => $check["notes"]
        ]);

        return redirect("/dashboard/checks/{$id}/");

    }

}
