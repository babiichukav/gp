<?php

namespace App\Controllers;

use App\Models\Model;


class ArchiveController extends Controller
{
    public function getIndex($request, $response)
    {
        $ref = $this->db->getReference('/Archive');
        $years = [];
        if($ref->getSnapshot()->exists()){
            $years = $ref->getChildKeys();
        }
        arsort($years);
        return $this->render('archive/index', compact('years'));
    }
    public function getSetArchive($request, $response, $args)
    {

        $_SESSION['archive'] = $args['year'];
        return redirect('/dashboard/loads/');

    }
    public function getUnSetArchive($request, $response, $args)
    {

        unset($_SESSION['archive']);
        return redirect('/dashboard/loads/');

    }
}
