<?php

namespace App\Controllers;

use App\Models\History;
use Throwable;

class HistoryController extends Controller
{

    public function getIndex($request, $response)
    {
        $users = History::all();
		
        return $this->render('history/index', compact('users'));

    }
    
    public function getDetails($request, $response, $args)
    {
	    
	    $userID = $args['userID'];
        $id = $args['id'];
		
        $user = $this->db->getReference('History/' . $userID)->getValue();
//         echo '<script type="text/javascript">alert("' . $user[$id] . '")</script>';

        return $this->render('history/details', compact('user', 'id', 'userID'));
    }
    
    public function getDelete($request, $response, $args)
    {
        History::remove($args['id']);

        $this->flash->addMessage('form_messages', ["Юзер был удален"]);

        return redirect("/dashboard/history");
    }
}
