<?php

namespace App\Controllers;

//echo("<script>console.log('PHP: " . $brand . "');</script>");

class SubusersController extends Controller
{

    public function getIndex($request, $response, $args)
    { 
	    $id = $args['id'];
        $subusers = $this->db->getReference('Subusers/' . $id)->getValue() ?? [];

        return $this->render('subusers/index', compact('subusers'));
    }

    public function getDetails($request, $response, $args)
    {
	    $id = $args['id'];        

        return $this->render('subusers/details', compact('id'));
    }


    public function postAdd($request, $response)
    {
	    
        return $this->updateLoadDetails($request);
    }

    public function getEdit($request, $response, $args)
    {

		$id = $args['id'];
		$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < 10; $i++) {
        	$randomString .= $characters[rand(0, $charactersLength - 1)];
    	}
    
	    $randomPass = $randomString;
	    
        return $this->render('subusers/update', compact('id', 'randomPass'));
    }

    public function postEdit($request, $response, $args)
    {
        return $this->updateLoadDetails($request, true, $args);
    }

    public function getDelete($request, $response, $args)
    {

        $brand = $args['brand'];
        $id = $args['id'];

		$ref = $this->db->getReference('Subusers/' . '/' . $id);
        $ref->remove();
        $this->flash->addMessage('form_messages', ["Продукт был удален"]);

		return redirect('/dashboard/products/' . $brand . '/' . 'buyTogether');
                
    }

    private function updateLoadDetails($request, $edit = false, $args)
    {

         
         
		$load = $request->getParam('load');
		

        $validator = $this->validate($load, [
            "id" => "required",
            "name" => "required",
            "EDRPOU" => "required",
            "code" => "required",
            "address" => "required",
        ]);

        if ($validator->failed()) {
            return back();
        }
        
        
		$id = $load['id'];
			 
        
		$loadsRef = $this->db->getReference('Subusers/' . '/' . $id);
            
            
            if (!$loadsRef->getSnapshot()->exists()) {
                $newLoadKey = 0;
            } else {
                $keys = $loadsRef->getChildKeys();
                sort($keys);
                $newLoadKey = end($keys) + 1;
            }

             $load['subuser_id'] = (string) $newLoadKey;
            
            
            
			$ref = $this->db->getReference('/Subusers/' . $id . '/' . $newLoadKey);
            

            $ref->set($load);
			 
        

        return redirect('/dashboard/users/' . $id . '/' . 'subusers');
  

    }

}
