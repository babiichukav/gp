<?php

namespace App\Controllers;
use App\Models\Brae;
use Throwable;
//echo("<script>console.log('PHP: " . $brand . "');</script>");

class BrandController extends Controller
{

    public function getIndex($request, $response, $args)
    { 
	    $brand = $args['brand'];
        $products = $this->db->getReference('Products/' . $brand)->getValue() ?? [];
		
		if ($request->isXhr()) {
			//$test = Brae::all();
			//echo("<script>console.log('PHP: " . $test . "');</script>");

            return $response->withJson($products);
        }else{
            return $this->render('brand/index', compact('products'));
        }
        
    }

    public function getDetails($request, $response, $args)
    {
	    $brand = $args['brand'];
        $id = $args['id'];
		
        $load = $this->db->getReference('Products/' . $brand . '/' . $id)->getValue();
        

        return $this->render('brand/details', compact('load', 'brand'));
    }


    public function postAdd($request, $response)
    {
        return $this->updateLoadDetails($request);
    }

    public function getEdit($request, $response, $args)
    {

        $brand = $args['brand'];
        $id = $args['id'];

        $ref = $this->db->getReference('Products/'  . $brand . '/' . $id);
       
        $load = $ref->getValue();

        if (is_null($load)) {
            return redirect("/dashboard/products/");
        }

        return $this->render('brand/update', compact('load', 'id'));
    }

    public function postEdit($request, $response, $args)
    {
        return $this->updateLoadDetails($request, true, $args);
    }

    public function getDelete($request, $response, $args)
    {

        $brand = $args['brand'];
        $id = $args['id'];

		$ref = $this->db->getReference('Products/' . $brand . '/' . $id);
        $ref->remove();
        $this->flash->addMessage('form_messages', ["Продукт был удален"]);


        return redirect("/dashboard/products/");
                
    }

    private function updateLoadDetails($request, $edit = false, $args)
    {
        $validator = $this->validate($request, [
/*
                 "load.place.category" => "required",
                 "load.place.type" => "required",
*/
                 "load.name" => "required",
         ]);

         if ($validator->failed()) {
             return back();
         }
         
         
		$load = $request->getParam('load');
		$brand = "";
		$load['isTop'] = "0"; 
		if ($load['brand'] == "Dr. Sorbie") {
	            $brand = "DrSorbie";
            } elseif ($load['brand'] == "Brae") { 
	            $brand = "Brae";
            } elseif ($load['brand'] == "Tempting") {
	           	$brand = "Tempting"; 
            } elseif ($load['brand'] == "C этим покупают") {
	            $brand = "BuyTogether"; 
            }
        
        if (is_uploaded_file($_FILES['load']['tmp_name']['imgs']['0'])) {
            $filesystem = $this->storage->getFilesystem();
            $stream     = fopen($_FILES['load']['tmp_name']['imgs']['0'], 'r+');
            $filename   = md5(time()) . "0.png";
            $filesystem->writeStream(
                'Logos/' . $filename,
                $stream
            );
            fclose($stream);
            $load['logo'] = $filename;
            $load['imgs']['0'] = $filename;
        }else {
            $load['imgs']['0'] = null;
         }
        
        if (is_uploaded_file($_FILES['load']['tmp_name']['imgs']['1'])) {
            $filesystem = $this->storage->getFilesystem();
            $stream     = fopen($_FILES['load']['tmp_name']['imgs']['1'], 'r+');
            $filename   = md5(time()) . "1.png";
            $filesystem->writeStream(
                'Logos/' . $filename,
                $stream
            );
            fclose($stream);
            $load['imgs']['1'] = $filename;
        }else {
            $load['imgs']['1'] = null;
         }
        
        if (is_uploaded_file($_FILES['load']['tmp_name']['imgs']['2'])) {
            $filesystem = $this->storage->getFilesystem();
            $stream     = fopen($_FILES['load']['tmp_name']['imgs']['2'], 'r+');
            $filename   = md5(time()) . "2.png";
            $filesystem->writeStream(
                'Logos/' . $filename,
                $stream
            );
            fclose($stream);
            $load['imgs']['2'] = $filename;
        }else {
            $load['imgs']['2'] = null;
         }
        
        if (is_uploaded_file($_FILES['load']['tmp_name']['imgs']['3'])) {
            $filesystem = $this->storage->getFilesystem();
            $stream     = fopen($_FILES['load']['tmp_name']['imgs']['3'], 'r+');
            $filename   = md5(time()) . "3.png";
            $filesystem->writeStream(
                'Logos/' . $filename,
                $stream
            );
            fclose($stream);
            $load['imgs']['3'] = $filename;
        }else {
            $load['imgs']['3'] = null;
         }
        
        

		$load['date'] = date("m.d.y"); 
		 if ($edit) {
			 
		 	
			 $id = $load['id'];
                                    
			 $ref = $this->db->getReference('Products/' . $args['brand'] . '/' . $args['id']);

             $ref->update($load);


			 
			 } else {
        
		$loadsRef = $this->db->getReference('Products/' . '/' . $brand);
            
            
            if (!$loadsRef->getSnapshot()->exists()) {
                $newLoadKey = 0;
            } else {
                $keys = $loadsRef->getChildKeys();
                sort($keys);
                $newLoadKey = end($keys) + 1;
            }

            $load['id'] = (string) $newLoadKey;
            
            
            
			$ref = $this->db->getReference('/Products/' . $brand . '/' . $newLoadKey);
            

            $ref->set($load);
			 }
        

        return redirect('/dashboard/products/' . $brand . '/' . $load['id']);
  

    }
    
    public function getAccept($request, $response, $args)
    {
        
        
        $brand = "";
        if ($args['br'] == "Dr. Sorbie") {
            $brand = "DrSorbie";
        } elseif ($args['br'] == "Brae") { 
            $brand = "Brae";
        } elseif ($args['br'] == "Tempting") {
               $brand = "Tempting"; 
        } elseif ($args['br'] == "C этим покупают") {
            $brand = "BuyTogether"; 
        }
        
        
        $ref = $this->db->getReference('Products/' . $brand . '/' . $args['id']);
        $ref->update(['isTop'=>"1"]);

        
        return redirect('/dashboard/products/' . $brand);
    }
    
    public function getReject($request, $response, $args)
    {
        $brand = "";
        if ($args['br'] == "Dr. Sorbie") {
            $brand = "DrSorbie";
        } elseif ($args['br'] == "Brae") { 
            $brand = "Brae";
        } elseif ($args['br'] == "Tempting") {
               $brand = "Tempting"; 
        } elseif ($args['br'] == "C этим покупают") {
            $brand = "BuyTogether"; 
        }
        
        
        $ref = $this->db->getReference('Products/' . $brand . '/' . $args['id']);
        $ref->update(['isTop'=>"0"]);

        
        return redirect('/dashboard/products/' . $brand);
    }

}
