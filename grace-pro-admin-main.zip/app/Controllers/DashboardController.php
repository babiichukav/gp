<?php

namespace App\Controllers;

use App\Models\Contract;
use App\Models\Driver;
use App\Models\Truck;
use App\Models\User;

class DashboardController extends Controller
{

    public function getSignIn($request, $response)
    {
        return $this->render('signin');
    }

    public function getExport($request, $response)
    {
        $files = [];
        $path  = '../storage/backups';
        if (is_dir($path)) {
            $files = scandir($path);
            $files = array_diff($files, array('.', '..'));
        }
        return $this->render('export', compact('files'));
    }

    public function getExportFile($request, $response, $args)
    {
        $file = '../storage/backups/' . $args['filename'] . ".json";

        if (file_exists($file)) {
            header('Content-Description: File Transfer');
            header('Content-Type: application/octet-stream');
            header('Content-Disposition: attachment; filename="' . basename($file) . '"');
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($file));
            readfile($file);
            exit;
        } else {
            die("File not found");
        }
    }

    public function postExport($request, $response)
    {
        $ref      = $this->db->getReference('/');
        $json     = $ref->getValue();
        $json     = json_encode($json, JSON_PRETTY_PRINT);
        $filename = "export_" . date("d_m_Y_H_i_s") . ".json";
        $dir = '../storage/backups/';

        if(!is_dir($dir)){
            mkdir($dir, 0755, true);
        }


        file_put_contents($dir . $filename, $json);

        //send email

        

        require __DIR__ . '../../../libs/PHPMailer/Exception.php';
        require __DIR__ . '../../../libs/PHPMailer/PHPMailer.php';
        require __DIR__ . '../../../libs/PHPMailer/SMTP.php';

        $mail = new \PHPMailer\PHPMailer\PHPMailer(true);

        try {
            //Server settings
            $mail->SMTPDebug = 0; //\PHPMailer\PHPMailer\SMTP::DEBUG_SERVER; // Enable verbose debug output
            $mail->isSMTP(); // Send using SMTP
            $mail->Host       = 'smtp.gmail.com'; // Set the SMTP server to send through
            $mail->SMTPAuth   = true; // Enable SMTP authentication
            $mail->Username   = 'best9.jovi@gmail.com'; // SMTP username
            $mail->Password   = 'khypvcujjtipqhin'; // SMTP password
            $mail->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS; // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` also accepted
            $mail->Port       = 587; // TCP port to connect to

            //Recipients
            $mail->setFrom('best9.jovi@gmail.com', 'Service');

            $mail->addAddress(EXPORT_BACKUP_EMAIL); // Add a recipient

            // Attachments
            $mail->addAttachment($dir . $filename); // Add attachments

            $mail->Subject = 'Export Backup ' . date("m-d-Y");
            $mail->Body    = 'This email contains fresh copy of export backup in attachment.';

            $mail->send();

        } catch (\PHPMailer\PHPMailer\Exception $e) {
           // echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
        }

        return redirect("/dashboard/export");
    }

    public function getLogout($request, $response)
    {
        unset($_SESSION['user']);
        unset($_SESSION['archive']);
        return redirect('/');
    }

    public function postSignIn($request, $response)
    {

        $validator = $this->validate($request, ["user.username" => "required", "user.password" => "required"],
            ['user.username' => 'User username', 'user.password' => 'User password']);

        if ($validator->failed()) {
            return back();
        }

        $user = $request->getParam('user');


        //if ($user['username'] === 'admin' && $user['password'] === 'admin') {
        if ($user['username'] === 'dodotap' && $user['password'] === 'dodotap') {
            $_SESSION['user'] = 'admin';
            return redirect('/dashboard/products');
        }
        
   

        $user_data = User::find(md5($user['username']));

        if (!empty($user_data) && $user_data['password'] == $user['password']) {
            $_SESSION['user'] = $user_data['username'];
            return redirect('/dashboard/products');
        }

        $this->flash->addMessage("form_errors", ["Wrong username or password"]);
        return back();
    }

    public function getIndex($request, $response)
    {
        $trucks    = Truck::last(10);
        $drivers   = Driver::last(10);
        $contracts = Contract::last(10);

        return $this->render('index', compact('trucks', 'drivers', 'contracts'));
    }

    public function getDownload($request, $response, $args)
    {
        $path       = ucfirst($args['dir']) . '/' . $args['file'];
        $filesystem = $this->storage->getFilesystem();
        if ($filesystem->has($path)) {
            $filename = isset($_GET['filename']) ? $_GET['filename'] : "doc.png";
            $contents = $filesystem->readStream($path);
            $stream   = new \Slim\Http\Stream($contents);
            return $response->withHeader('Content-Type', 'application/force-download')
                ->withHeader('Content-Type', 'application/octet-stream')
                ->withHeader('Content-Type', 'application/download')
                ->withHeader('Content-Description', 'File Transfer')
                ->withHeader('Content-Transfer-Encoding', 'binary')
                ->withHeader('Content-Disposition', 'attachment; filename="' . basename($filename) . '"')
                ->withHeader('Expires', '0')
                ->withHeader('Cache-Control', 'must-revalidate, post-check=0, pre-check=0')
                ->withHeader('Pragma', 'public')
                ->withBody($stream);
        } else {
            die("File not found");
        }
    }

    public function getPageNotFound($request, $response)
    {
        return $response->withStatus(404)
            ->withHeader('Content-Type', 'text/html')
            ->write($this->render('404'));
    }

}
