<?php

namespace App\Controllers;

use App\Models\Managers;
use Throwable;

class ManagersController extends Controller
{

    public function getIndex($request, $response)
    {
        $users = Managers::all();
        
        if ($request->isXhr()) {
            return $response->withJson($users);
        }else{
            return $this->render('managers/index', compact('users'));
        }

        

    }
    
    public function getDetails($request, $response, $args)
    {
        $id = $args['id'];
		
        $user = $this->db->getReference('Managers/' . $id)->getValue();
        

        return $this->render('managers/details', compact('user'));
    }
    
    public function getEdit($request, $response, $args)
    {

        $id  = $args['id'];

        $ref = $this->db->getReference('Managers/' . $id);
       
        $user = $ref->getValue();

        return $this->render('managers/update', compact('user', 'id'));
    }

    public function getAdd($request, $response)
    {
        return $this->render('managers/update');
    }

    public function postAdd($request, $response)
    {
        return $this->updateDetails($request);
    }

    public function getDelete($request, $response, $args)
    {
        User::remove($args['username']);

        $this->flash->addMessage('form_messages', ["Юзер был удален"]);

        return redirect("/dashboard/managers");
    }

    private function updateDetails($request, $edit = false)
    {

        $user = $request->getParam('user');

        $validator = $this->validate($user, [
            "username" => "required",
            "password" => "required",
        ]);

        if ($validator->failed()) {
            return back();
        }
        
        
         if ($validator->failed()) {
             return back();
         }
         
         
		$load = $request->getParam('user');
		
	
        

		$load['date'] = date("m.d.y"); 
		
        
		$loadsRef = $this->db->getReference('Managers/' . '/' . $brand);
            
            
            if (!$loadsRef->getSnapshot()->exists()) {
                $newLoadKey = 0;
            } else {
                $keys = $loadsRef->getChildKeys();
                sort($keys);
                $newLoadKey = end($keys) + 1;
            }

            $load['id'] = (string) $newLoadKey;
            
            
            
			$ref = $this->db->getReference('/Managers/' . $newLoadKey);
            

            $ref->set($load);
			 

        return redirect('/dashboard/managers/');

    }
    
    
    public function postEdit($request, $response, $args)
    {
        return $this->updateEditDetails($request);
    }
    
    private function updateEditDetails($request)
    {        
         
		$load = $request->getParam('user');
		        		        
        $id = $load['id'];
                                    
		$ref = $this->db->getReference('Managers/' . $id);

        $ref->update($load);

        return redirect('/dashboard/managers/' . $id);

    }

    
   
}
