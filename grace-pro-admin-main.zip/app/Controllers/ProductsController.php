<?php

namespace App\Controllers;

class ProductsController extends Controller
{

    public function getIndex($request, $response)
    {
	    
	    


	    $json = file_get_contents('https://gr.pro.softcom.pp.ua/work_utp_web/hs/mobileappexchange/productsremains/list?exchgID=939c8134-b47e-11eb-b75e-856319ff2119'); 
		$data = json_decode($json);
		
		$drsorbie = $this->db->getReference('Products/DrSorbie')->getValue() ?? [];
		$brae = $this->db->getReference('Products/Brae')->getValue() ?? [];
		$tempting = $this->db->getReference('Products/Tempting')->getValue() ?? [];
		
		foreach ($data as $key => $value) {
			foreach ($drsorbie as $keyBrand1 => $valueBrand1) {
				if ($valueBrand1['vendor'] ===  $value->id) {
					$load = [];
					$load['price'] = $value->price;
					$load['count'] = $value->count;
					$ref = $this->db->getReference('Products/DrSorbie/' . $keyBrand1);
					$ref->update($load);
				}
   		 	}
   		 	foreach ($brae as $keyBrand2 => $valueBrand2) {
				if ($valueBrand2['vendor'] ===  $value->id) {
					$load = [];
					$load['price'] = $value->price;
					$load['count'] = $value->count;
					$ref = $this->db->getReference('Products/Brae/' . $keyBrand1);
					$ref->update($load);
				}
   		 	}
   		 	foreach ($tempting as $keyBrand3 => $valueBrand3) {
				if ($valueBrand3['vendor'] ===  $value->id) {
					$load = [];
					$load['price'] = $value->price;
					$load['count'] = $value->count;
					$ref = $this->db->getReference('Products/Tempting/' . $keyBrand1);
					$ref->update($load);
				}
   		 	}
		}


		
					


        $camera = $this->db->getReference('Products/')->getValue() ?? [];

        return $this->render('products/index', compact('camera'));
    }

    public function getDetails($request, $response, $args)
    {
        $promoplace_id = $args['id'] ?? "";

        $load = $this->db->getReference('Products/' . $promoplace_id)->getValue();
        

        return $this->render('products/details', compact('load'));
    }

    public function getAdd($request, $response, $args)
    {
        $truck_id = $args['truck_id'] ?? null;

        $trip_id = $args['trip_id'] ?? null;

        return $this->render('products/update', compact('truck_id', 'trip_id'));
    }

    public function postAdd($request, $response)
    {
        return $this->addLoadDetails($request);
    }

    public function getEdit($request, $response, $args)
    {

        $id  = $args['place_id'];

        $ref = $this->db->getReference('Products/' . $id);
       
        $load = $ref->getValue();

        if (is_null($load)) {
            return redirect("/dashboard/products/");
        }

        return $this->render('products/update', compact('load', 'id'));
    }

    public function postEdit($request, $response, $args)
    {
        return $this->updateLoadDetails($request, true, $args);
    }

    public function getDelete($request, $response, $args)
    {

        $id  = $args['place_id'];

		$ref = $this->db->getReference('Products/' . $id);
        $ref->remove();
        $this->flash->addMessage('form_messages', ["Продукт был удален"]);


        return redirect("/dashboard/products/");
                
    }
    
    private function addLoadDetails($request, $edit = false)
    {
        $validator = $this->validate($request, [
/*
                 "load.place.category" => "required",
                 "load.place.type" => "required",
*/
                 "load.name" => "required",
         ]);

         if ($validator->failed()) {
             return back();
         }
         
         
		$load = $request->getParam('load');
		$brand = "";
		$load['isTop'] = "0"; 
        $load['count'] = 0;
		if ($load['brand'] == "Dr. Sorbie") {
	            $brand = "DrSorbie";
            } elseif ($load['brand'] == "Brae") { 
	            $brand = "Brae";
            } elseif ($load['brand'] == "Tempting") {
	           	$brand = "Tempting"; 
            } elseif ($load['brand'] == "C этим покупают") {
	            $brand = "BuyTogether"; 
            }
        
        if (is_uploaded_file($_FILES['load']['tmp_name']['imgs']['0'])) {
           $filesystem = $this->storage->getFilesystem();
           $stream     = fopen($_FILES['load']['tmp_name']['imgs']['0'], 'r+');
           $filename   = md5(time()) . "0.png";
           $filesystem->writeStream(
               'Logos/' . $filename,
               $stream
           );
           fclose($stream);
           $load['logo'] = $filename;
           $load['imgs']['0'] = $filename;
       } else {
            $load['imgs']['0'] = null;
         }
       
       if (is_uploaded_file($_FILES['load']['tmp_name']['imgs']['1'])) {
            $filesystem = $this->storage->getFilesystem();
            $stream     = fopen($_FILES['load']['tmp_name']['imgs']['1'], 'r+');
            $filename   = md5(time()) . "1.png";
            $filesystem->writeStream(
                'Logos/' . $filename,
                $stream
            );
            fclose($stream);
            $load['imgs']['1'] = $filename;
        } else {
           $load['imgs']['1'] = null;
        }
       
       if (is_uploaded_file($_FILES['load']['tmp_name']['imgs']['2'])) {
           $filesystem = $this->storage->getFilesystem();
           $stream     = fopen($_FILES['load']['tmp_name']['imgs']['2'], 'r+');
           $filename   = md5(time()) . "2.png";
           $filesystem->writeStream(
               'Logos/' . $filename,
               $stream
           );
           fclose($stream);
           $load['imgs']['2'] = $filename;
       } else {
            $load['imgs']['2'] = null;
         }
       
       if (is_uploaded_file($_FILES['load']['tmp_name']['imgs']['3'])) {
           $filesystem = $this->storage->getFilesystem();
           $stream     = fopen($_FILES['load']['tmp_name']['imgs']['3'], 'r+');
           $filename   = md5(time()) . "3.png";
           $filesystem->writeStream(
               'Logos/' . $filename,
               $stream
           );
           fclose($stream);
           $load['imgs']['3'] = $filename;
       } else {
            $load['imgs']['3'] = null;
         }

		$load['date'] = date("m.d.y"); 
		
		 if ($edit) {
			 

			 $id = $load['id'];
                                    
			 $ref = $this->db->getReference('Products/' . $brand . '/' . $id);

             $ref->update($load);


			 
			 } else {
        
		$loadsRef = $this->db->getReference('Products/' . '/' . $brand);
            
            
            if (!$loadsRef->getSnapshot()->exists()) {
                $newLoadKey = 0;
            } else {
                $keys = $loadsRef->getChildKeys();
                sort($keys);
                $newLoadKey = end($keys) + 1;
            }

            $load['id'] = (string) $newLoadKey;
            
            
            
			$ref = $this->db->getReference('/Products/' . $brand . '/' . $newLoadKey);
            

            $ref->set($load);
			 }
        

        return redirect('/dashboard/products/' . $brand . '/' . $newLoadKey);
  

    }

    private function updateLoadDetails($request, $edit = false, $args)
    {
        $validator = $this->validate($request, [
/*
                 "load.place.category" => "required",
                 "load.place.type" => "required",
*/
                 "load.name" => "required",
         ]);

         if ($validator->failed()) {
             return back();
         }
         
         
		$load = $request->getParam('load');
		$brand = "";
		
		if ($load['brand'] == "Dr. Sorbie") {
	            $brand = "DrSorbie";
            } elseif ($load['brand'] == "Brae") { 
	            $brand = "Brae";
            } elseif ($load['brand'] == "Tempting") {
	           	$brand = "Tempting"; 
            } elseif ($load['brand'] == "C этим покупают") {
	            $brand = "BuyTogether"; 
            }
        
        // if (is_uploaded_file($_FILES['load']['tmp_name']['logo'])) {
        //     $filesystem = $this->storage->getFilesystem();
        //     $stream     = fopen($_FILES['load']['tmp_name']['logo'], 'r+');
        //     $filename   = md5(time()) . ".png";
        //     $filesystem->writeStream(
        //         'Logos/' . $filename,
        //         $stream
        //     );
        //     fclose($stream);
        //     $load['logo'] = $filename;
        // }

		$load['date'] = date("m.d.y"); 
		
		 if ($edit) {
			 

			 $id = $load['id'];
                                    
			 $ref = $this->db->getReference('Products/' . $brand . '/' . $id);

             $ref->update($load);


			 
			 } else {
        
		$loadsRef = $this->db->getReference('Products/' . '/' . $brand);
            
            
            if (!$loadsRef->getSnapshot()->exists()) {
                $newLoadKey = 0;
            } else {
                $keys = $loadsRef->getChildKeys();
                sort($keys);
                $newLoadKey = end($keys) + 1;
            }

            $load['id'] = (string) $newLoadKey;
            
            
            
			$ref = $this->db->getReference('/Products/' . $brand . '/' . $newLoadKey);
            

            $ref->set($load);
            
			 }
        

        return redirect('/dashboard/products/' . $load['id']);
  

    }

}
