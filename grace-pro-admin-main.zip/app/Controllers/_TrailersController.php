<?php

namespace App\Controllers;

use App\Models\Trailer;


class TrailersController extends Controller
{

    public function getIndex($request, $response)
    {
        $trailers = Trailer::all();


        return $this->render('trailers/index', compact('trailers'));
        
        
    }

    public function getDetails($request, $response, $args)
    {
        $trailer = Trailer::find($args['trailer_id']);

        if (empty($trailer)) {
            return redirect("/dashboard/trailers");
        }

        return $this->render('trailers/details', compact('trailer'));
    }

    public function getAdd($request, $response)
    {
        return $this->render('trailers/update');
    }

    public function postAdd($request, $response)
    {
        return $this->updateDetails($request);
    }

    public function getEdit($request, $response, $args)
    {
        $trailer = Trailer::find($args['trailer_id']);

        if (empty($trailer)) {
            return redirect("/dashboard/trailers");
        }

        return $this->render('trailers/update', compact('trailer'));
    }

    public function postEdit($request, $response, $args)
    {
        return $this->updateDetails($request, true);
    }

    public function getDelete($request, $response, $args)
    {
        Trailer::remove($args['trailer_id']);

        $this->flash->addMessage('form_messages', ["Trailer #${args['trailer_id']} has been deleted."]);

        return redirect("/dashboard/trailers");
    }

    private function updateDetails($request, $edit = false)
    {
        $validator = $this->validate($request, [
            "trailer.TrailerNumber" => "required|numeric",
        ]);

        if ($validator->failed()) {
            return back();
        }

        $trailer = $request->getParam('trailer');

        $trailerNumber = $trailer['TrailerNumber'];

        $trailer['Active'] = $trailer['Active'] == 'true' ? 1 : 0;
        
        
         if (is_uploaded_file($_FILES['trailer']['tmp_name']['PDF'])) {
            $filesystem = $this->storage->getFilesystem();
            $stream     = fopen($_FILES['trailer']['tmp_name']['PDF'], 'r+');
            $filename   = md5(time()) . ".pdf";
            $filesystem->writeStream(
                'Trailer/' . $filename,
                $stream
            );
            fclose($stream);
            $trailer['PDF'] = $filename;
        } 

        if ($edit) {

            try{
                Trailer::update($trailerNumber, $trailer);
            }catch(\Throwable $e){
                $this->flash->addMessage('form_errors', ["Something went wrong. " . $e->getMessage()]);
                return back();
            }

        } else {

            try{
                Trailer::create($trailerNumber, $trailer);
            }catch(\Throwable $e){
                $this->flash->addMessage('form_errors', ["Something went wrong. " . $e->getMessage()]);
                return back();
            }
            
        }

        if ($edit) {
            return redirect("/dashboard/trailers/" . $trailer['TrailerNumber']);
        } else {
            return redirect("/dashboard/trailers");
        }

    }

}
