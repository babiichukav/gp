<?php

namespace App\Controllers;

//echo("<script>console.log('PHP: " . $brand . "');</script>");

class BuyTogetherController extends Controller
{

    public function getIndex($request, $response, $args)
    { 
	    $brand = $args['brand'];
        $products = $this->db->getReference('BuyTogether/' . $brand)->getValue() ?? [];

        return $this->render('buyTogether/index', compact('products', 'brand'));
    }

    public function getDetails($request, $response, $args)
    {
	    $brand = $args['brand'];        

        return $this->render('buyTogether/details', compact('brand'));
    }


    public function postAdd($request, $response)
    {
        return $this->updateLoadDetails($request);
    }

    public function getEdit($request, $response, $args)
    {

        $brand = $args['brand'];

        return $this->render('buyTogether/update', compact('brand'));
    }

    public function postEdit($request, $response, $args)
    {
        return $this->updateLoadDetails($request, true, $args);
    }

    public function getDelete($request, $response, $args)
    {

        $brand = $args['brand'];
        $id = $args['id'];

		$ref = $this->db->getReference('BuyTogether/' . $brand . '/' . $id);
        $ref->remove();
        $this->flash->addMessage('form_messages', ["Продукт был удален"]);

		return redirect('/dashboard/products/' . $brand . '/' . 'buyTogether');
                
    }

    private function updateLoadDetails($request, $edit = false, $args)
    {

         
         
		$load = $request->getParam('load');
		$brand = $load['brand'];
		
        if (is_uploaded_file($_FILES['load']['tmp_name']['logo'])) {
            $filesystem = $this->storage->getFilesystem();
            $stream     = fopen($_FILES['load']['tmp_name']['logo'], 'r+');
            $filename   = md5(time()) . ".png";
            $filesystem->writeStream(
                'Logos/' . $filename,
                $stream
            );
            fclose($stream);
            $load['logo'] = $filename;
        }

		$load['date'] = date("m.d.y"); 
		 
        
		$loadsRef = $this->db->getReference('BuyTogether/' . '/' . $brand);
            
            
            if (!$loadsRef->getSnapshot()->exists()) {
                $newLoadKey = 0;
            } else {
                $keys = $loadsRef->getChildKeys();
                sort($keys);
                $newLoadKey = end($keys) + 1;
            }

             $load['id'] = (string) $newLoadKey;
            
            
            
			$ref = $this->db->getReference('/BuyTogether/' . $brand . '/' . $newLoadKey);
            

            $ref->set($load);
			 
        

        return redirect('/dashboard/products/' . $brand . '/' . 'buyTogether');
  

    }

}
