<?php

namespace App\Controllers;

use App\Models\Tariffs;


class TariffsController extends Controller
{

    public function getIndex($request, $response)
    {
	    
        $news = News::all() ?? [];

        return $this->render('tariffs/index', compact('news'));
    }

    public function getDetails($request, $response, $args)
    {
        $promoplace_id = $args['news_id'] ?? "";
        $camera = News::all() ?? [];

        $load = $this->db->getReference('tariffs/' . $promoplace_id)->getValue();
        

        return $this->render('tariffs/details', compact('load'));
    }

    public function getAdd($request, $response, $args)
    {
        $truck_id = $args['truck_id'] ?? null;
        $trip_id = $args['trip_id'] ?? null;

        return $this->render('tariffs/update', compact('truck_id', 'trip_id'));
    }

    public function postAdd($request, $response)
    {
        return $this->updateLoadDetails($request);
    }

    public function getEdit($request, $response, $args)
    {

        $id  = $args['tariff_id'];

        $ref = $this->db->getReference('tariffs/' . $id);
       
        $load = $ref->getValue();

        if (is_null($load)) {
            return redirect("/dashboard/tariffs/");
        }

        return $this->render('tariffs/update', compact('load', 'id'));
    }

    public function postEdit($request, $response, $args)
    {
        return $this->updateLoadDetails($request, true, $args);
    }

/*
    public function getDelete($request, $response, $args)
    {

        $id  = $args['news_id'];

		$ref = $this->db->getReference('News/' . $id);
        $ref->remove();
        $this->flash->addMessage('form_messages', ["Новость была удалена"]);


        return redirect("/dashboard/news/");
                
    }
*/

    private function updateLoadDetails($request, $edit = false)
    {

                  
		$load = $request->getParam('load');
			       		
		 if ($edit) {
			 

			 $id = $load['id'];
			 
			 echo("<script>console.log('PHP: " . $id . "');</script>");

                                    
			 $ref = $this->db->getReference('tariffs/' . $id);

             $ref->update($load);


			 
			 } else {
        
			 $loadsRef = $this->db->getReference('tariffs/');
            
            
            if (!$loadsRef->getSnapshot()->exists()) {
                $newLoadKey = 0;
            } else {
                $keys = $loadsRef->getChildKeys();
                sort($keys);
                $newLoadKey = end($keys) + 1;
            }

            $load['id'] = (string) $newLoadKey;
            
			$ref = $this->db->getReference('tariffs/' . $newLoadKey);
            

            $ref->set($load);
			 }
        

        return redirect('/dashboard/tariffs/');
  

    }

}
