<?php

namespace App\Controllers;

use App\Models\Procedures;


class ProceduresController extends Controller
{

    public function getIndex($request, $response, $args)
    {
	            
        $brand = $args['brand'];
        $news = $this->db->getReference('Procedures/' . $brand)->getValue() ?? [];

        return $this->render('procedures/index', compact('news'));
    }

    public function getDetails($request, $response, $args)
    {
        $promoplace_id = $args['news_id'] ?? "";
        $camera = Procedures::all() ?? [];

        $load = $this->db->getReference('Procedures/' . $promoplace_id)->getValue();
        

        return $this->render('procedures/details', compact('load'));
    }

    public function getAdd($request, $response, $args)
    {
        $truck_id = $args['truck_id'] ?? null;
        $trip_id = $args['trip_id'] ?? null;

        return $this->render('procedures/update', compact('truck_id', 'trip_id'));
    }

    public function postAdd($request, $response)
    {
        return $this->updateLoadDetails($request);
    }

    public function getEdit($request, $response, $args)
    {

        $id  = $args['news_id'];
        $brand = $args['brand'];
                                
        $ref = $this->db->getReference('Procedures/' . $brand . '/' . $id);
       
        $load = $ref->getValue();

        if (is_null($load)) {
            return redirect("/dashboard/procedures/");
        }

        return $this->render('procedures/update', compact('load', 'id'));
    }

    public function postEdit($request, $response, $args)
    {
	    echo("<script>console.log('PHP:');</script>");
        return $this->updateLoadDetails($request, true, $args);
    }

    public function getDelete($request, $response, $args)
    {

        $id  = $args['news_id'];
		$brand = $args['brand'];
		$ref = $this->db->getReference('Procedures/' . $brand . '/' . $id);
        $ref->remove();
        $this->flash->addMessage('form_messages', ["Процедура была удалена"]);


        return redirect('/dashboard/products/' . $brand . '/procedures');
                
    }

    private function updateLoadDetails($request, $edit = false)
    {
      
         
		$load = $request->getParam('load');

		$brand = "";
		
		if ($load['brand'] == "Dr. Sorbie") {
	            $brand = "DrSorbie";
	            $load['brand'] = "DrSorbie";
            } elseif ($load['brand'] == "Brae") { 
	            $brand = "Brae";
            } elseif ($load['brand'] == "Tempting") {
	           	$brand = "Tempting"; 
            }
            
		if (is_uploaded_file($_FILES['load']['tmp_name']['photo'])) {
            $filesystem = $this->storage->getFilesystem();
            $stream     = fopen($_FILES['load']['tmp_name']['photo'], 'r+');
            $filename   = md5(time()) . ".png";
            $filesystem->writeStream(
                'Photos/' . $filename,
                $stream
            );
            fclose($stream);
            $load['photo'] = $filename;
        }
       
		
		$load['Date'] = date("m.d.y"); 
		echo("<script>console.log('PHP: " . $load['Date'] . "');</script>");

		
		 if ($edit) {
			 

			 $id = $load['id'];
                                    
			 $ref = $this->db->getReference('Procedures/' . $brand . '/' . $id);

             $ref->update($load);
			 
			 } else {
        
		$loadsRef = $this->db->getReference('Procedures/' . $brand);
            
            
            if (!$loadsRef->getSnapshot()->exists()) {
                $newLoadKey = 0;
            } else {
                $keys = $loadsRef->getChildKeys();
                sort($keys);
                $newLoadKey = end($keys) + 1;
            }

            $load['id'] = (string) $newLoadKey;
            
        $ref = $this->db->getReference('Procedures/' . $brand . '/' . $newLoadKey);
            

            $ref->set($load);
			 }
        

        return redirect('/dashboard/products/' . $brand . '/procedures');
  

    }

}
