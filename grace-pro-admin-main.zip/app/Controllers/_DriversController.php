<?php

namespace App\Controllers;

use App\Models\Driver;

class DriversController extends Controller
{

    public function getIndex($request, $response)
    {
        $drivers = Driver::all();

        return $this->render('drivers/index', compact('drivers'));
    }

    public function getDetails($request, $response, $args)
    {
        $driverKey = unslugify($args['driver']);

        $driver = Driver::find($driverKey);

        if (empty($driver)) {
            return redirect("/dashboard/drivers");
        }

        return $this->render('drivers/details', compact('driver'));
    }

    public function getAdd($request, $response)
    {
        return $this->render('drivers/update');
    }

    public function postAdd($request, $response)
    {
        return $this->updateDriverDetails($request);
    }

    public function getEdit($request, $response, $args)
    {
        $driverKey = unslugify($args['driver']);

        $driver = Driver::find($driverKey);

        if (empty($driver)) {
            return redirect("/dashboard/drivers");
        }

        return $this->render('drivers/update', compact('driver'));
    }

    public function postEdit($request, $response, $args)
    {
        return $this->updateDriverDetails($request, true);
    }

    public function getDelete($request, $response, $args)
    {
        $driverKey = unslugify($args['driver']);

        Driver::remove($driverKey);

        $this->flash->addMessage('form_messages', ["Driver has been deleted."]);

        return redirect("/dashboard/drivers");
    }

    private function updateDriverDetails($request, $edit = false)
    {
        $validator = $this->validate($request, [
            "driver.Name" => "required",
        ]);

        if ($validator->failed()) {
            return back();
        }

        $driver = $request->getParam('driver');

        $driver['active'] = $driver['active'] == 'true' ? 1 : 0;

        if (is_uploaded_file($_FILES['driver']['tmp_name']['PDF'])) {
            $filesystem = $this->storage->getFilesystem();
            $stream = fopen($_FILES['driver']['tmp_name']['PDF'], 'r+');
            $filename = md5(time()) . ".pdf";
            $filesystem->writeStream(
                'Drivers/' . $filename,
                $stream
            );
            fclose($stream);
            $driver['PDF'] = $filename;
        }

        $driverName = $driver['Name'];

        if ($edit) {

            try {
                Driver::update($driverName, $driver);
            } catch (\Throwable $e) {
                $this->flash->addMessage('form_errors', ["Something went wrong. " . $e->getMessage()]);
                return back();
            }

        } else {

            try {
                Driver::create($driverName, $driver);
            } catch (\Throwable $e) {
                $this->flash->addMessage('form_errors', ["Something went wrong. " . $e->getMessage()]);
                return back();
            }

        }

        if ($edit) {
            $driverKey = slugify($driverName);
            return redirect("/dashboard/drivers/" . $driverKey);
        } else {
            return redirect("/dashboard/drivers");
        }

    }

}
