<?php

namespace App\Controllers;

class ExpensesController extends Controller
{

    public function getEdit($request, $response, $args)
    {
        $truck_id = $args['truck_id'];

        $expenses = $this->db->getReference('Trucks/' . $truck_id . '/Expenses')->getValue();

        return $this->render('expenses/update', compact('expenses', 'truck_id'));
    }

    public function postEdit($request, $response, $args)
    {
        return $this->updateExpensesDetails($request, true);
    }
    
    private function updateExpensesDetails($request, $edit = false)
    {
        $validator = $this->validate($request, [

        ]);

        if ($validator->failed()) {
            return back();
        }

        $expenses = $request->getParam('expenses');

        $expenses["InsuranceStatus"] = ($expenses["InsuranceStatus"] == 'true');

        $truck_id = $expenses["TruckNumber"];

        unset($expenses["TruckNumber"]);

        $ref = $this->db->getReference('Trucks/' . $truck_id . '/Expenses');

        if ($edit){
            
            $ref->update($expenses);

        }else{

            $ref->set($expenses);
        }

        return redirect("/dashboard/trucks/" . $truck_id);

    }



}
