<?php

namespace App\Controllers;

class ClientInfoController extends Controller
{

    public function getEdit($request, $response, $args)
    {
        $place_id = $args['place_id'];

        $client = $this->db->getReference('PromoPlaces/' . $place_id . '/client')->getValue();

        return $this->render('client/update', compact('client', 'place_id'));
    }

    public function postEdit($request, $response, $args)
    {
        return $this->updateExpensesDetails($request, true, $args);
    }
    
    private function updateExpensesDetails($request, $edit = false, $args)
    {

		$place_id = $args['place_id'];

        $client = $request->getParam('client');

        $ref = $this->db->getReference('PromoPlaces/' . $place_id . '/client');

        if ($edit) {
            $ref->update($client);
        } else {
            $ref->set($client);
        }

        return redirect("/dashboard/promoplaces/" . $place_id);

    }



}
