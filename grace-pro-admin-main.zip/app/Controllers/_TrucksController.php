<?php

namespace App\Controllers;

use App\Models\Truck;

class TrucksController extends Controller
{

    public function getIndex($request, $response)
    {
        $trucks = Truck::all();

        if ($request->isXhr()) {
            return $response->withJson($trucks);
        }else{
            return $this->render('trucks/index', compact('trucks'));
        }
        
    }

    public function getDetails($request, $response, $args)
    {
        $truck = Truck::find($args['truck_id']);
        
        

        if (empty($truck)) {
            return redirect("/dashboard/trucks");
        }
        if ($request->isXhr()) {
            return $response->withJson($truck['Trips'] ?? []);
        }
        $total_lumper = 0;
        $total_expenses = 0;
        $total_wallet = 0;

        //Lumper
        if(!empty($truck['Trips'])){
            foreach ($truck['Trips'] as $key=>&$trip) {
                if(is_null($trip)) continue;


                if(empty($trip['Loads'])) {
                    $trip['hide_details'] = true;
                    continue;
                }

                $own_loads = 0;
               
                foreach ($trip['Loads'] as $key=>$load) {
                    if(empty($load)) continue;

                    if($_SESSION['user'] != "admin" && (empty($load['created_by']) || $load['created_by'] != $_SESSION['user'])){
                    unset($truck['Trips'][$key]['Loads'][$key]);
                    continue;
                    }


                    if($_SESSION['user'] == "admin" || (!empty($load['created_by']) && $load['created_by'] == $_SESSION['user'])){
                        $own_loads++;
                    }

                    
                    $total_lumper += parse_num($load['Lumper']);
                    $total_wallet += parse_num($load['Onhold']);
                }
                if($own_loads == 0){

                    $trip['hide_details'] = true;
                }
            }
            //var_dump($truck['Trips']);
        }

        //Total expenses
        if(!empty($truck['Expenses'])){
            foreach ($truck['Expenses'] as $expenses_title => $expenses) {
                if(in_array($expenses_title, ['InsuranceNotes', 'InsuranceStatus'])) continue;
                $val = parse_num($expenses);
                $total_expenses += $val;
            }
        }
        
        $truck['Active'] = $truck['Active'] == 'true' ? 1 : 0;

        return $this->render('trucks/details', compact('truck', 'total_lumper', 'total_expenses', 'total_wallet'));
    }

    public function getAdd($request, $response)
    {
        return $this->render('trucks/update');
    }

    public function postAdd($request, $response)
    {
        return $this->updateTruckDetails($request);
    }

    public function getEdit($request, $response, $args)
    {
        $truck = Truck::find($args['truck_id']);

        if (empty($truck)) {
            return redirect("/dashboard/trucks");
        }

        return $this->render('trucks/update', compact('truck'));
    }

    public function postEdit($request, $response, $args)
    {
        return $this->updateTruckDetails($request, true);
    }

    public function getDelete($request, $response, $args)
    {
        Truck::remove($args['truck_id']);

        $this->flash->addMessage('form_messages', ["Truck #${args['truck_id']} has been deleted."]);

        return redirect("/dashboard/trucks");
    }

    private function updateTruckDetails($request, $edit = false)
    {
        $validator = $this->validate($request, [
            "truck.TruckNumber" => "required|numeric",
        ]);

        if ($validator->failed()) {
            return back();
        }

        $truck = $request->getParam('truck');

        $truckNumber = $truck['TruckNumber'];
        
        
        if (is_uploaded_file($_FILES['truck']['tmp_name']['PDF'])) {
            $filesystem = $this->storage->getFilesystem();
            $stream     = fopen($_FILES['truck']['tmp_name']['PDF'], 'r+');
            $filename   = md5(time()) . ".pdf";
            $filesystem->writeStream(
                'Truck/' . $filename,
                $stream
            );
            fclose($stream);
            $truck['PDF'] = $filename;
        }        

        if ($edit) {

            try{
                Truck::update($truckNumber, $truck);
            }catch(\Throwable $e){
                $this->flash->addMessage('form_errors', ["Something went wrong. " . $e->getMessage()]);
                return back();
            }

        } else {

            try{
                Truck::create($truckNumber, $truck);
            }catch(\Throwable $e){
                $this->flash->addMessage('form_errors', ["Something went wrong. " . $e->getMessage()]);
                return back();
            }
            
        }

        if ($edit) {
            return redirect("/dashboard/trucks/" . $truck['TruckNumber']);
        } else {
            return redirect("/dashboard/trucks");
        }

    }

}
