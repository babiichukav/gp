<?php

namespace App\Controllers;

use App\Models\News;
use Throwable;
class ParamsController extends Controller
{

    public function getEdit($request, $response, $args)
    {
        $brand = $args['brand'];
        $id = $args['id'];
        $promo_id  = $args['param_id'] ?? "";

		$data = $this->db->getReference('Products/' . $brand . '/' . $id . '/params/' . $promo_id)->getValue();

        return $this->render('params/update', compact('brand', 'id', 'data'));
    }

    public function postEdit($request, $response, $args)
    {
        return $this->updateExpensesDetails($request, true, $args);
    }
    
    public function post($request, $response, $args)
    {
        return $this->createExpensesDetails($request, true, $args);
    }
    
    private function updateExpensesDetails($request, $edit = false, $args)
    {
		
		$user = $request->getParam('promocodes');

        $validator = $this->validate($user, [
            "name" => "required",
            "price" => "required",
            "vendor" => "required",

        ]);

        if ($validator->failed()) {
            return back();
        }
        
		
		$brand = $args['brand'];
        $id = $args['id'];
		$promo_id  = $args['param_id'];
		
        $promocodes = $request->getParam('promocodes');

		$loadsRef = $this->db->getReference('Products/' . $brand . '/' . $id . '/params');
            
                            $newLoadKey = $promo_id;


            if (!$loadsRef->getSnapshot()->exists()) {
                $newLoadKey = 0;
            } else {
                $keys = $loadsRef->getChildKeys();
                sort($keys);
                $newLoadKey = end($keys) + 1;
            }
            
                       
             if (is_uploaded_file($_FILES['promocodes']['tmp_name']['logo'])) {
            $filesystem = $this->storage->getFilesystem();
            $stream     = fopen($_FILES['promocodes']['tmp_name']['logo'], 'r+');
            $filename   = md5(time()) . ".png";
            $filesystem->writeStream(
                'Logos/' . $filename,
                $stream
            );
            fclose($stream);
            $promocodes['logo'] = $filename;
 			}


            $promocodes['id'] = (string) $newLoadKey;
            
			$ref = $this->db->getReference('Products/' . $brand . '/' . $id . '/params/' . $newLoadKey);

            $ref->update($promocodes);    
        

        return redirect("/dashboard/products/" . $brand . '/' . $id);

    }
    
    private function createExpensesDetails($request, $edit = false, $args)
    {
		
		
		$user = $request->getParam('promocodes');

        $validator = $this->validate($user, [
            "name" => "required",
            "price" => "required",
            "vendor" => "required",

        ]);

        if ($validator->failed()) {
            return back();
        }
        
		
		$brand = $args['brand'];
        $id = $args['id'];
		$promo_id  = $args['param_id'];
		
        $promocodes = $request->getParam('promocodes');

		$loadsRef = $this->db->getReference('Products/' . $brand . '/' . $id . '/params');
            
                            $newLoadKey = $promo_id;


            if (!$loadsRef->getSnapshot()->exists()) {
                $newLoadKey = 0;
            } else {
                $keys = $loadsRef->getChildKeys();
                sort($keys);
                $newLoadKey = end($keys) + 1;
            }
            
            $newLoadKey = $promo_id;    
             if (is_uploaded_file($_FILES['promocodes']['tmp_name']['logo'])) {
            $filesystem = $this->storage->getFilesystem();
            $stream     = fopen($_FILES['promocodes']['tmp_name']['logo'], 'r+');
            $filename   = md5(time()) . ".png";
            $filesystem->writeStream(
                'Logos/' . $filename,
                $stream
            );
            fclose($stream);
            $promocodes['logo'] = $filename;
 			}


            $promocodes['id'] = (string) $newLoadKey;
            $promocodes['count'] = 0;
            
			$ref = $this->db->getReference('Products/' . $brand . '/' . $id . '/params/' . $newLoadKey);

            $ref->update($promocodes);    
        

        return redirect("/dashboard/products/" . $brand . '/' . $id);


    }
 
	public function getDelete($request, $response, $args)
    {
	
		$brand = $args['brand'];
        $id = $args['id'];
        $promo_id  = $args['param_id'];

		$ref = $this->db->getReference('Products/' . $brand . '/' . $id . '/params/' . $promo_id);
        $ref->remove();
        $this->flash->addMessage('form_messages', ["Парамер товара был удален"]);


        return redirect("/dashboard/products/" . $place_id);
                
    }


}
