<?php

namespace App\Controllers;

use App\Models\Notes;

class NotesController extends Controller
{

    public function getIndex($request, $response)
    {
        $notes = Notes::all();

        return $this->render('notes/index', compact('notes'));
    }

    public function getDetails($request, $response, $args)
    {
	    
        $notesKey = unslugify($args['note']);

        $notes = Notes::find($notesKey);

        if (empty($notes)) {
            return redirect("/dashboard/notes");
        }

        return $this->render('notes/details', compact('notes'));
    }

    public function getAdd($request, $response)
    {
        return $this->render('notes/update');
    }

    public function postAdd($request, $response)
    {
        return $this->updateNotesDetails($request);
    }

    public function getEdit($request, $response, $args)
    {
        $notesKey = unslugify($args['note']);

        $notes = Notes::find($notesKey);

        if (empty($notes)) {
            return redirect("/dashboard/notes");
        }

        return $this->render('notes/update', compact('notes'));
    }

    public function postEdit($request, $response, $args)
    {
        return $this->updateNotesDetails($request, true);
    }

    public function getDelete($request, $response, $args)
    {
        $notesKey = unslugify($args['note']);

        Notes::remove($notesKey);

        $this->flash->addMessage('form_messages', ["Note has been deleted."]);

        return redirect("/dashboard/notes");
    }

    private function updateNotesDetails($request, $edit = false)
    {
        $validator = $this->validate($request, [
            "notes.Title" => "required",
        ]);

        if ($validator->failed()) {
            return back();
        }

        $notes = $request->getParam('notes');       
        $notesName = $notes['Title'];

        if ($edit) {

            try {
                Notes::update($notesName, $notes);
            } catch (\Throwable $e) {
                $this->flash->addMessage('form_errors', ["Something went wrong. " . $e->getMessage()]);
                return back();
            }

        } else {

            try {
                Notes::create($notesName, $notes);
            } catch (\Throwable $e) {
                $this->flash->addMessage('form_errors', ["Something went wrong. " . $e->getMessage()]);
                return back();
            }

        }

        if ($edit) {
            $noteKey = slugify($noteName);
            return redirect("/dashboard/notes/" . $noteKey);
        } else {
            return redirect("/dashboard/notes");
        }

    }

}
