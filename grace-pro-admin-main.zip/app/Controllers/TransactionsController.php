<?php

namespace App\Controllers;

use App\Models\Transactions;
use Throwable;

class TransactionsController extends Controller
{

    public function getIndex($request, $response, $args)
    {
	    
	    $id = $args['place_id'];

        $users = $this->db->getReference('Transactions/' . $id)->getValue();

        return $this->render('transactions/index', compact('users'));

    }

    public function getAdd($request, $response)
    {
        return $this->render('transactions/update');
    }

    public function postAdd($request, $response)
    {
        return $this->updateDetails($request);
    }

    public function getDelete($request, $response, $args)
    {
        Transactions::remove($args['username']);

        $this->flash->addMessage('form_messages', ["Юзер был удален"]);

        return redirect("/dashboard/transactions");
    }

/*
    private function updateDetails($request, $edit = false)
    {

        $user = $request->getParam('user');


        $ref = $this->db->getReference('Transactions/' . md5($user['username']));
        if ($ref->getSnapshot()->exists()) {
            $this->flash->addMessage('form_errors', ["User already exists"]);
            return back();
        }

        $user['date_added'] = date("m/d/Y");
        $user['total_loads'] = 0;
        try {
            User::create(md5($user['username']), $user);
        } catch (Throwable $e) {
            $this->flash->addMessage('form_errors', ["Something went wrong. " . $e->getMessage()]);
            return back();
        }

        return redirect("/dashboard/transactions");

    }
*/

}
