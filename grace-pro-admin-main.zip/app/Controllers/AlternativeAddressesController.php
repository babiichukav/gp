<?php

namespace App\Controllers;

class AlternativeAddressesController extends Controller
{

    public function getEdit($request, $response, $args)
    {
        $place_id = $args['place_id'];

        $promocodes = $this->db->getReference('PromoPlaces/' . $place_id . '/addresses')->getValue();

        return $this->render('alternativeaddresses/update', compact('promocodes', 'place_id'));
    }

    public function postEdit($request, $response, $args)
    {
        return $this->updateExpensesDetails($request, true, $args);
    }
    
    private function updateExpensesDetails($request, $edit = false, $args)
    {

		$place_id = $args['place_id'];
		
		
		$loadsRef = $this->db->getReference('PromoPlaces/' . $place_id . '/addresses');
            
            
            if (!$loadsRef->getSnapshot()->exists()) {
                $newLoadKey = 1;
            } else {
                $keys = $loadsRef->getChildKeys();
                sort($keys);
                $newLoadKey = end($keys) + 1;
            }

                    $promocodes = $request->getParam('addresses');

            $promocodes['id'] = (string) $newLoadKey;
            
        $ref = $this->db->getReference('PromoPlaces/' . $place_id . '/addresses/' . $newLoadKey);


            $ref->set($promocodes);


        return redirect("/dashboard/promoplaces/" . $place_id);

    }

	public function getDelete($request, $response, $args)
    {

        $place_id  = $args['place_id'];
        $addresses_id  = $args['addresses_id'];

		$ref = $this->db->getReference('PromoPlaces/' . $place_id . '/addresses/' . $addresses_id);
        $ref->remove();
        $this->flash->addMessage('form_messages', ["Адрес был удален"]);


        return redirect("/dashboard/promoplaces/" . $place_id);
                
    }


}
