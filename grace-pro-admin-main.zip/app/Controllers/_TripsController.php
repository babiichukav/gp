<?php

namespace App\Controllers;

use Dompdf\Dompdf;
use App\Models\Truck;
use App\Models\Driver;

class TripsController extends Controller
{

    public function getDetails($request, $response, $args)
    {
        $truck_id = $args['truck_id'];

        $ref = $this->db->getReference('Trucks/' . $truck_id . '/Trips');

        if(is_null($ref->getValue())){
            return redirect("/dashboard/trucks/" . $truck_id);
        }

        $trip = $ref->orderByKey()
            ->equalTo((string) $args['trip_id'])
            ->getValue();



        if (empty($trip)) {
            return redirect("/dashboard/trucks/" . $truck_id);
        }

        $trip = reset($trip);


        if(isset($trip['Check'])){
            $filename = $trip['Check'];
        } else {
            $filename = md5($args['trip_id'] . $truck_id) . ".pdf";
        }

       
        $filesystem = $this->storage->getFilesystem();
        if ($filesystem->has('Checks/' . $filename)) {
            $filename_o = "trip_" . $args['trip_id'] . "_truck_" . $truck_id . "_invoice.pdf";
            $check_url = '/dashboard/download/checks/' . $filename . '/?filename=' . $filename_o;
        }

        


        if(!empty($trip["Loads"])){
           foreach($trip["Loads"] as $key => $load){
            if($_SESSION['user'] != "admin" && (empty($load["created_by"]) || $load["created_by"] != $_SESSION['user'])){
                                unset($trip["Loads"][$key]);
                            }
            }

            
        }
               

        return $this->render('trips/details', compact('trip', 'truck_id', 'check_url'));
    }

    public function getAdd($request, $response, $args)
    {
        $drivers = Driver::all();

        $drivers = array_keys($drivers);

        $truck_id = $args['truck_id'];

        return $this->render('trips/update', compact('drivers', 'truck_id'));
    }

    public function postAdd($request, $response)
    {
        return $this->updateTripDetails($request);
    }

    public function getEdit($request, $response, $args)
    {

        $truck_id = $args['truck_id'];

        $trip_id = $args['trip_id'];

        $ref = $this->db->getReference('Trucks/' . $truck_id . '/Trips/' . $trip_id);

        $trip = $ref->getValue();

        if(is_null($trip)){
            return redirect("/dashboard/trucks/" . $truck_id);
        }

        $drivers = Driver::all();

        $drivers = array_keys($drivers);

        return $this->render('trips/update', compact('trip', 'drivers', 'truck_id'));
    }
    
    public function postEdit($request, $response, $args)
    {
        return $this->updateTripDetails($request, true);
    }

    public function getDelete($request, $response, $args)
    {
        $truck_id = $args['truck_id'];
        $trip_id = $args['trip_id'];

        $ref = $this->db->getReference('Trucks/' . $truck_id . '/Trips/' . $trip_id);
        $ref->remove();
        $this->flash->addMessage('form_messages', ["Trip #${trip_id} has been deleted."]);
        return redirect("/dashboard/trucks/" . $truck_id);
    }

    private function updateTripDetails($request, $edit = false)
    {
        $validator = $this->validate($request, [
            // "trip.From" => "required",
            // "trip.To" => "required",
            // "trip.Date" => "required|date:d/m/Y",
            // "trip.Driver" => "required",
            // "trip.DriverMoney" => "required",
            // "trip.Fuel" => "required",
            // "trip.MoneyNote" => "required",
            "trip.TruckNum" => "required",
        ]);

        if ($validator->failed()) {
            return back();
        }

        $trip = $request->getParam('trip');

        $truck_id = $trip['TruckNum'];

        unset($trip['TruckNum']);

        if ($edit){

            $ref = $this->db->getReference('Trucks/' . $truck_id . '/Trips/' . $trip['TripNum']);

            $_truck = $ref->getValue();

            if(is_null($_truck)) {
                $this->flash->addMessage('form_errors', ["Something went wrong."]);
                return back();
            }

            $ref->update($trip);

        }else{
            $tripsRef = $this->db->getReference('Trucks/' . $truck_id . '/Trips/');
            if(!$tripsRef->getSnapshot()->exists()){
                $newTripKey = 1;
            }else{
                $max_key = max(array_values($tripsRef->getChildKeys()));
                $newTripKey = $max_key + 1;
            }

            $trip['TripNum'] = (string)$newTripKey;
            $trip['Check'] = '';
            $ref = $this->db->getReference('Trucks/' . $truck_id . '/Trips/' . $newTripKey);
            $ref->set($trip);
        }


        if ($edit) {
            return redirect('/dashboard/trucks/' . $truck_id . '/trips/' . $trip['TripNum']);
        } else {
            return redirect('/dashboard/trucks/' . $truck_id);
        }

    }

    public function getCheck($request, $response, $args)
    {
        $filename = md5($args['trip_id'] . $args['truck_id']) . ".pdf";
        $filesystem = $this->storage->getFilesystem();

        $check_num = 7000;
        
        $truck = Truck::find($args['truck_id']);

        if(is_file("check_num.txt")){
            $check_num = @file_get_contents("check_num.txt");
        }

        
/*
        if ($filesystem->has('Checks/' . $filename)) {
            app('view')->addData(['form_errors' => ["Check for this trip was already created. Creating new check may result in wrong calculations already made."]]);
        }
*/
        
       return $this->render('trips/check', compact('truck', 'check_num'));
    }

    public function postCheck($request, $response, $args)
    {
        $fields = $request->getParam("fields");

        $check_num = $request->getParam("check_num");

        $truck_id = $args['truck_id'];

        $trip_id = $args['trip_id'];

        $truck = Truck::find($truck_id);

        $trip = $truck['Trips'][$trip_id];

        $trips_total = 0;
        $total_to_pay = 0;

        if(!empty($trip['Loads'])){
            foreach($trip['Loads'] as &$load){
                if(empty($load)) continue;
                $load['LoadTotal'] = parse_num($load['LoadTotal']);
                $trips_total += $load['LoadTotal'];
            }
        }

        $total_to_pay = $trips_total;

        $percent = parse_num($request->getParam("percent"));

        $check = $request->getParam("check");

        $dispatch_fee = ($trips_total * $percent / 100);

        $total_to_pay = $trips_total - $dispatch_fee;

        $fuel = parse_num('-'.$trip['Fuel']);

        $custom_fields[] = ["Name" => "Dispatch fee (" . $percent . "%)", "Value" => $dispatch_fee];

        $custom_fields[] = ["Name" => "Total trip's (- dispatch fee)", "Value" => $total_to_pay ];
        
		
        
        // $custom_fields[] = ["Name" => "Fuel", "Value" => $fuel];

		$fuel_total_new = 0;
        $index = 0;
        
        foreach($fields as $key => &$field){
            if(empty($field['Name'])){
                unset($fields[$key]);
                continue;
            }
            $index + $index+1;
            
            $field['Value'] = parse_num($field['Value']);
            $total_to_pay += $field['Value'];
            
            if($field['Name'] == 'TRUCK PAYMENT') {
				$name = $fields[20]['Name'];
                $text = $fields[20]['Text'];
                $fields[20]['Name'] = "$name $text";
	        }
            if($field['Name'] == 'INSURANCE'){
                $old_val = parse_num($truck['Expenses']['Insurance']);
                $truck['Expenses']['Insurance'] = "$" . ($old_val + abs($field['Value']));
                
                $name = $fields[0]['Name'];
                $text = $fields[0]['Text'];
                $fields[0]['Name'] = "$name $text";
            }
            if($field['Name'] == 'LOGBOOK'){
                $old_val = parse_num($truck['Expenses']['Logbook']);
                $truck['Expenses']['Logbook'] = "$" . ($old_val + abs($field['Value']));
            }
            if(strpos($field['Name'], "IFTA_Q") !== false){
                $old_val = parse_num($truck['Expenses'][$field['Name']]);
                $truck['Expenses'][$field['Name']] = "$" . ($old_val + abs($field['Value']));
            }
            if($field['Name'] == 'FUEL'){
                $old_val = parse_num($truck['Trips'][$trip_id]['Fuel']);
                $truck['Trips'][$trip_id]['Fuel'] = "$" . ($old_val + abs($field['Value']));
                $fuel_total_new = abs($field['Value']);
            }
        }

        $trips_total_old = parse_num($truck['Profit']["tripTotal"] ?? 0);
        $fuel_total_old = parse_num($truck['Profit']["fuelTotal"] ?? 0);
        
        $dispatch_fee_old = parse_num($truck['Profit']["dispatchFee"] ?? 0);

        $truck['Profit'] = ["tripTotal" => "$" . ($trips_total_old + $trips_total), 
        "dispatchFee" => "$" . ($dispatch_fee_old + $dispatch_fee), "fuelTotal" => "$" . ($fuel_total_old + $fuel_total_new)];


        if(isset($_GET['total_only'])){
            die($total_to_pay);
        }


        Truck::update($truck_id, $truck);
        $fields = array_merge($custom_fields, $fields);

        // $total_to_pay += $fuel;

        $loads = array_filter($trip['Loads']);
        $print_check = $check['printCheck'];

    $im = imagecreatetruecolor(900, 60);
    $white = imagecolorallocate($im, 255, 255, 255);
    $black = imagecolorallocate($im, 0, 0, 0);
    imagefilledrectangle($im, 0, 0, 900, 59, $white);

    // The text to draw
    $text = "c00{$check['num']} a123000220a 153666656852c";
    // Replace path by your own font path
    $font = __DIR__ . '/../../public/fonts/micrenc.ttf';

    // Add the text
    imagettftext($im, 40, 0, 20, 40, $black, $font, $text);

    $check_font_image = "test.png";





$f = new \NumberFormatter("en", \NumberFormatter::SPELLOUT);
$value = floatval(preg_replace('/[^\d\.]+/', '', $check['total']));
$check['total_text'] = $f->format($value);
$check['total_text'] = str_replace("point","and",$check['total_text']);


    imagepng($im, __DIR__ . "/../../public/img/temp/" . $check_font_image, 0);
    imagedestroy($im);


        $html = $this->render('check/template', compact('total_to_pay', 'truck_id', 'trip_id', 'trips_total', 'loads', 'fields', 'fuel', 'check_font_image', 'check','print_check'));

        $dompdf = new Dompdf();
        $dompdf->loadHtml($html);
        $dompdf->setPaper('A4', 'portrait');
        //$dompdf->set_option('defaultFont', 'sans-serif');
        $dompdf->set_option('defaultMediaType', 'all');
        $dompdf->set_option('isFontSubsettingEnabled', true);
        $dompdf->render();
        

        if(is_file("check_num.txt")){
            $check_num = @file_get_contents("check_num.txt");
            file_put_contents("check_num.txt", ++$check_num);
        } else {
            file_put_contents("check_num.txt", 7000);
        }

          
        $filename = md5(time()) . ".pdf";
        $output = $dompdf->output();

        $filesystem = $this->storage->getFilesystem();
        $filesystem->put(
            'Checks/' . $filename,
            $output
        );

        $trip['Check'] = $filename;

        $truck['Trips'][$trip_id] = $trip;

        Truck::update($truck_id, $truck);

        $filename = "trip_" . $args['trip_id'] . "_truck_" . $args['truck_id'] . "_invoice.pdf";
        $dompdf->stream($filename, array("Attachment" => false));
        exit(0);
        //return redirect('/dashboard/trucks/' . $truck_id . '/trips/' . $trip['TripNum']);
    }

}
