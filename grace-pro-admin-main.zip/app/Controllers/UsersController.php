<?php

namespace App\Controllers;

use App\Models\User;
use Throwable;

class UsersController extends Controller
{

    public function getIndex($request, $response)
    {
        $users = User::all();
		
        return $this->render('users/index', compact('users'));

    }
    
    public function getDetails($request, $response, $args)
    {
        $id = $args['id'];
		
        $user = $this->db->getReference('Users/' . $id)->getValue();
        

        return $this->render('users/details', compact('user'));
    }
    
    public function getEdit($request, $response, $args)
    {
		
        $id  = $args['id'];

        $ref = $this->db->getReference('Users/' . $id);
       
        $user = $ref->getValue();

        return $this->render('users/update', compact('user', 'id'));
    }

    public function getAdd($request, $response)
    {
	    
	    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
		$charactersLength = strlen($characters);
		$randomString = '';
		for ($i = 0; $i < 10; $i++) {
        	$randomString .= $characters[rand(0, $charactersLength - 1)];
    	}
    
	    $randomPass = $randomString;
	    
        return $this->render('users/update', compact('randomPass'));
    }

    public function postAdd($request, $response)
    {
        return $this->updateDetails($request);
    }

    public function getDelete($request, $response, $args)
    {
        User::remove($args['id']);

        $this->flash->addMessage('form_messages', ["Юзер был удален"]);

        return redirect("/dashboard/users");
    }

    private function updateDetails($request, $edit = false)
    {

        $user = $request->getParam('user');		

/*
		$url = 'http://195.3.205.177/GraceProWebTest/hs/mobileappexchange/counterparties/create?exchgID=939c8134-b47e-11eb-b75e-856319ff2119';

		$code = $user['code'];
		$name = $user['username'];
		$password = $user['password'];
		$email = $user['email'];
		$EDRPOU = $user['EDRPOU'];
		$address = $user['address'];
		$manager = $user['manager'];
		$phone = $user['phone'];
		$data = '
		{
  			"id": "'.$code.'",
  			"name": "'.$name.'",
  			"code_EDRPOU": "'.$EDRPOU.'",
  			"manager_email": "'.$manager.'",
  			"adress": "'.$address.'",
  			"adress2": "",
  			"phone_number": "'.$phone.'",
		}
		';

		$additional_headers = array(                                                                          
   			'Accept: application/json',
   			'Content-Type: application/json'
   		);

		$ch = curl_init($url);                                                                      
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");                                                                     
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);                                                                  
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);                                                                      
		curl_setopt($ch, CURLOPT_HTTPHEADER, $additional_headers); 
		$server_output = curl_exec ($ch);
*/



        $validator = $this->validate($user, [
            "username" => "required",
            "password" => "required",
        ]);

        if ($validator->failed()) {
            return back();
        }
        
         
         
		$load = $request->getParam('user');        

		$load['date'] = date("m.d.y"); 
		
        
		$loadsRef = $this->db->getReference('Users/' . '/' . $brand);
            
            
            if (!$loadsRef->getSnapshot()->exists()) {
                $newLoadKey = 0;
            } else {
                $keys = $loadsRef->getChildKeys();
                sort($keys);
                $newLoadKey = end($keys) + 1;
            }

            $load['id'] = (string) $newLoadKey;
            
            
            
			$ref = $this->db->getReference('/Users/' . $newLoadKey);
            

            $ref->set($load);
            
                        
            //subusers
            $subusers = [];
            
            $newLoadKey1 = 0;
            

             $subusers['subuser_id'] = (string) $newLoadKey1;
             $subusers['code'] = $load['code'];
             $subusers['name'] = $load['username'];
             $subusers['id'] = (string) $newLoadKey;
            
            
            
			$refSubusers = $this->db->getReference('/Subusers/' . $newLoadKey . '/' . $newLoadKey1);
            

            $refSubusers->set($subusers);

			 

        return redirect('/dashboard/users/');

    }
    

    
    
    public function postEdit($request, $response, $args)
    {
        return $this->updateEditDetails($request);
    }
    
    private function updateEditDetails($request)
    {        
         
		$load = $request->getParam('user');
		        		        
        $id = $load['id'];
                                    
		$ref = $this->db->getReference('Users/' . $id);

        $ref->update($load);

        return redirect('/dashboard/users/' . $id);

    }
    
    
  
    
   
}
