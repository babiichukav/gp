<?php

namespace App\Controllers;

use App\Models\News;


class NewsController extends Controller
{

    public function getIndex($request, $response)
    {
	    
        $news = News::all() ?? [];

        return $this->render('news/index', compact('news'));
    }

    public function getDetails($request, $response, $args)
    {
        $promoplace_id = $args['news_id'] ?? "";
        $camera = News::all() ?? [];

        $load = $this->db->getReference('News/' . $promoplace_id)->getValue();
        

        return $this->render('news/details', compact('load'));
    }

    public function getAdd($request, $response, $args)
    {
        $truck_id = $args['truck_id'] ?? null;
        $trip_id = $args['trip_id'] ?? null;

        return $this->render('news/update', compact('truck_id', 'trip_id'));
    }

    public function postAdd($request, $response)
    {
        return $this->updateLoadDetails($request);
    }

    public function getEdit($request, $response, $args)
    {

        $id  = $args['news_id'];

        $ref = $this->db->getReference('News/' . $id);
       
        $load = $ref->getValue();

        if (is_null($load)) {
            return redirect("/dashboard/news/");
        }

        return $this->render('news/update', compact('load', 'id'));
    }

    public function postEdit($request, $response, $args)
    {
        return $this->updateLoadDetails($request, true, $args);
    }

    public function getDelete($request, $response, $args)
    {

        $id  = $args['news_id'];

		$ref = $this->db->getReference('News/' . $id);
        $ref->remove();
        $this->flash->addMessage('form_messages', ["Новость была удалена"]);


        return redirect("/dashboard/news/");
                
    }

    private function updateLoadDetails($request, $edit = false)
    {
/*
        $validator = $this->validate($request, [
                 "load.place.place_name" => "required",
         ]);

         if ($validator->failed()) {
             return back();
         }
*/
         
         echo("<script>console.log('PHP:');</script>");
         
		$load = $request->getParam('load');
		
		if (is_uploaded_file($_FILES['load']['tmp_name']['photo'])) {
            $filesystem = $this->storage->getFilesystem();
            $stream     = fopen($_FILES['load']['tmp_name']['photo'], 'r+');
            $filename   = md5(time()) . ".png";
            $filesystem->writeStream(
                'Photos/' . $filename,
                $stream
            );
            fclose($stream);
            $load['photo'] = $filename;
        }

		       

		$load['Date'] = date("m.d.y"); 
		
		 if ($edit) {
			 

			 $id = $load['id'];
			 
			 echo("<script>console.log('PHP: " . $id . "');</script>");

                                    
			 $ref = $this->db->getReference('News/' . $id);

             $ref->update($load);


			 
			 } else {
        
			 $loadsRef = $this->db->getReference('News/');
            
            
            if (!$loadsRef->getSnapshot()->exists()) {
                $newLoadKey = 0;
            } else {
                $keys = $loadsRef->getChildKeys();
                sort($keys);
                $newLoadKey = end($keys) + 1;
            }

            $load['id'] = (string) $newLoadKey;
            
			$ref = $this->db->getReference('News/' . $newLoadKey);
            

            $ref->set($load);
			 }
        

        return redirect('/dashboard/news/');
  

    }

}
