<?php

namespace App\Controllers;

class NPController extends Controller
{

    public function getEdit($request, $response, $args)
    {
        $id = $args['id'];

        $params = $this->db->getReference('Users/' . $id . '/np')->getValue();

        return $this->render('np/update', compact('params', 'id'));
    }

    public function postEdit($request, $response, $args)
    {
        return $this->updateExpensesDetails($request, true, $args);
    }
    
    private function updateExpensesDetails($request, $edit = false, $args)
    {
		
		
        $id = $args['id'];
		
        
		$loadsRef = $this->db->getReference('Users/' . $id . '/np/');
            
            
            if (!$loadsRef->getSnapshot()->exists()) {
                $newLoadKey = 0;
            } else {
                $keys = $loadsRef->getChildKeys();
                sort($keys);
                $newLoadKey = end($keys) + 1;
            }
            

             $promocodes = $request->getParam('np');

            $promocodes['id'] = (string) $newLoadKey;
            
			$ref = $this->db->getReference('Users/' . $id . '/np/' . $newLoadKey);

            $ref->set($promocodes);    
        

        return redirect("/dashboard/users/" . $id);

    }
 
	public function getDelete($request, $response, $args)
    {
	
        $id = $args['id'];
        $np_id  = $args['np_id'];

		$ref = $this->db->getReference('Users/' . $id . '/np/' . $np_id);
        $ref->remove();
        $this->flash->addMessage('form_messages', ["Парамер товара был удален"]);


        return redirect("/dashboard/users/" . $id);
                
    }


}
