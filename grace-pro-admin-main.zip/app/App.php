<?php

namespace App;

class App
{
    private static $app = null;

    public static function getInstance()
    {
        if (null === self::$app) {
            self::$app = self::makeInstance();
        }

        return self::$app;
    }

    private static function makeInstance()
    {
        $settings = require __DIR__ . '/../app/settings.php';
        $app = new \Slim\App($settings);

        return $app;
    }
}
