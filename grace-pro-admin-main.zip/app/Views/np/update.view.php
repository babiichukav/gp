<?php $this->layout('layouts/default', [
    'title' => 'Dashboard - Edit NP #' . $id 
    ])?>
    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Новая почта</h1>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/users-white.svg" alt="" />
                    </div>
                    <h4>НП | <?=$id?></h4>
                    <div class="box__header-item box__header-item--left">
                        <a href="../../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Назад</a>
                    </div>
                </div>
                <div class="box__wrapper">
                    <?=$this->insert('partials/form-messages')?>
                                        <form action="" method="post" data-js="form" class="edit-form">

                    <div class="grid">
	                    
                    <div class="grid__item grid__item--half">
                        
                        <div class="form">
                            <div class="form__row">
                                <div class="field">
                                    <input type="text" name="np[name]" placeholder="Название" autocomplete="off" value=""/>
                                </div>
                            </div>
                            <div class="form__row">
                                <div class="field">
                                    <input type="text" name="np[city]" placeholder="Город" autocomplete="off" value=""/>
                                </div>
                            </div>
							                            
                        </div>
                    </div>
                    <div class="grid__item grid__item--half">
                        <div class="form">
                           
                            <div class="form__row">
                                <div class="field">
                                    <input type="text" name="np[numb]" placeholder="Номер отделения" autocomplete="off" value=""/>
                                </div>
                            </div>
                           
                        </div>
                    </div>
                </div>
                

                    <div class="grid__item grid__item--whole">
                            <div class="form__row">
                                <button class="btn">Сохранить</button>
                            </div>

                    </div>

                    </form>




                            

                </div>



            </div>

        </div>
 


        <?=$this->insert('partials/dashboard-nav')?>

    </div>


