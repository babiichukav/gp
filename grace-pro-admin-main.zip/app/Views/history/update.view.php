<?php $this->layout('layouts/default', [
        'title' =>  isset($user) ? 'Users - Редактировать - ' . $user["username"] : 'Users - Добавить'
    ])?>
    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <?php if(isset($user)): ?>
                <h1 class="dashboard__title">Юзер</h1>
                <?php else: ?>
                    <h1 class="dashboard__title">Юзер</h1>
                    <?php endif; ?>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/users-white.svg" alt="" />
                    </div>
                    <?php if(isset($user)): ?>
                        <h4><?=$user['username']?></h4>
                        <div class="box__header-item box__header-item--right">
                            <a href="../delete/" data-js="confirm-btn" data-message="Are you sure?" class="btn" style="background:#c33d3d;"><i class="mi mi-delete"></i></a>
                        </div>
                        <?php else: ?>
                            <h4>Добавить нового юзера</h4>
                            <?php endif; ?>
                                <div class="box__header-item box__header-item--left">
                                    <a href="../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Back</a>
                                </div>
                </div>
                <div class="box__wrapper">
                    <?=$this->insert('partials/form-messages')?>
                        <form action="" method="post" data-js="form" data-btn="form-submit">
                        <?php if(isset($user)): ?>
                            <input type="hidden" name="user[id]" value="<?=$user['id']?>"/>
                        <?php endif; ?>
                            <div class="grid">
                                <div class="grid__item grid__item--half">
	                                
	                                
	                                <?php if(isset($user)): ?>
	                                
                        <?php else: ?>
                        <div class="form">
									<div class="form__row show-hide">
                                <div class="field field__loading">
                                    <select name="user[managerID]" onchange="typeDidChange()" placeholder="Выбрать менеджера" data-js="select-truck" id="cat"> 
                                        <option selected disabled>Выбрать менеджера</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                                    <div class="form">
                                        <div class="form__row">
                                            <div class="form__row-title">Логин</div><div class="field" data-js="field">
                                                <input type="text" name="user[email]" placeholder="Логин" value="<?=$user['email'] ?? ''?>">
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="form__row-title">Телефон</div><div class="field" data-js="field">
                                                <input type="text" name="user[phone]" placeholder="Телефон" value="<?=$user['phone'] ?? ''?>">
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="form__row-title">Адрес</div><div class="field" data-js="field">
                                                <input type="text" name="user[address]" placeholder="Адрес" value="<?=$user['address'] ?? ''?>">
                                            </div>
                                        </div>


                                    </div>
                                </div>

                                <div class="grid__item grid__item--half">
                                    <div class="form">
	                                    <div class="form__row">
                                            <div class="form__row-title">ФИО</div><div class="field" data-js="field">
                                                <input type="text" name="user[username]" placeholder="ФИО" value="<?=$user['username'] ?? ''?>">
                                            </div>
                                        </div>
	                                    
                                        <div class="form__row">
                                            <div class="form__row-title">Пароль</div><div class="field" data-js="field">
                                                <input type="text" name="user[password]" placeholder="Пароль" value="<?=$user['password'] ?? $randomPass?>">
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="form__row-title">Код</div><div class="field" data-js="field">
                                                <input type="text" name="user[code]" placeholder="Код" value="<?=$user['code'] ?? time()?>">
                                            </div>
                                        </div>
                                        <div class="form__row hidden">
                                            <div class="form__row-title">Менеджер</div><div class="field" data-js="field">
                                                <input type="text" name="user[manager]" placeholder="Менеджер" id="typeName" value="<?=$user['manager'] ?? ''?>">
                                            </div>
                                        </div>
                                        
                                        <div class="form__row">
                        <div class="field">
                           <input type="text" name="user[EDRPOU]" placeholder="Код ЄДРПОУ" autocomplete="off" value="<?=$user['EDRPOU'] ?? ''?>"/>
                        </div>
                     </div>

                                    </div>
                                </div>

                            </div>
<div class="grid">
                                <div class="grid__item grid__item--whole">
<div class="form__row">
                                        <button class="btn">Save</button>
                                    </div>
                                </div>
                            </div>
                        </form>

                </div>

            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>
    
    <script>
	   function typeDidChange() {
     var catValue = document.getElementById("cat").value;  
     var catText = getSelectedText('cat');
     
     document.getElementById("typeName").value = catText;   

     } 
     
     function getSelectedText(elementId) {
    var elt = document.getElementById(elementId);

    if (elt.selectedIndex == -1)
        return null;

    return elt.options[elt.selectedIndex].text;
    
    
}

	    	    
    </script>