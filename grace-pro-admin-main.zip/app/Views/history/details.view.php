<?php $this->layout('layouts/default', ['title' => 'Dashboard - User'])?>
<div class="dashboard grid grid--wrapped">
<div class="grid__item grid__item--whole">
   <h1 class="dashboard__title">Подробнее</h1>
</div>
<div class="grid__item grid__item--whole">
   <div class="box">
      <div class="box__header">
         <div class="box__header-circle">
            <img src="/img/checks-white.svg" alt="" />
         </div>
         <h4>Заказ #<?=$user[$id]['orderNumber']?></h4>
         <div class="box__header-item box__header-item--left">
            <a href="/dashboard/products/" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Назад</a>
         </div>
<!--
         <div class="box__header-item box__header-item--right">
	         <a href="subusers/" class="btn">Сабюзеры <i class="mi mi-people-outline"></i></a>&nbsp;
             <a href="edit/" class="btn"><i class="mi mi-edit"></i></a>&nbsp;
            <a href="delete/" data-js="confirm-btn" data-message="Вы уверены?" class="btn" style="background:#c33d3d;"><i class="mi mi-delete"></i></a>
         </div>
-->
      </div>
      <div class="box__wrapper" style="padding-bottom:0;">
         <div class="grid">
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Дата</h6>
                  <span>
                  <?=($user[$id]['date'] ?? "-")?>
                  </span>
               </div>
            </div>
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Сумма</h6>
                  <span>
                  <?=($user[$id]['totalPrice'] ?? "-")?>
                  </span>
               </div>
            </div>
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Юзер</h6>
                  <span>
                  <a href="/dashboard/users/<?=($userID ?? "-")?>" class="link"><?=($userID ?? "-")?></a>   
                  </span>
               </div>
            </div>
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Тип оплаты</h6>
                  <span>
                  <?=($user[$id]['paymentType'] ?? "-")?>
                  </span>
               </div>
            </div>
         </div>
                                         
        
         <br>
         
         <hr style="height:2px;border-width:0;color:gray;background-color:gray">         
         <div class="grid__item grid__item--whole grid__item--no-gutters">
            <div class="item-info">
	            <br>
               <h6>Товары</h6>
<!--                <span><a href="np/edit/" class="btn"><i class="mi mi-add"></i></a></span> -->
            </div>
         </div>
         <div class="grid__item grid__item--whole grid__item--no-gutters">
            <?php if(empty($user[$id]['Order'])): ?>
            <span class="box__message">Нет данных</span>
            <br>
            <?php else: ?>
            <div class="table">
               <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
               <table class="table__item" id="trips-list" data-js="sortable-list">
                  <tr class="no-user-select">
                     <th class="sort" data-sort="id">#<i class="mi mi-unfold-more"></i></th>
                     <th class="sort" data-sort="vendor">Артикул<i class="mi mi-unfold-more"></i></th>
                     <th class="sort" data-sort="name">Название<i class="mi mi-unfold-more"></i></th>
                     <th class="sort" data-sort="count">Количество<i class="mi mi-unfold-more"></i></th>
                     <th class="sort" data-sort="price">Цена<i class="mi mi-unfold-more"></i></th>
                  </tr>
                  <tbody class="list">
                     <?php foreach($user[$id]['Order'] as $trip): ?>
                     <?php if(is_null($trip)) continue; ?>
                     <tr>
                        <td class="id">
                           <?=($trip['productID'] ?? "-")?>
                        </td>
                        <td class="vendor">
                           <?=($trip['vendor'] ?? "-")?>
                        </td>
                        <td class="name">
                           <?=($trip['name'] ?? "-")?>
                        </td>
                        <td class="count">
                           <?=($trip['count'] ?? "-")?>
                        </td>
                        <td class="price">
                           <?=($trip['price'] ?? "-")?>
                        </td>
                        <!--
                        <td class="money-note">
 	                        <a href="/dashboard/users/<?=$user['id']?>/np/<?=$trip['id']?>/delete/" class="link">удалить</a>                        
 	                       </td>
-->
                          

                     </tr>
                     <?php endforeach; ?>
                  </tbody>
               </table>
            </div>
            <?php endif; ?>
         </div>    
         
         
         
         
           
         
         
         
              
   </div>

   <?=$this->insert('partials/dashboard-nav')?>
</div>