<?php $this->layout('layouts/default', ['title' => 'Dashboard - Users'])?>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Заказы</h1>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/checks-white.svg" alt="" />
                    </div>
                    <h4>История заказов</h4>
<!--
                    <div class="box__header-item box__header-item--right">
	                    <a href="https://gracepro.shatk.dev/dashboard/managers/" class="btn">Менеджеры <i class="mi mi-people"></i></a>
                        <a href="add/" class="btn"><i class="mi mi-add"></i></a>
                    </div>
-->
                    <div class="box__header-item box__header-item--left">
                        <div class="field">
                            <input id="list-search" type="text" placeholder="Поиск" autocomplete="off" />
                        </div>
                    </div>
                </div>
                <?=$this->insert('partials/form-messages')?>
                    <?php if(empty($users)): ?>
                        <span class="box__message">Нет данных для отображения</span>
                        <?php else: ?>

                            <div class="table">
                                <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
                                <table class="table__item" id="companies-list" data-js="sortable-list">
                                    <tr class="no-user-select">
	                                    <th class="sort" data-sort="id">ID заказа<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="date">Дата<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="totalPrice">Сумма<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="paymentType">Тип оплаты<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="typeOfUser">Тип юзера<i class="mi mi-unfold-more"></i></th> 
                                        <th class="sort" data-sort="managerUsername">Менеджер<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="username">Контрагент<i class="mi mi-unfold-more"></i></th>                                        
                                        
                                        <th>&nbsp;</th> 
                                    </tr>
                                    <tbody class="list">
                                        <?php foreach($users as $userID => $user) : ?>
                                            <?php if(is_null($user)) continue; ?>
                                            <?php foreach($user as $key => $value) : ?>
                                            <tr>
	                                            <td class="id">
                                                    <?=($key ?? '-')?>
                                                </td>

                                                <td class="date">
                                                    <?=($value['date'] ?? '-')?>
                                                </td>
                                                <td class="totalPrice">
                                                    <?=($value['totalPrice']  ?? '-')?>
                                                </td>
                                                <td class="paymentType">
                                                    <?=($value['paymentType']  ?? '-')?>
                                                </td>
                                                <td class="typeOfUser">
                                                    <?=($value['typeOfUser']  ?? '-')?>
                                                </td>

                                                <td class="managerUsername">
                                                    <?=($value['managerUsername']  ?? '-')?>
                                                </td>

                                                <td class="username">
                                                    <?=($value['username']  ?? '-')?>
                                                </td>
                                                
                                                

                                                
                                                
<!--
                                                <td class="email">
                                                    <?=($user['email'] ?? '-')?>
                                                </td>
                                                <td class="ordersCount">
                                                    <?=($user['manager'] ?? '-')?>
                                                </td>
-->
                                                  <td><a href="<?=$userID?>/<?=$key?>/" class="link">Подробнее</a></td> 

                                            </tr>
                                            <?php endforeach; ?>
                                            <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?>

            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>
