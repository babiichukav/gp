<?php $this->layout('layouts/default', ['title' => 'Page Not Found'])?>

    <style>
        .box__header {
            padding-top: 40px;
        }
    </style>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Page Not Found</h1>
        </div>

    </div>