<?php $this->layout('layouts/default', [ 'title' => isset($load) ? 'Dashboard - Edit News Details' : 'Dashboard - Add News'  ]) ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<div class="dashboard grid grid--wrapped">
   <div class="grid__item grid__item--whole">
      <h1 class="dashboard__title">Новости</h1>
   </div>
   <div class="grid__item grid__item--whole">
      <div class="box">
         <div class="box__header">
            <div class="box__header-circle">
               <img src="/img/news.svg" alt="" />
            </div>
            <?php if(isset($load)): ?>
            <h4>Редактировать новость #<?=$load['id']?></h4>
            <div class="box__header-item box__header-item--left">
               <?php if(!empty($trip_id)): ?>
               <a href="../../../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Назад</a>
               <?php else: ?>
               <a href="../../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Назад</a>
               <?php endif; ?>
            </div>
            <div class="box__header-item box__header-item--right">
               <a href="../delete/" data-js="confirm-btn" data-message="Вы уверены?" class="btn" style="background:#c33d3d;"><i class="mi mi-delete"></i></a>
            </div>
            <?php else: ?>
            <h4>Добавить новость</h4>
            <div class="box__header-item box__header-item--left">
               <a href="../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Назад</a>
            </div>
            <?php endif; ?>
         </div>
         <div class="box__wrapper">
            <?=$this->insert('partials/form-messages')?>
            <form action="" enctype="multipart/form-data" method="post" data-js="form" class="<?=(isset($load) ? 'edit-form' : '')?>">
               <div class="grid">
                  <div class="grid__item grid__item--half">
                     <div class="form__row">
                        <div class="field">
                           <input type="text" name="load[title]" placeholder="Заголовок" autocomplete="off" value="<?=$load['title'] ?? ''?>"/>
                        </div>
                     </div>
                     <div class="form__row">
                        <div class="field">
                           <textarea placeholder="Новость" name="load[body]"><?=$load['body'] ?? ''?></textarea>
                        </div>
                     </div>
                     <div class="form__row hidden">
                        <div class="field">
                           <textarea placeholder="Новость" name="load[id]"><?=$load['id'] ?? ''?></textarea>
                        </div>
                     </div>
                  </div>
                  <div class="grid__item grid__item--half">
                     <div class="form__row">
                        <div class="field">
                           <input type="text" placeholder="Name" value="Фото" autocomplete="off" readonly />
                           <input type="file" name="load[photo]" placeholder="Фото" accept=".png" autocomplete="off" value="<?=$load['photo'] ?? ''?>" />
                        </div>
                     </div>
                  </div>
                  <!--                     <hr style="height:2px;border-width:0;color:gray;background-color:gray"> -->
                  <br>
                  <div class="grid__item grid__item--whole">
                     <center>
                        <br>
                        <div class="form__row"><button class="btn">Сохранить</button></div>
                     </center>
                  </div>
               </div>
            </form>
         </div>
      </div>
   </div>
   <?=$this->insert('partials/dashboard-nav')?> 
</div>