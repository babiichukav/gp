<?php $this->layout('layouts/default', [ 'title' => isset($load) ? 'Dashboard - Edit News Details' : 'Dashboard - Add News'  ]) ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<div class="dashboard grid grid--wrapped">
   <div class="grid__item grid__item--whole">
      <h1 class="dashboard__title">Новости</h1>
   </div>
   <div class="grid__item grid__item--whole">
      <div class="box">
         <div class="box__header">
            <div class="box__header-circle">
               <img src="/img/news.svg" alt="" />
            </div>
            <?php if(isset($load)): ?>
            <h4>Редактировать процедуру #<?=$load['id']?></h4>
            <div class="box__header-item box__header-item--left">
               <?php if(!empty($trip_id)): ?>
               <a href="../../../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Назад</a>
               <?php else: ?>
               <a href="../../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Назад</a>
               <?php endif; ?>
            </div>
            <div class="box__header-item box__header-item--right">
               <a href="../delete/" data-js="confirm-btn" data-message="Вы уверены?" class="btn" style="background:#c33d3d;"><i class="mi mi-delete"></i></a>
            </div>
            <?php else: ?>
            <h4>Добавить процедуру</h4>
            <div class="box__header-item box__header-item--left">
               <a href="../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Назад</a>
            </div>
            <?php endif; ?>
         </div>
         <div class="box__wrapper">
            <?=$this->insert('partials/form-messages')?>
            <form action="" enctype="multipart/form-data" method="post" data-js="form" class="<?=(isset($load) ? 'edit-form' : '')?>">
               <div class="grid">
	               
                  <div class="grid__item grid__item--half">
                        <div class="form__row">
                           <div class="field">
                              <select name="load[brandID]" onchange="catDidChange()" id="cat">
                                 <option value="" selected>Бренд</option>
                                 <option value='1'>Dr. Sorbie</option>
                                 <option value='2'>Brae</option>
                                 <option value='3'>Tempting</option>
                              </select>
                           </div>
                    </div>
                     <div class="form__row">
                        <div class="field">
                           <input type="text" name="load[title]" placeholder="Заголовок" autocomplete="off" value="<?=$load['title'] ?? ''?>"/>
                        </div>
                     </div>
                     <div class="form__row">
                        <div class="field">
                           <textarea placeholder="Описание" name="load[body]"><?=$load['body'] ?? ''?></textarea>
                        </div>
                     </div>
                     <div class="form__row hidden">
                        <div class="field">
                           <input type="text" name="load[brand]" placeholder="Бренд" id="brand" autocomplete="off" value="<?=$load['brand'] ?? ''?>"/>
                        </div>
                     </div>
                     <div class="form__row hidden">
                        <div class="field">
                           <input type="text" name="load[id]" placeholder="id" autocomplete="off" value="<?=$load['id'] ?? ''?>"/>
                        </div>
                     </div>
                     <div class="form__row">
                        <div class="field">
                           <input type="text" name="load[videoURL]" placeholder="YouTube Link" autocomplete="off" value="<?=$load['videoURL'] ?? ''?>"/>
                        </div>
                     </div>
                  </div>
                  <div class="grid__item grid__item--half">
	                  <div class="form__row">
                           <div class="field">
                              <select name="load[typeContent]">
                                 <option value="photo" selected>Photo</option>
                                 <option value='video'>Video</option>
                              </select>
                           </div>
                           <br>
                           <div class="form__row">
                        <div class="field">
                           <input type="text" name="load[title]" placeholder="Заголовок (Укр)" autocomplete="off" value="<?=$load['title_ua'] ?? ''?>"/>
                        </div>
                     </div>
                     <div class="form__row">
                        <div class="field">
                           <textarea placeholder="Описание (Укр)" name="load[body]"><?=$load['body_ua'] ?? ''?></textarea>
                        </div>
                     </div>
                           
                     <div class="form__row">
                        <div class="field">
                           <input type="text" placeholder="Name" value="Фото" autocomplete="off" readonly />
                           <input type="file" name="load[photo]" placeholder="Фото" accept=".png" autocomplete="off" value="<?=$load['photo'] ?? ''?>" />
                        </div>
                     </div>
                  </div>
                  <br>
                  
               </div>
               <div class="grid__item grid__item--whole">
                     <center>
                        <br>
                        <div class="form__row"><button class="btn">Сохранить</button></div>
                     </center>
                  </div>
            </form>
         </div>
      </div>
   </div>
   
   
   <?=$this->insert('partials/dashboard-nav')?> 
</div>

<script>
function catDidChange() {
   	
     var catValue = document.getElementById("cat").value;  
     var catText = getSelectedText('cat');
     
     document.getElementById("brand").value = catText;         
     
   
    }
    
    function getSelectedText(elementId) {
    var elt = document.getElementById(elementId);

    if (elt.selectedIndex == -1)
        return null;

    return elt.options[elt.selectedIndex].text;
    
    
}
    </script>