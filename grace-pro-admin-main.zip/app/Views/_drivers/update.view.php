<?php $this->layout('layouts/default', [
    'title' => isset($driver) ? 'Dashboard - Edit Driver - ' . $driver['Name'] : 'Dashboard - Add Driver'
    ])?>
    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <?php if(isset($driver)): ?>
                <h1 class="dashboard__title">Edit Driver</h1>
                <?php else: ?>
                    <h1 class="dashboard__title">Add Driver</h1>
                    <?php endif; ?>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/driver-white.svg" alt="" />
                    </div>
                    <?php if(isset($driver)): ?>
                        <h4><?=$driver['Name']?></h4>
                        <?php if($_SESSION['user'] == "admin"): ?> 
                        <div class="box__header-item box__header-item--right">
                            <a href="../delete/" data-js="confirm-btn" data-message="Are you sure? All driver related data will be also deleted." class="btn" style="background:#c33d3d;"><i class="mi mi-delete"></i></a>
                        </div>
                        <?php endif; ?> 
                        <?php else: ?>
                            <h4>Add new driver</h4>
                            <?php endif; ?>
                                <div class="box__header-item box__header-item--left">
                                    <a href="../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Back</a>
                                </div>
                </div>
                <div class="box__wrapper">
                    <?=$this->insert('partials/form-messages')?>
                        <form action="" enctype="multipart/form-data" method="post" data-js="form" class="<?=(isset($driver) ? 'edit-form' : '')?>">
                            <div class="grid">
                                <div class="grid__item grid__item--half">

                                    <div class="form">
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="text" name="driver[Name]" placeholder="Name" autocomplete="off" value="<?=$driver['Name'] ?? ''?>" <?=(isset($driver) ? 'readonly' : '')?>/>
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="text" name="driver[Phone]" placeholder="Mobile" autocomplete="off" value="<?=$driver['Phone'] ?? ''?>" />
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="field">
                                                <?php $options = ["true"=>"Active", "false"=>"Inactive"]; ?>
                                                    <select name="driver[active]" placeholder="Active">
                                                        <?php foreach($options as $value => $option): ?>
                                                            <option value="<?=$value?>" <?=(isset($driver) && $value == $driver['active']) ? 'selected' : ''?>>
                                                                <?=$option?>
                                                            </option>
                                                            <?php endforeach; ?>
                                                    </select>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="grid__item grid__item--half">

                                    <div class="form">
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="text" data-js="datepicker" name="driver[License]" placeholder="License" autocomplete="off" value="<?=$driver['License'] ?? ''?>" />
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="text" data-js="datepicker" name="driver[MedCard]" placeholder="MedCard" autocomplete="off" value="<?=$driver['MedCard'] ?? ''?>" />
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="file" name="driver[PDF]" placeholder="PDF" autocomplete="off" value="<?=$driver['PDF'] ?? ''?>" />
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="grid__item grid__item--whole">
                                    <div class="form__row">
                                        <button class="btn">Save</button>
                                    </div>

                                </div>
                            </div>

                        </form>

                </div>

            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>