<?php $this->layout('layouts/default', ['title' => 'Dashboard - Drivers'])?>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Drivers</h1>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/driver-white.svg" alt="" />
                    </div>
                    <h4>Drivers</h4>
                    <div class="box__header-item box__header-item--right">
                        <a href="add/" class="btn"><i class="mi mi-add"></i></a>
                    </div>
                    <div class="box__header-item box__header-item--left">
                        <div class="field">
                            <input id="list-search" type="text" placeholder="Search" autocomplete="off" />
                        </div>
                    </div>
                </div>
                <?=$this->insert('partials/form-messages')?>
                    <?php if(empty($drivers)): ?>
                        <span class="box__message">No drivers</span>
                        <?php else: ?>

                            <div class="table">
                                <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
                                <table class="table__item" id="drivers-list" data-js="sortable-list">
                                    <tr class="no-user-select">
                                        <th class="sort" data-sort="name">Name<i class="mi mi-unfold-more"></i></th>
                                        <th>Phone</th>
                                        <th class="sort" data-sort="license">License<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="medcard">Med card<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="active">Active<i class="mi mi-unfold-more"></i></th>
                                        <th>PDF</th>
                                        <th>&nbsp;</th>
                                    </tr>
                                    <tbody class="list">
                                        <?php foreach($drivers as $driver): ?>
                                            <?php $driver['slug'] = slugify($driver['Name']) ?>
                                                <tr>
                                                    <td class="name">
                                                        <?=($driver['Name'] ?? '-')?>
                                                    </td>
                                                    <td class="phone">
                                                        <?=($driver['Phone'] ?? '-')?>
                                                    </td>
                                                    <td class="license" data-type="date" <?=($driver['active'] ? 'data-due-to' : '')?>>
                                                        <?=($driver['License'] ?? '-')?>
                                                    </td>
                                                    <td class="medcard" data-type="date" <?=($driver['active'] ? 'data-due-to' : '')?>>
                                                        <?=($driver['MedCard'] ?? '-')?>
                                                    </td>
                                                    <td class="active">
                                                        <?=($driver['active'] ? 'Yes' : 'No')?>
                                                    </td>
                                                    <td class="pdf">
                                                        <?php if(!empty($driver['PDF'])): ?>
                                                            <a href="/dashboard/download/drivers/<?=$driver['PDF']?>/?filename=<?=$driver['Name']?>.pdf" class="link">Download</a>
                                                            <?php else: ?>
                                                                -
                                                                <?php endif; ?>
                                                    </td>
                                                    <td><a href="<?=$driver['slug']?>/" class="link">Details</a></td>
                                                </tr>
                                                <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?>

            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>
