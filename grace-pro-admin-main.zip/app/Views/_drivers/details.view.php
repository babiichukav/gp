<?php $this->layout('layouts/default', ['title' => 'Dashboard - Driver Details - ' . $driver['Name']])?>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Driver Details</h1>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/driver-white.svg" alt="" />
                    </div>
                    <h4><?=$driver['Name']?></h4>
                    <div class="box__header-item box__header-item--left">
                        <a href="../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Back</a>
                    </div>
                     
                    <div class="box__header-item box__header-item--right">
                        <a href="edit/" class="btn"><i class="mi mi-edit"></i></a>&nbsp;
                        <?php if($_SESSION['user'] == "admin"): ?> 
                        <a href="delete/" data-js="confirm-btn" data-message="Are you sure? All driver related data will be also deleted." class="btn" style="background:#c33d3d;"><i class="mi mi-delete"></i></a>
						<?php endif; ?> 
                    </div>
                     
                </div>
                <div class="box__wrapper" style="padding-bottom:0;">

                    <div class="grid__item grid__item--one-quarter">
                        <div class="item-info">
                            <h6>Phone</h6>
                            <span><?=$driver['Phone']?></span>
                        </div>
                        <div class="item-info">
                            <h6>Active</h6>
                            <span><?=($driver['active'] ? 'Yes' : 'No')?></span>
                        </div>
                    </div>

                    <div class="grid__item grid__item--one-quarter">
                        <div class="item-info">
                            <h6>License</h6>
                            <span><?=$driver['License']?></span>
                        </div>
                        <div class="item-info">
                            <h6>MedCard</h6>
                            <span><?=$driver['MedCard']?></span>
                        </div>
                    </div>

                    <div class="grid__item grid__item--one-quarter">
                        <div class="item-info">
                            <h6>PDF</h6>
                            <span>
                            <?php if(!empty($driver['PDF'])): ?>
                            <a href="/dashboard/download/drivers/<?=$driver['PDF']?>/?filename=<?=$driver['Name']?>.pdf" class="link">Download</a>
                            <?php else: ?>
                            -
                            <?php endif; ?>
                        </span>
                        </div>
                    </div>

                </div>

            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>