<?php $this->layout('layouts_auth/default', ['title' => 'Sign In'])?>
<style>
.box--login{
    position: absolute;
    min-width: 420px;
    top: 40%;
    left: 50%;
    transform: translateX(-50%) translateY(-50%);
}
.box--login .btn{
    width: 100%;
}
.mobile .box--login{
    top: 20%;
    min-width: 90%;
    transform: translateX(-50%);
}
</style>



<div class="box box--login">
    <div class="box__header">
        <div class="box__header-circle">
            <img src="http://dashboard.ukrtransport.net/img/truck-white.svg" alt=""/>
        </div>
        <h4>Sign in</h4>
    </div>
    <div class="box__wrapper">
            <div class="form">
                <div class="form__row">
                    <div class="field">
                        <input type="text" id="phoneNumber" placeholder="Phone" autocomplete="off" value="+15037244964"/>
                    </div>
                </div>
                <div class="form__row">
                    <div class="field">
                        <input type="password" id="code" placeholder="Code" autocomplete="off"/>
                    </div>
                </div>

					<button class="btn" onclick="submitPhoneNumberAuth()">Request code</button>
					</br></br>
                    <button class="btn" onclick="submitPhoneNumberAuthCode()">Validate code</button>
					</br>
					<center><div id="recaptcha-container"></div></center>

            </div>


    </div>
</div>

    

    <!-- Add the latest firebase dependecies from CDN -->
    <script src="https://www.gstatic.com/firebasejs/6.3.3/firebase-app.js"></script>
    <script src="https://www.gstatic.com/firebasejs/6.3.3/firebase-auth.js"></script>

    <script>
      // Paste the config your copied earlier
      const firebaseConfig = {
  apiKey: "AIzaSyAmwjhyck-yXLDz4j01MOlmkOQdJdpzLf8",
  authDomain: "trucksappus.firebaseapp.com",
  databaseURL: "https://trucksappus.firebaseio.com",
  projectId: "trucksappus",
  storageBucket: "trucksappus.appspot.com",
  messagingSenderId: "243491565108",
  appId: "1:243491565108:web:76c7a6f17950bcde60e461"
};

      firebase.initializeApp(firebaseConfig);

      // Create a Recaptcha verifier instance globally
      // Calls submitPhoneNumberAuth() when the captcha is verified
      window.recaptchaVerifier = new firebase.auth.RecaptchaVerifier(
        "recaptcha-container",
        {
          size: "normal",
          callback: function(response) {
            submitPhoneNumberAuth();
          }
        }
      );

      // This function runs when the 'sign-in-button' is clicked
      // Takes the value from the 'phoneNumber' input and sends SMS to that phone number
      function submitPhoneNumberAuth() {
        var phoneNumber = document.getElementById("phoneNumber").value;
        var appVerifier = window.recaptchaVerifier;
        firebase
          .auth()
          .signInWithPhoneNumber(phoneNumber, appVerifier)
          .then(function(confirmationResult) {
            window.confirmationResult = confirmationResult;
          })
          .catch(function(error) {
            //alert(error);
          });
      }

      // This function runs when the 'confirm-code' button is clicked
      // Takes the value from the 'code' input and submits the code to verify the phone number
      // Return a user object if the authentication was successful, and auth is complete
      function submitPhoneNumberAuthCode() {
        var code = document.getElementById("code").value;
        confirmationResult
          .confirm(code)
          .then(function(result) {
            var user = result.user;
            //alert(user);
          })
          .catch(function(error) {
            //alert(error);
          });
      }

      //This function runs everytime the auth state changes. Use to verify if the user is logged in
      firebase.auth().onAuthStateChanged(function(user) {
        if (user) {
	        window.location.href = 'http://dashboard.ukrtransport.net/dashboard/products/';
        } else {
         // alert("USER NOT LOGGED IN");
        }
      });
    </script>
  </body>
</html>