<?php $this->layout('layouts/default', [
   'title' => 'Dashboard - Edit PromoPlace #' . $place_id . ' promocode'
   ])?>
   
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAsiWkx8ntjBh86x7yT2jNn39omoSdRKcM"></script>
<script src="https://unpkg.com/location-picker/dist/location-picker.min.js"></script>
<style>
   #map {
   width: 100%;
   height: 350px;
   }
</style>
   
<div class="dashboard grid grid--wrapped">
   <div class="grid__item grid__item--whole">
      <h1 class="dashboard__title">Промокоды</h1>
   </div>
   <div class="grid__item grid__item--whole">
      <div class="box">
         <div class="box__header">
            <div class="box__header-circle">
               <img src="/img/expenses-white.svg" alt="" />
            </div>
            <h4>Промоместо #<?=$place_id?> | Другие адреса</h4>
            <div class="box__header-item box__header-item--left">
               <a href="../../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Back</a>
            </div>
         </div>
         <div class="box__wrapper">
            <?=$this->insert('partials/form-messages')?>
            <form action="" method="post" data-js="form" class="edit-form">
               <div class="grid">
                  <div class="grid__item grid__item--half">
                     <div class="form">
                        <div class="form__row">
                           <div class="field">
                              <input type="text" name="addresses[address]" placeholder="Адрес" autocomplete="off" value=""/>
                           </div>
                        </div>
                       <div class="form__row hidden">
                           <div class="field">
                              <input type="text" name="addresses[lat]" id="lat" placeholder="lat" autocomplete="off" value=""/>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="grid__item grid__item--half">
                     <div class="form">
                         <div class="form__row">
                           <div class="field">
                              <input type="text" name="addresses[phone]" placeholder="Телефон" autocomplete="off" value=""/>
                           </div>
                        </div>
                        <div class="form__row hidden">
                           <div class="field">
                              <input type="text" name="addresses[lon]" id="lon" placeholder="lon" autocomplete="off" value=""/>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
               <br><div id="map"></div><br>
               <div class="grid__item grid__item--whole">
                  <div class="form__row">
                     <center><button class="btn">Сохранить</button></center>
                  </div>
               </div>
         </div>
         </form>
      </div>
   </div>
</div>
<script>
   // Get element references
   var confirmBtn = document.getElementById('confirmPosition');
   var onClickPositionView = document.getElementById('onClickPositionView');
   var onIdlePositionView = document.getElementById('onIdlePositionView');
   
   var latTF = document.getElementById('lat');
   var lonTF = document.getElementById('lon');
   
   // Initialize locationPicker plugin
   var lp = new locationPicker('map', {
     lat: 50.4547,
     lng: 30.5238, // You can omit this, defaults to true
   }, {
     zoom: 12 // You can set any google map options here, zoom defaults to 15
   });
   
   // Listen to map idle event, listening to idle event more accurate than listening to ondrag event
   google.maps.event.addListener(lp.map, 'idle', function (event) {
     // Get current location and show it in HTML
     var location = lp.getMarkerPosition();
     latTF.value = location.lat;
     lonTF.value = location.lng;
   
   });
</script> 
<?=$this->insert('partials/dashboard-nav')?>
</div>