<?php $this->layout('layouts/default', ['title' => 'Dashboard - Export'])?>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Export</h1>
        </div>
        <div class="grid__item grid__item--whole">
            <div class="box">
                <div class="box__wrapper">
                    <form action="" method="post">
                        <button class="btn">Create backup</button>
                    </form>
                    <small style="display: block;margin: 14px 2px;">A copy of created backup will be send to <?=EXPORT_BACKUP_EMAIL?></small>
                    <br/>
                    <?php foreach ($files as $file): ?>
                        <a href="<?=str_replace(".json", "", $file)?>" class="link"><?=$file?></a><br/>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>