<?php $this->layout('layouts/default', [
        'title' =>  isset($user) ? 'Users - Edit User - ' . $user["username"] : 'Users - Add User'
    ])?>
    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <?php if(isset($user)): ?>
                <h1 class="dashboard__title">Edit User</h1>
                <?php else: ?>
                    <h1 class="dashboard__title">Add User</h1>
                    <?php endif; ?>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/users-white.svg" alt="" />
                    </div>
                    <?php if(isset($user)): ?>
                        <h4><?=$user['username']?></h4>
                        <div class="box__header-item box__header-item--right">
                            <a href="../delete/" data-js="confirm-btn" data-message="Are you sure?" class="btn" style="background:#c33d3d;"><i class="mi mi-delete"></i></a>
                        </div>
                        <?php else: ?>
                            <h4>Add new user</h4>
                            <?php endif; ?>
                                <div class="box__header-item box__header-item--left">
                                    <a href="../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Back</a>
                                </div>
                </div>
                <div class="box__wrapper">
                    <?=$this->insert('partials/form-messages')?>
                        <form action="" method="post" data-js="form" data-btn="form-submit">
                        <?php if(isset($user)): ?>
                            <input type="hidden" name="user[id]" value="<?=$user['id']?>"/>
                        <?php endif; ?>
                            <div class="grid">
                                <div class="grid__item grid__item--half">

                                    <div class="form">
                                        <div class="form__row">
                                            <div class="form__row-title">Username</div><div class="field" data-js="field">
                                                <input type="text" name="user[username]" placeholder="Username" value="<?=$user['username'] ?? ''?>"">
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="grid__item grid__item--half">
                                    <div class="form">
                                        <div class="form__row">
                                            <div class="form__row-title">Password</div><div class="field" data-js="field">
                                                <input type="text" name="user[password]" placeholder="Password" value="<?=$user['password'] ?? ''?>"">
                                            </div>
                                        </div>

                                    </div>
                                </div>

                            </div>
<div class="grid">
                                <div class="grid__item grid__item--whole">
<div class="form__row">
                                        <button class="btn">Save</button>
                                    </div>
                                </div>
                            </div>
                        </form>

                </div>

            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>