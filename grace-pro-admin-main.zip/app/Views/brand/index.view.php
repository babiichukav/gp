<?php $this->layout('layouts/default', ['title' => 'Dashboard - Users'])?>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Бренд</h1>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/load-white.svg" alt="" />
                    </div>
                    <h4>Бренд</h4>

                    <div class="box__header-item box__header-item--right">
	                    <a href="procedures" class="btn">ПРОЦЕДУРЫ <i class="mi mi-hot-tub"></i></a>
                        <a href="buyTogether" class="btn">Покупают вместе <i class="mi mi-add-shopping-cart"></i></a>
                    </div>

                    <div class="box__header-item box__header-item--left">
                        <div class="field">
                            <input id="list-search" type="text" placeholder="Поиск" autocomplete="off" />
                        </div>
                    </div>
                </div>
                <?=$this->insert('partials/form-messages')?>
                    <?php if(empty($products)): ?>
                        <span class="box__message">Нет данных для отображения</span>
                        <?php else: ?>

                            <div class="table">
                                <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
                                <table class="table__item" id="companies-list" data-js="sortable-list">
                                    <tr class="no-user-select">
	                                    <th class="sort" data-sort="vendor">Артикул<i class="mi mi-unfold-more"></i></th>
	                                    <th class="sort" data-sort="type">Тип<i class="mi mi-unfold-more"></i></th>

                                        <th class="sort" data-sort="name">Название<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="price">Цена<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="isTop">ТОП<i class="mi mi-unfold-more"></i></th>
                                        <th>&nbsp;</th>

                                    </tr>
                                    <tbody class="list">
                                        <?php foreach($products as $prod): ?>
                                            <?php if(is_null($prod)) continue; ?>
                                            <tr>
                                                <td class="vendor">
                                                    <?=($prod['vendor'] ?? '-')?>
                                                </td>
                                                 <td class="type">
                                                    <?=($prod['typeName'] ?? '-')?>
                                                </td>
                                                <td class="name">
                                                    <?=($prod['name'] ?? '-')?>
                                                </td>
                                               
                                                <td class="price" >
                                                    <?=($prod['price'] ?? '-')?>
                                                </td>
                                                
                                                <td class="isTop" >
                                                     <?php if($prod['isTop'] === "1"): ?>
                                                    <a href="<?=$prod['id']?>/istop/<?=$prod['brand']?>/reject/" class="link">Да</a>
                                                    <?php else: ?>
                                                    <a href="<?=$prod['id']?>/istop/<?=$prod['brand']?>/accept/" class="link">Нет</a>
                                                    <?php endif; ?>
                                                 </td>
                                                
                                                 <td><a href="<?=$prod['id']?>/" class="link">Подробнее</a></td>
                                            </tr>
                                            <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?>

            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>
