<?php $this->layout('layouts/default', [ 'title' => isset($load) ? 'Dashboard - Edit Product Details' : 'Dashboard - Add Product'  ]) ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="https://unpkg.com/location-picker/dist/location-picker.min.js"></script>

<script>
 function getTopPlaces() {
	   
 	var tops = document.getElementById("tops_id");	
	
	//!!!!!!по айди TF получаем с ниго данные и настраиваем выпадайки!!!!!!!!
	
	setTimeout(function() {
	

//    alert(1111111)
     
/*
     if (tops.value.includes("0")) {
   		  document.getElementById("top00").checked = true;
     } 
     if (tops.value.includes("1")) {
	     document.getElementById("top11").checked = true;
     } 
     if (tops.value.includes("2")) {
   	 	document.getElementById("top22").checked = true;
     }
*/
     
    


	}, 800);
	

    }

getTopPlaces()

</script>
<div class="dashboard grid grid--wrapped">
   <div class="grid__item grid__item--whole">
      <h1 class="dashboard__title">Товары</h1>
   </div>
   <div class="grid__item grid__item--whole">
      <div class="box">
         <div class="box__header">
            <div class="box__header-circle">
               <img src="/img/load-white.svg" alt="" />
            </div>
            <?php if(isset($load)): ?>
            <h4>Редактировать товар #<?=$load['id']?></h4>
            <div class="box__header-item box__header-item--left">
               <?php if(!empty($trip_id)): ?>
               <a href="../../../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Назад</a>
               <?php else: ?>
               <a href="../../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Назад</a>
               <?php endif; ?>
            </div>
            <div class="box__header-item box__header-item--right">
               <a href="../delete/" data-js="confirm-btn" data-message="Вы уверены?" class="btn" style="background:#c33d3d;"><i class="mi mi-delete"></i></a>
            </div>
            <?php else: ?>
            <h4>Добавить новый товар</h4>
            <div class="box__header-item box__header-item--left">
               <a href="../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Назад</a>
            </div>
            <?php endif; ?>
         </div>
         <div class="box__wrapper">
            <?=$this->insert('partials/form-messages')?>
            <form action="" enctype="multipart/form-data" method="post" data-js="form" class="<?=(isset($load) ? 'edit-form' : '')?>">
               <div class="grid">
                  <div class="grid__item grid__item--half">
	                  <?php if(isset($load)): ?>
	                  <?php else: ?>
	                                       
                     <div class="form" id="editToHide1">
                        <div class="form__row">
                           <div class="field">
                              <select name="load[brand]" onchange="catDidChange()" id="cat">
                                 <option value="" selected>Бренд</option>
                                 <option value='1'>Dr. Sorbie</option>
                                 <option value='2'>Brae</option>
                                 <option value='3'>Tempting</option>
                                 <option value='4'>C этим покупают</option>
                              </select>
                           </div>
                        </div>
                     </div>
                    
                     <br>
                     <?php endif; ?>
					 <!-- техническая часть -->
					 <div class="form__row hidden">
                        <div class="field">
                           <input type="text" id="catDB" name="load[brand]" placeholder="Название Категории" autocomplete="off" value="<?=$load['brand'] ?? ''?>"/>
                        </div>
                     </div>
                     <div class="form__row hidden">
                        <div class="field">
                           <input type="text" id="typeID" name="load[typeID]" placeholder="Название Типа" autocomplete="off" value="<?=$load['typeID'] ?? ''?>"/>
                        </div>
                     </div>
                     
                     <div class="form__row hidden">
                        <div class="field">
                           <input type="text" id="typeName" name="load[typeName]" placeholder="Название Типа" autocomplete="off" value="<?=$load['typeName'] ?? ''?>"/>
                        </div>
                     </div>					 
                     <div class="form__row">
                        <div class="field">
                           <input type="text" name="load[name]" placeholder="Название" autocomplete="off" value="<?=$load['name'] ?? ''?>"/>
                        </div>
                     </div>
                     <div class="form__row">
                        <div class="field">
                           <input type="text" name="load[structure]" placeholder="Состав" autocomplete="off" value="<?=$load['structure'] ?? ''?>"/>
                        </div>
                     </div>
                     <div class="form__row">
                        <div class="field">
                           <input type="text" name="load[vendor]" placeholder="Артикул" autocomplete="off" value="<?=$load['vendor'] ?? ''?>"/>
                        </div>
                     </div>
                    
                   
                     
                     <div class="form__row hidden">
                        <div class="field">
                           <input type="text" name="load[id]" autocomplete="off" value="<?=$load['id'] ?? ''?>"readonly/>
                        </div>
                     </div>
                     
                     <div class="form__row hidden">
                        <div class="field">
                           <input type="text" name="load[isTop]" autocomplete="off" value="0" readonly/>
                        </div>
                     </div>
                    
                     
                  </div>
                  
                  <div class="grid__item grid__item--half">
	                  <?php if(isset($load)): ?>
	                  <?php else: ?>
	                  <div class="form"  id="editToHide3">
                        <div class="form__row">
                           <div class="field">
                              <select name="load[type]" onchange="typeDidChange()" id="type">
                                 <option value="" selected>Тип</option>
                              </select>
                           </div>
                        </div>
                     </div>
                     <br>
                     <?php endif; ?>
                     <div class="form__row">
                        <div class="field">
                           <input type="text" name="load[name_ua]" placeholder="Название (Укр)" autocomplete="off" value="<?=$load['name_ua'] ?? ''?>"/>
                        </div>
                     </div>
                     <div class="form__row">
                        <div class="field">
                           <input type="text" name="load[description]" placeholder="Описание" autocomplete="off" value="<?=$load['description'] ?? ''?>"/>
                        </div>
                     </div>
                     <div class="form__row">
                        <div class="field">
                           <input type="text" name="load[price]" placeholder="Цена (только цифры)" autocomplete="off" value="<?=$load['price'] ?? ''?>"/>
                        </div>
                     </div>
                      <div class="form__row">
                        <div class="field">
                           <input type="text" name="load[mainParamName]" placeholder="Название параметра" autocomplete="off" value="<?=$load['mainParamName'] ?? ''?>"/>
                        </div>
                     </div>
                     
                     
                    
                  </div>
                  
                  <div class="grid__item grid__item--half">   
	                 <div class="form__row">
                        <div class="field">
                           <input type="text" placeholder="Name" value="Фото 1" autocomplete="off" readonly />
                           <input type="file" name="load[imgs][0]" placeholder="Фото 1" accept="image/*" autocomplete="off" value="<?=$load['imgs']['0'] ?? ''?>" />
                        </div>
                     </div>
                     <div class="form__row hidden">
                        <div class="field">
                           <input type="text" name="load[imgs][0]" id="lat" placeholder="Ширина" autocomplete="off" value="<?=$load['imgs']['0'] ?? ''?>"readonly/>
                        </div>
                     </div> 
                     <div class="form__row">
                        <div class="field">
                           <input type="text" placeholder="Name" value="Фото 3" autocomplete="off" readonly />
                           <input type="file" name="load[imgs][2]" placeholder="Фото 3" accept="image/*" autocomplete="off" value="<?=$load['imgs']['2'] ?? ''?>" />
                        </div>
                     </div>
                     <div class="form__row hidden">
                        <div class="field">
                           <input type="text" name="load[imgs][2]" id="lat" placeholder="Ширина" autocomplete="off" value="<?=$load['imgs']['2'] ?? ''?>"readonly/>
                        </div>
                     </div> 
	                  
               </div>

			   <div class="grid__item grid__item--half">   
	                 <div class="form__row">
                        <div class="field">
                           <input type="text" placeholder="Name" value="Фото 2" autocomplete="off" readonly />
                           <input type="file" name="load[imgs][1]" placeholder="Фото 2" accept="image/*" autocomplete="off" value="<?=$load['imgs']['1'] ?? ''?>" />
                        </div>
                     </div>
                     <div class="form__row hidden">
                        <div class="field">
                           <input type="text" name="load[imgs][1]" id="lat" placeholder="Ширина" autocomplete="off" value="<?=$load['imgs']['1'] ?? ''?>"readonly/>
                        </div>
                     </div> 
                     <div class="form__row">
                        <div class="field">
                           <input type="text" placeholder="Name" value="Фото 4" autocomplete="off" readonly />
                           <input type="file" name="load[imgs][3]" placeholder="Фото 4" accept="image/*" autocomplete="off" value="<?=$load['imgs']['3'] ?? ''?>" />
                        </div>
                     </div>
                     <div class="form__row hidden">
                        <div class="field">
                           <input type="text" name="load[imgs][3]" id="lat" placeholder="Ширина" autocomplete="off" value="<?=$load['imgs']['3'] ?? ''?>"readonly/>
                        </div>
                     </div>
               </div>


                  <br><br>
               </div>
               <br>
               <div class="grid__item grid__item--whole">
                  <center>
                     <div class="form__row"><button class="btn">Сохранить</button></div>
                  </center>
         </div>
         </form> 
      </div>
   </div>
</div>


<?php if(isset($load)): ?>
	                  <?php else: ?>
<script>
     
   
   function catDidChange() {
   	
     var catValue = document.getElementById("cat").value;  
     var catText = getSelectedText('cat');
     
     document.getElementById("catDB").value = catText;
     

     
     
     if (catValue==="1") {
   		  var newOptionsHtml1 = "<option value='1'>Домашний уход</option><option value='2'>Для профессионалов</option><option value='3'>Наборы</option>";
   		  $("#type").html(newOptionsHtml1);
   		  
   	
     } else if (catValue==="2") {
   	  var newOptionsHtml2 = "<option value='1'>Revival</option><option value='2'>Divine</option><option value='3'>Bond Angel</option><option value='4'>Gorgeous Volume</option><option value='5'>Для профессионалов</option>";
   	  $("#type").html(newOptionsHtml2);
   	  
   	 
     } else if (catValue==="3") {
   	  var newOptionsHtml3 = "<option value=''>Тип</option>";
   	  $("#type").html(newOptionsHtml3);
   	 
     } else {
   	  var newOptionsHtml4 = "<option value=''>Тип</option>";
   	  $("#type").html(newOptionsHtml4);   	 
     }
     
     var catValue = document.getElementById("type").value;  
     var catText = getSelectedText('type');
     
     document.getElementById("typeID").value = catValue;
     document.getElementById("typeName").value = catText;
   
    }
    

    function typeDidChange() {
     var catValue = document.getElementById("type").value;  
     var catText = getSelectedText('type');
     
     document.getElementById("typeID").value = catValue;
     document.getElementById("typeName").value = catText;
   

     }

    
   
   
  

function inputChangedTops(event) {
    event.target.parentElement.parentElement.className = event.target.checked ? 'selectedTops' : '';
    
    var arr = [];
    var selectedRows = document.getElementsByClassName('selectedTops');
    
   
    for (var i = 0; i < selectedRows.length; ++i) {
     	 arr.push(selectedRows[i].cells[0].id);
    }
    
	document.getElementById("tops_id").value = arr;
   }
   
   function getSelectedText(elementId) {
    var elt = document.getElementById(elementId);

    if (elt.selectedIndex == -1)
        return null;

    return elt.options[elt.selectedIndex].text;
    
    
}


    
   
      
</script>  

<?php endif; ?>

<?=$this->insert('partials/dashboard-nav')?> </div>