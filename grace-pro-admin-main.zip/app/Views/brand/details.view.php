<?php $this->layout('layouts/default', ['title' => 'Dashboard - Product'])?>
<div class="dashboard grid grid--wrapped">
<div class="grid__item grid__item--whole">
   <h1 class="dashboard__title">Подробнее</h1>
</div>
<div class="grid__item grid__item--whole">
   <div class="box">
      <div class="box__header">
         <div class="box__header-circle">
            <img src="/img/load-white.svg" alt="" />
         </div>
         <h4>Артикул #<?=$load['vendor']?></h4>
         <div class="box__header-item box__header-item--left">
            <a href="/dashboard/products/" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Назад</a>
         </div>
         <div class="box__header-item box__header-item--right">
             <a href="edit/" class="btn"><i class="mi mi-edit"></i></a>&nbsp;
            <a href="delete/" data-js="confirm-btn" data-message="Вы уверены?" class="btn" style="background:#c33d3d;"><i class="mi mi-delete"></i></a>
         </div>
      </div>
      <div class="box__wrapper" style="padding-bottom:0;">
         <div class="grid">
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Бренд</h6>
                  <span>
                  <?=($load['brand'] ?? "-")?>
                  </span>
               </div>
            </div>
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Тип</h6>
                  <span>
                  <?=($load['type'] ?? "-")?>
                  </span>
               </div>
            </div>
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Название</h6>
                  <span>
                  <?=($load['name'] ?? "-")?>
                  </span>
               </div>
            </div>
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Описание</h6>
                  <span>
                  <?=($load['description'] ?? "-")?>
                  </span>
               </div>
            </div>
         </div>
         <div class="grid">
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Состав</h6>
                  <span>
                  <?=($load['structure'] ?? "-")?>
                  </span>
               </div>
            </div>
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Цена</h6>
                  <span>
                  <?=($load['price'] ?? "-")?>
                  </span>
               </div>
            </div>
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Артикул</h6>
                  <span>
                  <?=($load['vendor'] ?? "-")?>
                  </span>
               </div>
            </div>
            
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Лого</h6>
                  <span>
                  <?php if(!empty($load['logo'])): ?>
                            <a href="/dashboard/download/Logos/<?=$load['logo']?>/?filename=logo_promoplace<?=$load['vendor']?>.png" class="link">Показать</a>
                            <?php else: ?>
                            -
                            <?php endif; ?>
                  </span>
               </div>
            </div>
            
        
         <br>
         
         <hr style="height:2px;border-width:0;color:gray;background-color:gray">         
         <div class="grid__item grid__item--whole grid__item--no-gutters">
            <div class="item-info">
	            <br>
               <h6>Парамеры товара</h6>
               <span><a href="params/edit/" class="btn"><i class="mi mi-add"></i></a></span>
            </div>
         </div>
         <div class="grid__item grid__item--whole grid__item--no-gutters">
            <?php if(empty($load['params'])): ?>
            <span class="box__message">Нет данных</span>
            <br>
            <?php else: ?>
            <div class="table">
               <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
               <table class="table__item" id="trips-list" data-js="sortable-list">
                  <tr class="no-user-select">
                     <th class="sort" data-sort="trip-num">#<i class="mi mi-unfold-more"></i></th>
                     <th class="sort" data-sort="date">Артикул<i class="mi mi-unfold-more"></i></th>
                     <th class="sort" data-sort="from">Название<i class="mi mi-unfold-more"></i></th>
                     <th class="sort" data-sort="to">Цена<i class="mi mi-unfold-more"></i></th>
                     <th>&nbsp;</th>
                     <th>&nbsp;</th>
                  </tr>
                  <tbody class="list">
                     <?php foreach($load['params'] as $trip): ?>
                     <?php if(is_null($trip)) continue; ?>
                     <tr>
                        <td class="trip-num">
                           <?=($trip['id'] ?? "-")?>
                        </td>
                        <td class="date">
                           <?=($trip['vendor'] ?? "-")?>
                        </td>
                        <td class="date">
                           <?=($trip['name'] ?? "-")?>
                        </td>
                        <td class="from">
                           <?=($trip['price'] ?? "-")?>
                        </td>
                        <td class="money-note">
 	                        <a href="/dashboard/products/<?=$brand?>/<?=$load['id']?>/params/<?=$trip['id']?>/edit/" class="link">редактировать</a>
 	                        </td>                        </td>
                         <td class="money-note">
 	                        <a href="/dashboard/products/<?=$brand?>/<?=$load['id']?>/params/<?=$trip['id']?>/delete/" class="link">удалить</a>       
                     </tr>
                     <?php endforeach; ?>
                  </tbody>
               </table>
            </div>
            <?php endif; ?>
         </div>         
   </div>

   <?=$this->insert('partials/dashboard-nav')?>
</div>