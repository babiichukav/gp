<?php $this->layout('layouts/default', [
        'title' =>  isset($user) ? 'Managers - Редактировать - ' . $user["username"] : 'Managers - Добавить'
    ])?>
    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <?php if(isset($user)): ?>
                <h1 class="dashboard__title">Менеджеры</h1>
                <?php else: ?>
                    <h1 class="dashboard__title">Менеджеры</h1>
                    <?php endif; ?>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/users-white.svg" alt="" />
                    </div>
                    <?php if(isset($user)): ?>
                        <h4><?=$user['username']?></h4>
                        <div class="box__header-item box__header-item--right">
                            <a href="../delete/" data-js="confirm-btn" data-message="Are you sure?" class="btn" style="background:#c33d3d;"><i class="mi mi-delete"></i></a>
                        </div>
                        <?php else: ?>
                            <h4>Добавить нового менеджера</h4>
                            <?php endif; ?>
                                <div class="box__header-item box__header-item--left">
                                    <a href="../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Back</a>
                                </div>
                </div>
                <div class="box__wrapper">
                    <?=$this->insert('partials/form-messages')?>
                        <form action="" method="post" data-js="form" data-btn="form-submit">
                        <?php if(isset($user)): ?>
                            <input type="hidden" name="user[id]" value="<?=$user['id']?>"/>
                        <?php endif; ?>
                            <div class="grid">
                                <div class="grid__item grid__item--half">
	                                
	                                
	                                <?php if(isset($user)): ?>
	                                
                        <?php else: ?>
<!-- 
                        <div class="form">
									<div class="form__row">
                           <div class="field">
                              <select name="load[brand]" onchange="typeDidChange()" id="cat">
                                 <option value="" selected>Тип юзера</option>
                                 <option value='1'>User</option>
                                 <option value='2'>Manager</option>
                              </select>
                           </div>
                        </div>
                        </div>
-->
                        <?php endif; ?>
                                    <div class="form">
                                        <div class="form__row">
                                            <div class="form__row-title">ФИО</div><div class="field" data-js="field">
                                                <input type="text" name="user[username]" placeholder="ФИО" value="<?=$user['username'] ?? ''?>">
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="form__row-title">Телефон</div><div class="field" data-js="field">
                                                <input type="text" name="user[phone]" placeholder="Телефон" value="<?=$user['phone'] ?? ''?>">
                                            </div>
                                        </div>
                                        


                                    </div>
                                </div>

                                <div class="grid__item grid__item--half">
                                    <div class="form">
	                                    <div class="form__row">
                                            <div class="form__row-title">Email</div><div class="field" data-js="field">
                                                <input type="text" name="user[email]" placeholder="Email" value="<?=$user['email'] ?? ''?>">
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="form__row-title">Пароль</div><div class="field" data-js="field">
                                                <input type="text" name="user[password]" placeholder="Пароль" value="<?=$user['password'] ?? ''?>">
                                            </div>
                                        </div>
                                        

                                    </div>
                                </div>

                            </div>
<div class="grid">
                                <div class="grid__item grid__item--whole">
<div class="form__row">
                                        <button class="btn">Save</button>
                                    </div>
                                </div>
                            </div>
                        </form>

                </div>

            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>
    
    <script>
	   function typeDidChange() {
     var catValue = document.getElementById("cat").value;  
     var catText = getSelectedText('cat');
     
     document.getElementById("typeName").value = catText;

   

     } 
     
     function getSelectedText(elementId) {
    var elt = document.getElementById(elementId);

    if (elt.selectedIndex == -1)
        return null;

    return elt.options[elt.selectedIndex].text;
    
    
}

	    	    
    </script>