<?php $this->layout('layouts/default', ['title' => 'Dashboard - Users'])?>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Менеджеры</h1>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/users-white.svg" alt="" />
                    </div>
                    <h4>Менеджеры</h4>
                    <div class="box__header-item box__header-item--right">
<!-- 	                    <a href="" class="btn">Менеджеры <i class="mi mi-people"></i></a> -->
                        <a href="add/" class="btn"><i class="mi mi-add"></i></a>
                    </div>
                    <div class="box__header-item box__header-item--left">
                        <div class="field">
                            <input id="list-search" type="text" placeholder="Поиск" autocomplete="off" />
                        </div>
                    </div>
                </div>
                <?=$this->insert('partials/form-messages')?>
                    <?php if(empty($users)): ?>
                        <span class="box__message">Нет данных для отображения</span>
                        <?php else: ?>

                            <div class="table">
                                <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
                                <table class="table__item" id="companies-list" data-js="sortable-list">
                                    <tr class="no-user-select">
	                                    <th class="sort" data-sort="id">ID<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="name">ФИО<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="phone">Телефон<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="email">Почта<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="manager">Менеджер<i class="mi mi-unfold-more"></i></th>
                                        <th>&nbsp;</th> 
                                    </tr>
                                    <tbody class="list">
                                        <?php foreach($users as $user): ?>
                                            <?php if(is_null($user)) continue; ?>
                                            <tr>
	                                            <td class="id">
                                                    <?=($user['id'] ?? '-')?>
                                                </td>
                                                <td class="name">
                                                    <?=($user['username'] ?? '-')?>
                                                </td>
                                                <td class="phone">
                                                    <?=($user['phone'] ?? '-')?>
                                                </td>
                                                <td class="email">
                                                    <?=($user['email'] ?? '-')?>
                                                </td>
                                                <td class="manager">
                                                    <?=($user['manager'] ?? '-')?>
                                                </td>
                                                 <td><a href="<?=$user['id']?>/" class="link">Подробнее</a></td>
                                            </tr>
                                            <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?>

            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>
