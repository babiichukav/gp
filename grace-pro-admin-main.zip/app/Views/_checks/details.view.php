<?php $this->layout('layouts/default', ['title' => 'Dashboard - Check Details - ' . $check['Name']])?>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Check Details</h1>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/checks-white.svg" alt="" />
                    </div>
                    <h4><?=$check['Name']?></h4>
                    <div class="box__header-item box__header-item--left">
                        <a href="../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Back</a>
                    </div>
                    <?php if($_SESSION['user'] == "admin"): ?>
                    <div class="box__header-item box__header-item--right">
                        <a href="delete/" data-js="confirm-btn" data-message="Are you sure?" class="btn" style="background:#c33d3d;"><i class="mi mi-delete"></i></a>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="box__wrapper" style="padding-bottom:0;">

                    <div class="grid__item grid__item--one-quarter">
                        <div class="item-info">
                            <h6>Name</h6>
                            <span><?=$check['Name']?></span>
                        </div>
                        <div class="item-info">
                            <h6>Date Created</h6>
                            <span><?=($check['date_created'])?></span>
                        </div>
                    </div>

                    <div class="grid__item grid__item--one-quarter">
                        <div class="item-info">
                            <h6>Total Amount</h6>
                            <span>$<?=$total?></span>
                        </div>
                    </div>


                         <div class="grid__item grid__item--whole grid__item--no-gutters">
                            <div class="item-info">
                                <h6>Checks</h6>
                                <span><a href="add/" class="btn"><i class="mi mi-add"></i></a></span>
                            </div>
                        </div>

                </div>


                 <div class="grid__item grid__item--whole grid__item--no-gutters">
                        <?php if(empty($check['Checks'])): ?>
                            <span class="box__message">No checks</span>
                            <?php else: ?>

                                <div class="table">
                                    <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
                                    <table class="table__item" id="trips-list" data-js="sortable-list">
                                        <tr class="no-user-select">
                                            <th class="sort" data-sort="check-num">Check Num<i class="mi mi-unfold-more"></i></th>
                                            <th class="sort" data-sort="date_created">Date Created<i class="mi mi-unfold-more"></i></th>
                                            <th class="sort" data-sort="total">Total<i class="mi mi-unfold-more"></i></th>
                                            <th>Notes</th>
                                            <th>&nbsp;</th>
                                            <th>&nbsp;</th>
                                        </tr>
                                        <tbody class="list">
                                            <?php 
                                            $name = $check["Name"];
                                            foreach($check['Checks'] as $id=>$check): ?>
                                                <?php if(is_null($check)) continue; ?>
                                                    <tr>
                                                        <td class="check-num">
                                                            <?=$check['CheckNum']?>
                                                        </td>
                                                        <td class="date_created" data-order=<fmt:formatDate pattern="MM/dd/yyyy" value= "${myObject.myDate}" />
                                                            <?=$check['date_created']?>
                                                        </td>
                                                        <td class="total">
                                                            <?=$check['Total']?>
                                                        </td>
                                                        <td>
                                                            <?=($check['Notes'] ?? "")?>
                                                        </td>
                                                        <td>
                                                            <a href="<?=$id?>/download/?filename=check_<?=$check['CheckNum']?>.pdf" class="link">Download</a>
                                                        </td>
                                                        <td>
                                                            <a href="<?=$id?>/delete/" class="link" style="color:#fff; background: #c33d3d;border: 0;padding: 6px 12px;border-radius: 20px;" onclick="return confirm('Are you sure?');">Delete</a>
                                                        </td>
                                                        
                                                    </tr>
                                                    <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <?php endif; ?>

                    </div>

            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>