<?php $this->layout('layouts/default', ['title' => 'Dashboard - Checks'])?>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Checks</h1>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/checks-white.svg" alt="" />
                    </div>
                    <h4>Checks</h4>
                    <div class="box__header-item box__header-item--right">
                        <a href="add/" class="btn"><i class="mi mi-add"></i></a>
                    </div>
                    <div class="box__header-item box__header-item--left">
                        <div class="field">
                            <input id="list-search" type="text" placeholder="Search" autocomplete="off" />
                        </div>
                    </div>
                    <br><br><br><center>
                
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<select class="inputxlg" id="rangeval">
    <option value="">Filter by Date Range</option>
    <option value="7">7 Days</option>
    <option value="30">30 Days</option>
    <option value="90">90 Days</option>
<!--     <option value="365">Last Year</option> -->
    <option value="Single Date">Single Date</option>
    <option value="Custom Date Range">Custom Date Range</option>
</select>

<input id="selectDate" name="selectDate" type="text">
<input id="selectDate2" name="selectDate" type="text">
</center>

                </div>
                
                
                <?=$this->insert('partials/form-messages')?>
                    <?php if(empty($checks)): ?>
                        <span class="box__message">No checks</span>
                        <?php else: ?>

                            <div class="table">
                                <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
                                <table class="table__item" id="checks-list" data-js="sortable-list">
                                    <tr class="no-user-select">
                                        <th class="sort" data-sort="name">Name<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="date_created">Date Created<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="total_amount">Total Amount<i class="mi mi-unfold-more"></i></th>
                                        <th>&nbsp;</th>
                                    </tr>
                                    <tbody class="list">
                                        <?php foreach($checks as $id => $check): ?>
                                                <tr>
                                                    <td class="name">
                                                        <?=($check['Name'] ?? '')?>
                                                    </td>
                                                    <td class="date_created" data-order=<fmt:formatDate pattern="MM/dd/yyyy" value= "${myObject.myDate}" />
                                                        <?=($check['date_created'] ?? '')?>
                                                    </td>
                                                    <td class="total_amount">
                                                        $<?=($check['Total'] ?? '')?>
                                                    </td>
                                                    <td>
                                                        <a href="<?=$id?>/" class="link">Details</a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?>

            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>
    
    <script>
	    $(function(){
    // Initialise the inputs on page load:
    var today = new Date().toJSON().replace(/..(..)-(..)-(..).*/, '$2/$3/$1');
    $("#selectDate").datepicker({ dateFormat: 'mm/dd/yy' }).val(today).change(applyFilter);
    $("#selectDate2").datepicker({ dateFormat: 'mm/dd/yy' }).val(today).change(applyFilter);
    $("#rangeval").change(applyFilter);

    $.fn.date = function () {
        return new Date((this.is(':input') ? this.val() : this.text()).replace(/\/(..)$/, '/20$1'));
    }
    
    function applyFilter() {
        var filterType = $("#rangeval").val(),
            start, end;
        // Set the visibility of the two date fields:
        $("#selectDate").toggle(["Single Date", "Custom Date Range"].indexOf(filterType) > -1);
        $("#selectDate2").toggle(filterType === "Custom Date Range");
        // Depending on the type of filter, set the range of dates (start, end):
        if (filterType === "") {
            // Show all: choose extreme dates
            start = new Date('1000-01-01');
            end = new Date('3000-01-01');
        } else if (!parseInt(filterType)) {
            // Use data entry:
            start = $("#selectDate").date();
            end = filterType === "Custom Date Range" ? $("#selectDate2").date() : start;
        } else {
            // Show last X days:
            start = new Date();
            start.setHours(0,0,0,0);
            start.setDate(start.getDate() - parseInt(filterType));
            end = new Date(); // today
        }
        // For each row: set the visibility depending on the date range
        $(".list tr").each(function () {
            var date = $("td:nth-child(2)", this).date();
            $(this).toggle(date >= start && date <= end);
        });
    }
    applyFilter(); // Execute also on page load
});
	    </script>