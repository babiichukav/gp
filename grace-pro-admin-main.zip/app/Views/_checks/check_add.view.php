<?php $this->layout('layouts/default', [
    'title' => 'Dashboard - Add Check'
    ])?>
    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
                    <h1 class="dashboard__title">Add Check</h1>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/checks-white.svg" alt="" />
                    </div>
                            <h4>check for <?=$name?></h4>
                            <div class="box__header-item box__header-item--left">
                                    <a href="../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Back</a>
                                </div>
                </div>
                <div class="box__wrapper">
                    <?=$this->insert('partials/form-messages')?>
                        <form action="" method="post" data-js="form" enctype="multipart/form-data">
                            <div class="grid">
                                <div class="grid__item grid__item--half">

                                    
                                    
                            <div class="form__row">
                                <div class="field field__name-value">
                                    <input type="text" value="Check number" autocomplete="off" readonly />
                                    <input type="number" name="check[num]" value="<?=$check_num?>" placeholder="Check number" autocomplete="off"/>
                                </div>
                            </div>
                            <div class="form__row">
                                <div class="field field__name-value">
                                    <input type="text" value="Date" autocomplete="off" readonly />
                                    <input type="text" name="check[date]" value="<?=date("m-d-y")?>" placeholder="Date" autocomplete="off"/>
                                </div>
                            </div>
                            <div class="form__row" style="position: relative;">
                                <div class="field field__name-value">
                                    <input type="text" value="Total" autocomplete="off" readonly />
                                    <input type="text" name="check[total]" value="" placeholder="Total" autocomplete="off"/>
                                </div>
                                <span id="ajax_total" style="position: absolute;top:12px;left:100%;margin-left:20px;font-weight:bold;" class="hidden">$0</span>
                                <img src="https://telemir48.ru/images/gif/loading.gif" alt="" id="ajax_loading" style="position: absolute;top:10px;left:100%;margin-left:20px;width:20px;" class="hidden"/>

                            </div>
                            <div class="form__row">
                                <div class="field field__name-value">
                                    <input type="text" value="Pay To" autocomplete="off" readonly />
                                    <input type="text" name="check[to]" value="<?=$name?>" placeholder="Pay To" autocomplete="off"/>
                                </div>
                            </div>
                            <div class="form__row">
                                <div class="field field__name-value">
                                    <input type="text" value="Pay For" autocomplete="off" readonly />
                                    <input type="text" name="check[for]" value="" placeholder="Pay For" autocomplete="off"/>
                                </div>
                            </div>
                            <div class="form__row">
                                <div class="field">
                                    <textarea name="check[notes]" placeholder="Notes"></textarea>
                                </div>
                            </div>



                                </div>

                                <div class="grid__item grid__item--whole">
                                    <div class="form__row">
                                        <button class="btn">Save</button>
                                    </div>

                                </div>
                            </div>

                        </form>

                </div>

            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>