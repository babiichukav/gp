<?php $this->layout('layouts/default', ['title' => 'Dashboard - Users'])?>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Покупают вместе</h1>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/load-white.svg" alt="" />
                    </div>
                    <h4>Покупают с <?=($brand)?></h4>

                    <div class="box__header-item box__header-item--right">
                        <a href="edit" class="btn"><i class="mi mi-add"></i></a>
                    </div>

                    <div class="box__header-item box__header-item--left">
                        <div class="field">
                            <input id="list-search" type="text" placeholder="Поиск" autocomplete="off" />
                        </div>
                    </div>
                </div>
                <?=$this->insert('partials/form-messages')?>
                    <?php if(empty($products)): ?>
                        <span class="box__message">Нет данных для отображения</span>
                        <?php else: ?>

                            <div class="table">
                                <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
                                <table class="table__item" id="companies-list" data-js="sortable-list">
                                    <tr class="no-user-select">
	                                    <th class="sort" data-sort="vendor">Артикул<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="name">Название<i class="mi mi-unfold-more"></i></th>
                                        <th>&nbsp;</th>
                                    </tr>
                                    <tbody class="list">
                                        <?php foreach($products as $prod): ?>
                                            <?php if(is_null($prod)) continue; ?>
                                            <tr>
                                                <td class="vendor">
                                                    <?=($prod['vendor'] ?? '-')?>
                                                </td>
                                             
                                                <td class="name">
                                                    <?=($prod['name'] ?? '-')?>
                                                </td>
                                                                                               
                                                <td><a href="<?=$prod['id']?>/delete/" class="link">удалить</a></td>
                                            </tr>
                                            <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?>

            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>
