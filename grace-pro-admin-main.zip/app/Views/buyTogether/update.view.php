<?php $this->layout('layouts/default', [ 'title' => isset($load) ? 'Dashboard - Edit Product Details' : 'Dashboard - Add Product'  ]) ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="https://unpkg.com/location-picker/dist/location-picker.min.js"></script>

<script>
function removeElementsEdit(selectedCatID, selectedTypeID) {
	var cat = document.getElementById("cat");
	cat.value = selectedCatID;

	document.getElementById("editToHide1").classList.add("hidden");
	document.getElementById("editToHide2").classList.add("hidden");
	
	document.getElementById("editToHide3").classList.add("hidden");
	document.getElementById("editToHide4").classList.add("hidden");

	setTimeout(function() {
	
     var catText = getSelectedText('cat');
     document.getElementById("catDB").value = catText;
     
     if (selectedCatID===1) {
   		  var newOptionsHtml1 = "<option value='1'>Ресторан</option><option value='2'>Бар</option><option value='3'>Кофейня</option><option value='4'>Кафе</option><option value='5'>Пекарня</option>";
   		  $("#type").html(newOptionsHtml1);
     } else if (selectedCatID===2) {
   	  var newOptionsHtml2 = "<option value='1'>Салон</option><option value='2'>Фитнес</option><option value='3'>Стоматология</option><option value='4'>Медицина</option><option value='5'>Спа</option><option value='6'>Барбершоп</option>";
   	  $("#type").html(newOptionsHtml2);

     } else if (selectedCatID===3) {
   	  var newOptionsHtml3 = "<option value='1'>Аттракционы и досуг</option><option value='2'>Мода и розничная торговля</option><option value='3'>Ежедневные услуги</option>";
   	  $("#type").html(newOptionsHtml3);
     }
     
     var type = document.getElementById("type");
	type.value = selectedTypeID;


     var typeText = getSelectedText('type');
     document.getElementById("typeDB").value = typeText;

	}, 1000);
	

    }
    


</script>
<div class="dashboard grid grid--wrapped">
   <div class="grid__item grid__item--whole">
      <h1 class="dashboard__title">Товары</h1>
   </div>
   <div class="grid__item grid__item--whole">
      <div class="box">
         <div class="box__header">
            <div class="box__header-circle">
               <img src="/img/load-white.svg" alt="" />
            </div>
            <?php if(isset($load)): ?>
            <h4>Редактировать товар #<?=$load['id']?></h4>
            <div class="box__header-item box__header-item--left">
               <?php if(!empty($trip_id)): ?>
               <a href="../../../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Назад</a>
               <?php else: ?>
               <a href="../../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Назад</a>
               <?php endif; ?>
            </div>
            <div class="box__header-item box__header-item--right">
               <a href="../delete/" data-js="confirm-btn" data-message="Вы уверены?" class="btn" style="background:#c33d3d;"><i class="mi mi-delete"></i></a>
            </div>
            <?php else: ?>
            <h4>Добавить новый товар</h4>
            <div class="box__header-item box__header-item--left">
               <a href="../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Назад</a>
            </div>
            <?php endif; ?>
         </div>
         <div class="box__wrapper">
            <?=$this->insert('partials/form-messages')?>
            <form action="" enctype="multipart/form-data" method="post" data-js="form" class="<?=(isset($load) ? 'edit-form' : '')?>">
               <div class="grid">
                  <div class="grid__item grid__item--half">                     
<!--
                     <div class="form" id="editToHide1">
                        <div class="form__row">
                           <div class="field">
                              <select name="load[brand]" onchange="catDidChange()" id="cat">
                                 <option value="" selected>Бренд</option>
                                 <option value='1'>Dr. Sorbie</option>
                                 <option value='2'>Brae</option>
                                 <option value='3'>Tempting</option>
                              </select>
                           </div>
                        </div>
                     </div>
-->
                    
                     <br>
                     
					 <!-- техническая часть -->
					 <div class="form__row hidden">
                        <div class="field">
                           <input type="text" name="load[brand]" placeholder="Название Категории" autocomplete="off" value="<?=$brand?>"/>
                        </div>
                     </div>
                     <div class="form__row hidden">
                        <div class="field">
                           <input type="text" id="typeID" name="load[typeID]" placeholder="Название Типа" autocomplete="off" value=""/>
                        </div>
                     </div>
                     
                     <div class="form__row hidden">
                        <div class="field">
                           <input type="text" id="typeName" name="load[typeName]" placeholder="Название Типа" autocomplete="off" value=""/>
                        </div>
                     </div>
					 
					 
                     <div class="form__row">
                        <div class="field">
                           <input type="text" name="load[name]" placeholder="Название" autocomplete="off" value="<?=$load['name'] ?? ''?>"/>
                        </div>
                     </div>
                     <div class="form__row">
                        <div class="field">
                           <input type="text" name="load[structure]" placeholder="Состав" autocomplete="off" value="<?=$load['structure'] ?? ''?>"/>
                        </div>
                     </div>
                     <div class="form__row">
                        <div class="field">
                           <input type="text" name="load[vendor]" placeholder="Артикул" autocomplete="off" value="<?=$load['vendor'] ?? ''?>"/>
                        </div>
                     </div>
                     <div class="form__row">
                        <div class="field">
                           <input type="text" name="load[mainParamName]" placeholder="Название параметра" autocomplete="off" value="<?=$load['mainParamName'] ?? ''?>"/>
                        </div>
                     </div>
                    
                     <div class="form__row hidden">
                        <div class="field">
                           <input type="text" name="load[id]" autocomplete="off" value="<?=$load['id'] ?? ''?>"readonly/>
                        </div>
                     </div>
                    
                     
                  </div>
                  <div class="grid__item grid__item--half">
<!--
	                  <div class="form"  id="editToHide3">
                        <div class="form__row">
                           <div class="field">
                              <select name="load[type]" onchange="typeDidChange()" id="type">
                                 <option value="" selected>Тип</option>
                              </select>
                           </div>
                        </div>
                     </div>
-->
                     <br>
                     <div class="form__row">
                        <div class="field">
                           <input type="text" name="load[description]" placeholder="Описание" autocomplete="off" value="<?=$load['description'] ?? ''?>"/>
                        </div>
                     </div>
                     <div class="form__row">
                        <div class="field">
                           <input type="text" name="load[price]" placeholder="Цена (только цифры)" autocomplete="off" value="<?=$load['price'] ?? ''?>"/>
                        </div>
                     </div>
                     <div class="form__row">
                        <div class="field">
                           <input type="text" placeholder="Name" value="Фото" autocomplete="off" readonly />
                           <input type="file" name="load[logo]" placeholder="Фото" accept=".png" autocomplete="off" value="<?=$load['logo'] ?? ''?>" />
                        </div>
                     </div>
                                         
                     <div class="form__row hidden">
                        <div class="field">
                           <input type="text" name="load[logo]" id="lat" placeholder="Ширина" autocomplete="off" value="<?=$load['logo'] ?? ''?>"readonly/>
                        </div>
                     </div>
                     
                    
                  </div>
                  <br><br>
               </div>
               <br>
               <div class="grid__item grid__item--whole">
                  <center>
                     <div class="form__row"><button class="btn">Сохранить</button></div>
                  </center>
         </div>
         </form> 
      </div>
   </div>
</div>
<?php if(isset($load)): ?>
	                  <?php
 		                  $catID = $load['brand'];
 		                  $typeID = $load['type'];
		                  echo '<script>';
						  echo 'var catID = ' . $catID . ';';
						  echo 'var typeID = ' . $typeID . ';';
						  echo 'removeElementsEdit(catID,typeID);';
						  echo 'getTopPlaces(topsID);';
						  echo '</script>';
	                   ?>
                     <?php endif; ?>
<script>
     
   
   function catDidChange() {
   	
     var catValue = document.getElementById("cat").value;  
     var catText = getSelectedText('cat');
     
     document.getElementById("catDB").value = catText;
     

     
     
     if (catValue==="1") {
   		  var newOptionsHtml1 = "<option value='1'>Домашний уход</option><option value='2'>Для профессионалов</option><option value='3'>Наборы</option>";
   		  $("#type").html(newOptionsHtml1);
   		  
   	
     } else if (catValue==="2") {
   	  var newOptionsHtml2 = "<option value='1'>Revival</option><option value='2'>Divine</option><option value='3'>Bond Angel</option><option value='4'>Gorgeous Volume</option><option value='5'>Для профессионалов</option>";
   	  $("#type").html(newOptionsHtml2);
   	  
   	 
     } else if (catValue==="3") {
   	  var newOptionsHtml3 = "<option value=''>Тип</option>";
   	  $("#type").html(newOptionsHtml3);
   	 
     } else {
   	  var newOptionsHtml4 = "<option value=''>Тип</option>";
   	  $("#type").html(newOptionsHtml4);   	 
     }
     
     var catValue = document.getElementById("type").value;  
     var catText = getSelectedText('type');
     
     document.getElementById("typeID").value = catValue;
     document.getElementById("typeName").value = catText;
   
    }
    

    function typeDidChange() {
     var catValue = document.getElementById("type").value;  
     var catText = getSelectedText('type');
     
     document.getElementById("typeID").value = catValue;
     document.getElementById("typeName").value = catText;

   

     }

    
   
   
  

function inputChangedTops(event) {
    event.target.parentElement.parentElement.className = event.target.checked ? 'selectedTops' : '';
    
    var arr = [];
    var selectedRows = document.getElementsByClassName('selectedTops');
    
   
    for (var i = 0; i < selectedRows.length; ++i) {
     	 arr.push(selectedRows[i].cells[0].id);
    }
    
	document.getElementById("tops_id").value = arr;
   }
   
   function getSelectedText(elementId) {
    var elt = document.getElementById(elementId);

    if (elt.selectedIndex == -1)
        return null;

    return elt.options[elt.selectedIndex].text;
    
    
}


    
   
      
</script>    

<?=$this->insert('partials/dashboard-nav')?> </div>