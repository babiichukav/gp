        <div class="dashboard__nav" data-js="dashboard-nav">

            <nav class="nav">
                <a href="/dashboard/" style="display:none;" class="nav__item <?=pathclass('/dashboard/', "nav__item--active")?>">
                    <img src="/img/dashboard-white.svg" alt="" />
                    <span>Dashboard</span>
                </a>
                <a href="/dashboard/products/" class="nav__item <?=pathclass('/dashboard/products/*/', "nav__item--active")?>">
                    <img src="/img/load-white.svg" alt="" />
                    <span>Бренды</span>
                </a>
                <a href="/dashboard/news/" class="nav__item <?=pathclass('/dashboard/news/*/', "nav__item--active")?>">
                    <img src="/img/news.svg" alt="" />
                    <span>Новости</span>
                </a>
<!--
                <a href="/dashboard/procedures/" class="nav__item <?=pathclass('/dashboard/procedures/*/', "nav__item--active")?>">
                    <img src="/img/checks-white.svg" alt="" />
                    <span>Процедуры</span>
                </a>
-->
                <a href="/dashboard/users/" class="nav__item <?=pathclass('/dashboard/users/*/', "nav__item--active")?>">
                    <img src="/img/users-white.svg" alt="" />
                    <span>Юзеры</span>
                </a>
                <a href="/dashboard/history/" class="nav__item <?=pathclass('/dashboard/history/*/', "nav__item--active")?>">
                    <img src="/img/checks-white.svg" alt="" />
                    <span>Заказы</span>
                </a>
                
                
<!--
                <a href="/dashboard/transactions/" class="nav__item <?=pathclass('/dashboard/transactions/*/', "nav__item--active")?>">
                    <img src="/img/expenses-white.svg" alt="" />
                    <span>Транзакции</span>
                </a>
-->

                <!--
                <a href="/dashboard/trucks/" class="nav__item <?=pathclass('/dashboard/trucks/*/', "nav__item--active")?>">
                    <img src="/img/truck-white.svg" alt="" />
                    <span>Trucks</span>
                </a>
                <a href="/dashboard/trailers/" class="nav__item <?=pathclass('/dashboard/trailers/*/', "nav__item--active")?>">
                    <img src="/img/trailer-white.svg" alt="" />
                    <span>Trailers</span>
                </a>
                <a href="/dashboard/drivers/" class="nav__item <?=pathclass('/dashboard/drivers/*/', "nav__item--active")?>">
                    <img src="/img/driver-white.svg" alt="" />
                    <span>Drivers</span>
                </a>
                <a href="/dashboard/contracts/" class="nav__item <?=pathclass('/dashboard/contracts/*/', "nav__item--active")?>">
                    <img src="/img/contract-white.svg" alt="" />
                    <span>Contracts</span>
                </a>
                <a href="/dashboard/checks/" class="nav__item <?=pathclass('/dashboard/checks/*/', "nav__item--active")?>">
                    <img src="/img/checks-white.svg" alt="" />
                    <span>Checks</span>
                </a>
                <?php if($_SESSION['user'] == "admin"): ?>
                <?php if(!isset($_SESSION['archive'])): ?>
                <a href="/dashboard/archive/" class="nav__item <?=pathclass('/dashboard/archive/*/', "nav__item--active")?>">
                    <img src="/img/archive-white.svg" alt="" />
                    <span>Archive</span>
                </a>
                <?php endif; ?>
                <a href="/dashboard/users/" class="nav__item <?=pathclass('/dashboard/users/*/', "nav__item--active")?>">
                    <img src="/img/users-white.svg" alt="" />
                    <span>Users</span>
                </a>
                <?php endif; ?>
-->
            </nav>

        </div>