<?php $this->layout('layouts/default', [
    'title' => isset($notes) ? 'Dashboard - Edit Note - ' . $notes['Title'] : 'Dashboard - Add Note'
    ])?>
    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <?php if(isset($notes)): ?>
                <h1 class="dashboard__title">Edit Note</h1>
                <?php else: ?>
                    <h1 class="dashboard__title">Add Note</h1>
                    <?php endif; ?>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/notes-white.svg" alt="" />
                    </div>
                    <?php if(isset($notes)): ?>
                        <h4><?=$notes['Title']?></h4>
                        <?php if($_SESSION['user'] == "admin"): ?> 
                        <div class="box__header-item box__header-item--right">
                            <a href="../delete/" data-js="confirm-btn" data-message="Are you sure? All driver related data will be also deleted." class="btn" style="background:#c33d3d;"><i class="mi mi-delete"></i></a>
                        </div>
                        <?php endif; ?> 
                        <?php else: ?>
                            <h4>Add new note</h4>
                            <?php endif; ?>
                                <div class="box__header-item box__header-item--left">
                                    <a href="../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Back</a>
                                </div>
                </div>
                <div class="box__wrapper">
                    <?=$this->insert('partials/form-messages')?>
                        <form action="" enctype="multipart/form-data" method="post" data-js="form" class="<?=(isset($notes) ? 'edit-form' : '')?>">
                            <div class="grid">
                                <div class="grid__item grid__item--half">

                                    <div class="form">
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="text" name="notes[Title]" placeholder="Title" autocomplete="off" value="<?=$notes['Title'] ?? ''?>" <?=(isset($notes) ? 'readonly' : '')?>/>
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="field">
<!--                                                 <textarea type="text" name="notes[Data]" placeholder="Data" autocomplete="off" value="<?=$notes['Data'] ?? ''?>"</textarea> -->
                                                <textarea name="notes[Data]"><?=$notes['Data'] ?? ''?></textarea>
                                            </div>
                                        </div>
                                        

                                    </div>
                                </div>

                               
                                <div class="grid__item grid__item--whole">
                                    <div class="form__row">
                                        <button class="btn">Save</button>
                                    </div>

                                </div>
                            </div>

                        </form>

                </div>

            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>