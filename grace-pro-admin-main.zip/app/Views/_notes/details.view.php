<?php $this->layout('layouts/default', ['title' => 'Dashboard - Notes Details - ' . $notes['Title']])?>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Notes Details</h1>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/notes-white.svg" alt="" />
                    </div>
                    <h4><?=$notes['Title']?></h4>
                    <div class="box__header-item box__header-item--left">
                        <a href="../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Back</a>
                    </div>
                     
                    <div class="box__header-item box__header-item--right">
                        <a href="edit/" class="btn"><i class="mi mi-edit"></i></a>&nbsp;
                        <?php if($_SESSION['user'] == "admin"): ?> 
                        <a href="delete/" data-js="confirm-btn" data-message="Are you sure? All related data will be also deleted." class="btn" style="background:#c33d3d;"><i class="mi mi-delete"></i></a>
						<?php endif; ?> 
                    </div>
                     
                </div>
                <div class="box__wrapper" style="padding-bottom:0;">

                    <div class="grid__item grid__item--one-quarter">
                        <div class="item-info">
                            <h6>Title</h6>
                            <span><?=$notes['Title']?></span>
                        </div>
                        
                    </div>
                    
                    <div class="grid__item grid__item--one-quarter">
                            <div class="item-info">
                            <h6>Data</h6>
                            <span><?=$notes['Data']?></span>
                        </div>
                        </div>    

                </div>

            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>