<?php $this->layout('layouts/default', ['title' => 'Dashboard - News Details - News #' . $load['id']])?>
<div class="dashboard grid grid--wrapped">
<div class="grid__item grid__item--whole">
   <h1 class="dashboard__title">Подробнее</h1>
</div>
<div class="grid__item grid__item--whole">
   <div class="box">
      <div class="box__header">
         <div class="box__header-circle">
            <img src="/img/news.svg" alt="" />
         </div>
         <h4>Промоместо #<?=$load['place']['place_id']?></h4>
         <div class="box__header-item box__header-item--left">
            <a href="/dashboard/promoplaces/" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Назад</a>
         </div>
         <div class="box__header-item box__header-item--right">
             <a href="edit/" class="btn"><i class="mi mi-edit"></i></a>&nbsp;
            <a href="delete/" data-js="confirm-btn" data-message="Вы уверены?" class="btn" style="background:#c33d3d;"><i class="mi mi-delete"></i></a>
         </div>
      </div>
      <div class="box__wrapper" style="padding-bottom:0;">
         <div class="grid">
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Категория</h6>
                  <span>
                  <?=($load['place']['place_catDB'] ?? "")?>
                  </span>
               </div>
            </div>
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Тип</h6>
                  <span>
                  <?=($load['place']['place_typeDB'] ?? "")?>
                  </span>
               </div>
            </div>
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Теги</h6>
                  <span>
                  <?=($load['place']['type'] ?? "")?>
                  </span>
               </div>
            </div>
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Специфика</h6>
                  <span>
                  <?=($load['place']['type'] ?? "")?>
                  </span>
               </div>
            </div>
         </div>
         <div class="grid">
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Название</h6>
                  <span>
                  <?=($load['place']['place_name'] ?? "")?>
                  </span>
               </div>
            </div>
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Описание</h6>
                  <span>
                  <?=($load['place']['place_discr'] ?? "")?>
                  </span>
               </div>
            </div>
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Телефон</h6>
                  <span>
                  <?=($load['place']['place_phone'] ?? "")?>
                  </span>
               </div>
            </div>
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Адрес</h6>
                  <span>
                  <?=($load['place']['place_address_ru'] ?? "")?>
                  </span>
               </div>
            </div>
         </div>
         <div class="grid">
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Ссылка на сайт</h6>
                  <span>
                  <?=($load['place']['place_website'] ?? "")?>
                  </span>
               </div>
            </div>
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Ссылка на инст</h6>
                  <span>
                  <?=($load['place']['place_inst'] ?? "")?>
                  </span>
               </div>
            </div>
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Ссылка на фб</h6>
                  <span>
                  <?=($load['place']['place_facebook'] ?? "")?>
                  </span>
               </div>
            </div>
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Время работы</h6>
                  <span>
                  <?=($load['place']['place_time'] ?? "")?>
                  </span>
               </div>
            </div>
         </div>
         <div class="grid">
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Фото</h6>
                  <span>
                  <?php if(!empty($load['place']['place_photo'])): ?>
                            <a href="/dashboard/download/Photos/<?=$load['place']['place_photo']?>/?filename=photo_promoplace<?=$load['place']['place_id']?>.png" class="link">Показать</a>
                            <?php else: ?>
                            -
                            <?php endif; ?>
                  </span>
               </div>
            </div>
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Лого</h6>
                  <span>
                  <?php if(!empty($load['place']['place_logo'])): ?>
                            <a href="/dashboard/download/Logos/<?=$load['place']['place_logo']?>/?filename=logo_promoplace<?=$load['place']['place_id']?>.png" class="link">Показать</a>
                            <?php else: ?>
                            -
                            <?php endif; ?>
                  </span>
               </div>
            </div>
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Пин код</h6>
                  <span>
                  <?=($load['place']['place_pin'] ?? "")?>
                  </span>
               </div>
            </div>
            <!--
               <div class="grid__item grid__item--one-quarter">
                  <div class="item-info">
                     <h6>Время работы</h6>
                     <span>
                     <?=($load['place']['place_time'] ?? "")?>
                     </span>
                  </div>
               </div>
               -->
         </div>
         <!--
            <div class="grid">
                                    <div class="item-info">
                    <h6>PDF 1</h6>
                    <span>
                    <?php if(!empty($load['Date'])): ?>
                    <a href="/dashboard/download/loads/<?=$load['PDF']?>/?filename=load_<?=$load["LoadNumber"]?>.pdf" class="link">Download</a>
                    <?php else: ?>
                    -
                    <?php endif; ?>
                </span>
                 </div>
                <div class="item-info">
                    <h6>PDF 2</h6>
                    <span>
                    <?php if(!empty($load['PDF1'])): ?>
                    <a href="/dashboard/download/loads/<?=$load['PDF1']?>/?filename=load_<?=$load["LoadNumber"]?>.pdf" class="link">Download</a>
                    <?php else: ?>
                    -
                    <?php endif; ?>
                </span>
            -->
         <br>
         <hr style="height:2px;border-width:0;color:gray;background-color:gray">
         <br>
         <div class="grid">
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <a href="client/edit/" class="btn">Информация о клиенте <i class="mi mi-edit"></i></a>
               </div>
            </div>
         </div>
         <?php if(isset($load['client'])): ?>            
         <div class="grid">
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Имя и телефон</h6>
                  <span>
                  <?=($load['client']['name'] ?? "")?> - <?=($load['client']['phone'] ?? "")?>
                  </span>
               </div>
            </div>
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Баланс</h6>
                  <span>
                  <?=($load['client']['balance'] ?? "")?>
                  </span>
               </div>
            </div>
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Почта</h6>
                  <span>
                  <?=($load['client']['login'] ?? "")?>
                  </span>
               </div>
            </div>
            <div class="grid__item grid__item--one-quarter">
               <div class="item-info">
                  <h6>Пароль</h6>
                  <span>
                  <?=($load['client']['password'] ?? "")?>
                  </span>
               </div>
            </div>
         </div>
         <?php else: ?>
         <span class="box__message">Нет данных</span>
         <br><br>
         <?php endif; ?>
         <br>
         <hr style="height:2px;border-width:0;color:gray;background-color:gray">
         <br>
         
         <div class="grid__item grid__item--whole grid__item--no-gutters">
            <div class="item-info">
               <h6>Промокоды</h6>
               <span><a href="promocodes/edit/" class="btn"><i class="mi mi-add"></i></a></span>
            </div>
         </div>
         <div class="grid__item grid__item--whole grid__item--no-gutters">
            <?php if(empty($load['promocodes'])): ?>
            <span class="box__message">Нет данных</span>
            <br>
            <?php else: ?>
            <div class="table">
               <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
               <table class="table__item" id="trips-list" data-js="sortable-list">
                  <tr class="no-user-select">
                     <th class="sort" data-sort="trip-num">#<i class="mi mi-unfold-more"></i></th>
                     <th class="sort" data-sort="date">Тип<i class="mi mi-unfold-more"></i></th>
                     <th class="sort" data-sort="from">Название<i class="mi mi-unfold-more"></i></th>
                     <th class="sort" data-sort="to">Описание<i class="mi mi-unfold-more"></i></th>
                     <th class="sort" data-sort="driver">Сумма економии<i class="mi mi-unfold-more"></i></th>
                     <th class="sort" data-sort="fuel">% скидки<i class="mi mi-unfold-more"></i></th>
                     <th>&nbsp;</th>
                  </tr>
                  <tbody class="list">
                     <?php foreach($load['promocodes'] as $trip): ?>
                     <?php if(is_null($trip)) continue; ?>
                     <tr>
                        <td class="trip-num">
                           <?=($trip['id'] ?? "-")?>
                        </td>
                        <td class="date">
                           <?=($trip['typeToDB'] ?? "-")?>
                        </td>
                        <td class="date">
                           <?=($trip['name'] ?? "-")?>
                        </td>
                        <td class="from">
                           <?=($trip['descr'] ?? "-")?>
                        </td>
                        <td class="fuel">
                           <?=($trip['sum'] ?? "-")?>
                        </td>
                        <td class="money-note">
                           <?=($trip['procent']  ?? "-")?>
                        </td>
                        <td class="money-note">
	                        <a href="/dashboard/promoplaces/<?=$load['place']['place_id']?>/promocodes/<?=$trip['id']?>/delete/" class="link">удалить</a>
                        </td>
                          
                     </tr>
                     <?php endforeach; ?>
                  </tbody>
               </table>
            </div>
            <?php endif; ?>
         </div>
         
         <br><br>
         <hr style="height:2px;border-width:0;color:gray;background-color:gray">
         <br>
         
         <div class="grid__item grid__item--whole grid__item--no-gutters">
            <div class="item-info">
               <h6>Другие адреса</h6>
               <span><a href="alternativeaddresses/edit/" class="btn"><i class="mi mi-add"></i></a></span>
            </div>
         </div>
         
         <div class="grid__item grid__item--whole grid__item--no-gutters">
            <?php if(empty($load['addresses'])): ?>
            <span class="box__message">Нет данных</span>
            <br>
            <?php else: ?>
            <div class="table">
               <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
               <table class="table__item" id="trips-list" data-js="sortable-list">
                  <tr class="no-user-select">
                     <th class="sort" data-sort="trip-num">#<i class="mi mi-unfold-more"></i></th>
                     <th class="sort" data-sort="date">Адрес<i class="mi mi-unfold-more"></i></th>
                     <th class="sort" data-sort="from">Телефон<i class="mi mi-unfold-more"></i></th>
                     <th>&nbsp;</th>
                  </tr>
                  <tbody class="list">
                     <?php foreach($load['addresses'] as $trip): ?>
                     <?php if(is_null($trip)) continue; ?>
                     <tr>
                        <td class="trip-num">
                           <?=($trip['id'] ?? "-")?>
                        </td>
                        <td class="date">
                           <?=($trip['address'] ?? "-")?>
                        </td>
                        <td class="date">
                           <?=($trip['phone'] ?? "-")?>
                        </td>
                        <td class="money-note">
	                        <a href="/dashboard/promoplaces/<?=$load['place']['place_id']?>/alternativeaddresses/<?=$trip['id']?>/delete/" class="link">удалить</a>
                        </td>
                     </tr>
                     <?php endforeach; ?>
                  </tbody>
               </table>
            </div>
            <?php endif; ?>
         </div>
      </div>
   </div>
            </div>

   <?=$this->insert('partials/dashboard-nav')?>
</div>