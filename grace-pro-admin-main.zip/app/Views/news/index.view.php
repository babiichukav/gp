<?php $this->layout('layouts/default', ['title' => 'Dashboard - News'])?>
</style>
<div class="dashboard grid grid--wrapped">
   <div class="grid__item grid__item--whole">
      <h1 class="dashboard__title">Новости</h1>
   </div>
   <div class="grid__item grid__item--whole">
      <div class="box">
         <div class="box__header">
            <div class="box__header-circle">
               <img src="/img/news.svg" alt="" />
            </div>
            <h4>Новости</h4>
            <div class="box__header-item box__header-item--right">
               <a href="add/" class="btn"><i class="mi mi-add"></i></a>
            </div>
            <div class="box__header-item box__header-item--left">
               <div class="field">
                  <input id="list-search" type="text" placeholder="Поиск" autocomplete="off" />
               </div>
            </div>
         </div>
         <?=$this->insert('partials/form-messages')?>
         <?php if(empty($news)): ?>
         <span class="box__message">Нет данных для отображения</span>
         <?php else: ?>
         <div class="table">
            <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
            <table class="table__item" id="loads-list" data-js="sortable-list">
               <tr class="no-user-select">
                  <th class="sort" data-sort="id">ID<i class="mi mi-unfold-more"></i></th>
                  <th class="sort" data-sort="title">Заголовок<i class="mi mi-unfold-more"></i></th>
                  <th class="sort" data-sort="date">Дата публикации<i class="mi mi-unfold-more"></i></th>
                  <th>&nbsp;</th>
               </tr>
               <tbody class="list">
                  <?php foreach($news as $new): ?>
                  <?php if(is_null($new)) continue; ?>
                  <tr>
                     <td class="id">
                        <?=($new['id'] ?? '-')?>
                     </td>
                     <td class="title">
                        <?=$new['title']?>
                     </td>
                     <td class="date">
                        <?=$new['Date']?>
                     </td>
                     <td>
                        <a href="/dashboard/news/<?=$new['id']?>/edit" class="link">Редактировать</a>
                     </td>
                  </tr>
                  <?php endforeach; ?>
               </tbody>
            </table>
         </div>
         <?php endif; ?>
      </div>
   </div>
   <?=$this->insert('partials/dashboard-nav')?>
</div>