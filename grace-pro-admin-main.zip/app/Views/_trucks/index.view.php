<?php $this->layout('layouts/default', ['title' => 'Dashboard - Trucks'])?>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Trucks</h1>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/truck-white.svg" alt="" />
                    </div>
                    <h4>Trucks</h4>
                    <div class="box__header-item box__header-item--right">
                        <a href="add/" class="btn"><i class="mi mi-add"></i></a>
                    </div>
                    <div class="box__header-item box__header-item--left">
                        <div class="field">
                            <input id="list-search" type="text" placeholder="Search" autocomplete="off" />
                        </div>
                    </div>
                </div>
                <?=$this->insert('partials/form-messages')?>
                    <?php if(empty($trucks)): ?>
                        <span class="box__message">No trucks</span>
                        <?php else: ?>

                            <div class="table">
                                <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
                                <table class="table__item" id="trucks-list" data-js="sortable-list">
                                    <tr class="no-user-select">
                                        <th class="sort" data-sort="truck-id">№<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="plate">Plate<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="make">Make<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="service">PM Service<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="FuelCard">FuelCard<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="trips"># of trips<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort " data-sort="inspection">Inspection<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="insurance">Insurance<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="insurance">Active<i class="mi mi-unfold-more"></i></th>
                                        <th>&nbsp;</th>
                                    </tr>
                                    <tbody class="list">
                                        <?php foreach($trucks as $truck_id => $truck): ?>
                                            <tr>
                                                <td class="truck-id">
                                                    <?=$truck_id?>
                                                </td>
                                                <td class="plate">
                                                    <?=$truck['Plate']?>
                                                </td>
                                                <td class="make">
                                                    <?=$truck['Make'] ?? '-'?>
                                                </td>
                                                <td class="service" data-order=<fmt:formatDate pattern="MM/dd/yyyy" value= "${myObject.myDate}" <?=($truck['Active'] ? 'data-due-to1' : '')?>>
                                                   <?=($truck['Service'] ?? '-')?>
                                                </td>
                                                </td>
                                                <td class="FuelCard">
                                                    <?=($truck['FuelCard'] ?? '-')?>
                                                   
                                                </td>
                                                <td class="trips">
                                                    <?=(isset($truck['Trips']) ? count(array_filter($truck['Trips'])) : 0)?>
                                                </td>
                                                <td class="inspection" data-order=<fmt:formatDate pattern="MM/dd/yyyy" value= "${myObject.myDate}" <?=($truck['Active'] ? 'data-due-to' : '')?>>
                                                    <?=$truck['Inspection']?>
                                                </td>
                                                <td class="insurance" data-order=<fmt:formatDate pattern="MM/dd/yyyy" value= "${myObject.myDate}" <?=($truck['Active'] ? 'data-due-to' : '')?>>
                                                    <?=$truck['Insurance']?>
                                                </td>
                                                <td class="active">
                                                    <?=($truck['Active'] ? 'Yes' : 'No')?>
                                                </td>
                                                <td><a href="<?=$truck_id?>/" class="link">Details</a></td>
                                            </tr>
                                            <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?>

            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>