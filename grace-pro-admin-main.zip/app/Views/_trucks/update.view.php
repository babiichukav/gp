<?php $this->layout('layouts/default', [
    'title' => isset($truck) ? 'Dashboard - Edit Truck #' . $truck['TruckNumber'] : 'Dashboard - Add Truck'
    ])?>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <?php if(isset($truck)): ?>
                <h1 class="dashboard__title">Edit Truck</h1>
                <?php else: ?>
                    <h1 class="dashboard__title">Add Truck</h1>
                    <?php endif; ?>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/truck-white.svg" alt="" />
                    </div>
                    <?php if(isset($truck)): ?>
                        <h4>Edit truck №<?=$truck['TruckNumber']?></h4>
                        <div class="box__header-item box__header-item--right">
	                        <?php if($_SESSION['user'] == "admin"): ?>
                            <a href="../delete/" data-js="confirm-btn" data-message="Are you sure? All truck related data like trips and expenses will be also deleted." class="btn" style="background:#c33d3d;"><i class="mi mi-delete"></i></a>
                            <?php endif; ?>
                        </div>
                        <?php else: ?>
                            <h4>Add new truck</h4>
                            <?php endif; ?>
                                <div class="box__header-item box__header-item--left">
                                    <a href="../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Back</a>
                                </div>
                </div>

                <div class="box__wrapper">
                    <?=$this->insert('partials/form-messages')?>
                    <form action="" enctype="multipart/form-data" method="post" data-js="form" class="<?=(isset($truck) ? 'edit-form' : '')?>">
                            <div class="grid">
                                <div class="grid__item grid__item--half">

                                    <div class="form">
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="text" name="truck[TruckNumber]" placeholder="Truck №" autocomplete="off" value="<?=$truck['TruckNumber'] ?? ''?>" <?=(isset($truck) ? 'readonly' : '')?>/>
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="text" name="truck[Make]" placeholder="Make & Model" autocomplete="off" value="<?=$truck['Make'] ?? ''?>" />
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="text" name="truck[Plate]" placeholder="Plate" autocomplete="off" value="<?=$truck['Plate'] ?? ''?>" />
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="text" name="truck[VIN]" placeholder="VIN" autocomplete="off" value="<?=$truck['VIN'] ?? ''?>" />
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="text" name="truck[FuelCard]" placeholder="FuelCard" autocomplete="off" value="<?=$truck['FuelCard'] ?? ''?>" />
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="field">
                                                <?php $options = [1=>"Active", 0=>"Inactive"]; ?>
                                                    <select name="truck[Active]" placeholder="Active">
                                                        <?php foreach($options as $value => $option): ?>
                                                            <option value="<?=$value?>" <?=(isset($truck) && $value == $truck['Active']) ? 'selected' : ''?>>
                                                                <?=$option?>
                                                            </option>
                                                            <?php endforeach; ?>
                                                    </select>
                                            </div>
                                        </div>
                                        

                                    </div>
                                </div>

                                <div class="grid__item grid__item--half">

                                    <div class="form">
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="text" data-js="datepicker" name="truck[Insurance]" placeholder="Insurance" autocomplete="off" value="<?=$truck['Insurance'] ?? ''?>" />
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="text" data-js="datepicker" name="truck[Inspection]" placeholder="Inspection" autocomplete="off" value="<?=$truck['Inspection'] ?? ''?>" />
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="file" name="truck[PDF]" placeholder="PDF" autocomplete="off" value="<?=$truck['PDF'] ?? ''?>" />
                                            </div>
                                        </div>
                                        <?php 
	                                        $os = array("113", "114", "117", "201", "204", "777", "202", "203");
											if (in_array($truck['TruckNumber'], $os)): ?>

                                            
                                                                                    <div class="form__row">
                                            <div class="field">
                                                <input type="text" data-js="datepicker" name="truck[Service]" placeholder="PM Service" autocomplete="off" value="<?=$truck['Service'] ?? ''?>" />
                                            </div>
                                        </div>
                                        </div>

                                        
                                        
                                         <?php endif; ?>
                                    </div>
                                </div>

                                <div class="grid__item grid__item--whole">
                                    <div class="form__row">
                                        <button class="btn">Save</button>
                                    </div>

                                </div>
                            </div>

                        </form>

                </div>

            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>