<?php $this->layout('layouts/default', ['title' => 'Dashboard - Truck Details - #' . $truck['TruckNumber']])?>
<script>
function showhide() {
  var div = document.getElementById("newpost");
  div.classList.toggle('hidden'); 
}

  </script>
  
  <style>
.hidden{
display : none;
}
</style>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Truck Details</h1>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/truck-white.svg" alt="" />
                    </div>
                    <h4>Truck #<?=$truck['TruckNumber']?></h4>
                    <div class="box__header-item box__header-item--left">
                        <a href="../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Back</a>
                    </div>
                    
                    <div class="box__header-item box__header-item--right">
                        <a href="edit/" class="btn"><i class="mi mi-edit"></i></a>&nbsp;
                        <?php if($_SESSION['user'] == "admin"): ?>
                        <a href="delete/" data-js="confirm-btn" data-message="Are you sure? All truck related data like trips and expenses will be also deleted." class="btn" style="background:#c33d3d;"><i class="mi mi-delete"></i></a>
                        <?php endif; ?>
                    </div>
                    
                </div>
                <?=$this->insert('partials/form-messages')?>
                    <div class="box__wrapper" style="padding-bottom:0;">

                        <div class="grid__item grid__item--one-quarter">
                            <div class="item-info">
                                <h6>Plate number</h6>
                                <span><?=$truck['Plate']?></span>
                            </div>
                            <div class="item-info">
                                <h6>Make</h6>
                                <span><?=$truck['Make']?></span>
                            </div>
                        </div>

                        <div class="grid__item grid__item--one-quarter">
                            <div class="item-info">
                                <h6>Inspection</h6>
                                <span><?=$truck['Inspection']?></span>
                            </div>
                            <div class="item-info">
                                <h6>Insurance</h6>
                                <span><?=$truck['Insurance']?></span>
                            </div>
                        </div>

                        <div class="grid__item grid__item--one-quarter">
                
                            <div class="item-info">
                                <h6>VIN</h6>
                                <span><?=$truck['VIN']?></span>
                            </div>
                            
                            <div class="item-info">
                            <h6>PDF</h6>
                            <span>
                            <?php if(!empty($truck['PDF'])): ?>
                            <a href="/dashboard/download/truck/<?=$truck['PDF']?>/?filename=truck_<?=$truck["TruckNumber"]?>.pdf" class="link">Download</a>
                            <?php else: ?>
                            -
                            <?php endif; ?>
                        </span>
                         </div>

<!--
                            <div class="item-info">
                            	<h6>Active</h6>
								<span><?=($truck['Active'] ? 'Yes' : 'No')?></span>
                        	</div>
-->
                        </div>
                        
                         <div class="grid__item grid__item--one-quarter">
                
                            <div class="item-info">
                                <h6>FuelCard</h6>
                                <span><?=($truck['FuelCard'] ?? '-')?></span>
                            </div>
                        </div>


                        <div class="grid__item grid__item--whole grid__item--no-gutters">
                            <div class="item-info">
                                <h6>Trips</h6>
                                <span><a href="trips/add/" class="btn"><i class="mi mi-add"></i></a></span>
                            </div>
                        </div>

                    </div>
                    <div class="grid__item grid__item--whole grid__item--no-gutters">
                        <?php if(empty($truck['Trips'])): ?>
                            <span class="box__message">No trips</span>
                            <?php else: ?>

                                <div class="table">
                                    <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
                                    <table class="table__item" id="trips-list" data-js="sortable-list">
                                        <tr class="no-user-select">
                                            <th class="sort" data-sort="trip-num">#<i class="mi mi-unfold-more"></i></th>
                                            <th class="sort" data-sort="date">Date<i class="mi mi-unfold-more"></i></th>
                                            <th class="sort" data-sort="from">From<i class="mi mi-unfold-more"></i></th>
                                            <th class="sort" data-sort="to">To<i class="mi mi-unfold-more"></i></th>
                                            <th class="sort" data-sort="driver">Driver<i class="mi mi-unfold-more"></i></th>
                                            <th class="sort" data-sort="fuel">Fuel<i class="mi mi-unfold-more"></i></th>
                                            <th class="sort " data-sort="money-note">MoneyNote<i class="mi mi-unfold-more"></i></th>
                                            <th class="sort" data-sort="loads-num"># of loads<i class="mi mi-unfold-more"></i></th>
                                            <th>&nbsp;</th>
                                        </tr>
                                        <tbody class="list">
                                            <?php foreach($truck['Trips'] as $trip): ?>
                                                <?php if(is_null($trip)) continue; ?>
                                                    <tr>
                                                        <td class="trip-num">
                                                            <?=$trip['TripNum']?>
                                                        </td>
                                                        <td class="date">
                                                            <?=$trip['Date']?>
                                                        </td>
                                                        <td class="from">
                                                            <?=$trip['From']?>
                                                        </td>
                                                        <td class="to">
                                                            <?=$trip['To']?>
                                                        </td>
                                                        <td class="driver">
                                                            <?php if(!empty($trip['Driver'])): ?>
                                                            <a href="/dashboard/drivers/<?=slugify($trip['Driver'])?>/" class="link">
                                                                <?=$trip['Driver']?>
                                                            </a>
                                                            <?php else: ?>
                                                                -
                                                            <?php endif;?>
                                                        </td>
                                                        <td class="fuel">
                                                            <?=$trip['Fuel']?>
                                                        </td>
                                                        <td class="money-note">
                                                            <?=$trip['MoneyNote']?>
                                                        </td>
                                                        <td class="loads-num">
                                                            <?=(isset($trip['Loads']) ? count(array_filter($trip['Loads'])) : 0)?>
                                                        </td>
                                                        
                                                        <td>
                                                            <?php if(!isset($trip['hide_details'])): ?>
                                                            <a href="trips/<?=$trip['TripNum']?>/" class="link">Details</a>
                                                            <?php endif; ?>
                                                        </td>
                                                        
                                                    </tr>
                                                    <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <?php endif; ?>

                    </div>

                    <div class="box__wrapper">
                        <div class="grid__item grid__item--whole grid__item--no-gutters">
                            <div class="item-info">
                                <h6>Expenses</h6>
                            </div>
                        </div>
                        <?php $expenses = $truck['Expenses'] ?? []; ?>
                        <?php if($_SESSION['user'] == "admin"): ?>
                        <div class="grid__item grid__item--whole grid__item--no-gutters">
                            <a href="expenses/edit/" class="btn"><i class="mi mi-edit"></i></a><br/><br/>
                        </div>
                        <?php endif; ?>
                        <div class="grid">
                        <div class="grid__item grid__item--one-quarter">
                            <div class="item-info">
                                <h6>IFTA Q1</h6>
                                <span><?=($expenses['IFTA_Q1'] ?? '-')?></span>
                            </div>
                            <div class="item-info">
                                <h6>IFTA Q2</h6>
                                <span><?=($expenses['IFTA_Q2'] ?? '-')?></span>
                            </div>
                            <div class="item-info">
                                <h6>IFTA Q3</h6>
                                <span><?=($expenses['IFTA_Q3'] ?? '-')?></span>
                            </div>
                            <div class="item-info">
                                <h6>IFTA Q4</h6>
                                <span><?=($expenses['IFTA_Q4'] ?? '-')?></span>
                            </div>
                            <div class="item-info">
                                <h6>&nbsp;</h6>
                                <span>&nbsp;</span>
                            </div>
                            <div class="item-info">
                                <h6>January</h6>
                                <span><?=($expenses['January'] ?? '-')?></span>
                            </div>
                            <div class="item-info">
                                <h6>May</h6>
                                <span><?=($expenses['May'] ?? '-')?></span>
                            </div>
                            <div class="item-info">
                                <h6>September</h6>
                                <span><?=($expenses['September'] ?? '-')?></span>
                            </div>
                        </div>

                        <div class="grid__item grid__item--one-quarter">
                            <div class="item-info">
                                <h6>Insurance</h6>
                                <span><?=($expenses['Insurance'] ?? "-")?></span>
                            </div>
                            <div class="item-info">
                                <h6>Insurance (Status)</h6>
                                <span>
                                    <?php if(isset($expenses['InsuranceStatus'])): ?>
                                        <?=($expenses['InsuranceStatus'] == 'true' ? 'Paid' : 'Not paid')?>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </span>
                            </div>
                            <div class="item-info">
                                <h6>Insurance (Notes)</h6>
                                <span><?=($expenses['InsuranceNotes'] ?? "-")?></span>
                            </div>
                            <div class="item-info">
                                <h6>&nbsp;</h6>
                                <span>&nbsp;</span>
                            </div>
                            <div class="item-info">
                                <h6>&nbsp;</h6>
                                <span>&nbsp;</span>
                            </div>
                            <div class="item-info">
                                <h6>February</h6>
                                <span><?=($expenses['February'] ?? '-')?></span>
                            </div>
                            <div class="item-info">
                                <h6>June</h6>
                                <span><?=($expenses['June'] ?? '-')?></span>
                            </div>
                            <div class="item-info">
                                <h6>October</h6>
                                <span><?=($expenses['October'] ?? '-')?></span>
                            </div>
                        </div>

                        <div class="grid__item grid__item--one-quarter">
                            <div class="item-info">
                                <h6>Logbook</h6>
                                <span><?=($expenses['Logbook'] ?? "-")?></span>
                            </div>
                            <div class="item-info">
                                <h6>Expenses</h6>
                                <span><?=($expenses['Expenses'] ?? "-")?></span>
                            </div>
                            <div class="item-info">
                                <h6>Annual Inspection</h6>
                                <span><?=($expenses['AnnualInspection'] ?? "-")?></span>
                            </div>
                            <div class="item-info">
                                <h6>&nbsp;</h6>
                                <span>&nbsp;</span>
                                
                            </div>
                            <div class="item-info">
                                <h6>&nbsp;</h6>
                                <span>&nbsp;</span>
                            </div>
                            <div class="item-info">
                                <h6>March</h6>
                                <span><?=($expenses['March'] ?? '-')?></span>
                            </div>
                            <div class="item-info">
                                <h6>July</h6>
                                <span><?=($expenses['July'] ?? '-')?></span>
                            </div>
                            <div class="item-info">
                                <h6>November</h6>
                                <span><?=($expenses['November'] ?? '-')?></span>
                            </div>
                        </div>

                        <div class="grid__item grid__item--one-quarter">
                            <div class="item-info">
                                <h6>Total Lumper</h6>
                                <span>$<?=$total_lumper?></span>
                            </div>
                            <div class="item-info">
                                <h6>Total Expenses</h6>
                                <span>$<?=$total_expenses?></span>
                            </div>
                            <?php if($_SESSION['user'] == "admin"): ?>
                            <div class="item-info">
                                <h6>Wallet</h6>
                                <div id="newpost"  class="hidden">
								<p><span>$<?=$total_wallet?></span></p>
  								</div>
                                <button id="button" onclick="showhide()">Click Me</button>
                            </div>
                            <div class="item-info">
                                <h6>&nbsp;</h6>
                                <span>&nbsp;</span>
                            </div>
                            <div class="item-info">
                                <h6>&nbsp;</h6>
                                <span>&nbsp;</span>
                                <br>
                            </div>
                            <div class="item-info">
                                <h6>April</h6>
                                <span><?=($expenses['April'] ?? '-')?></span>
                            </div>
                            <div class="item-info">
                                <h6>August</h6>
                                <span><?=($expenses['August'] ?? '-')?></span>
                            </div>
                            <div class="item-info">
                                <h6>December</h6>
                                <span><?=($expenses['December'] ?? '-')?></span>
                            </div>
<!--  date('F') -->
                            <?php endif; ?>
                        </div>
                    </div>
            </div>


     <div class="box__wrapper">
                        <div class="grid__item grid__item--whole grid__item--no-gutters">
                            <div class="item-info">
<!--                                 <h6>Profit</h6> -->
                            </div>
                        </div>
                        <div class="grid">
                        <div class="grid__item grid__item--one-quarter">
	                        <div class="item-info">
                                <h6>Total fuel</h6>
                                <span><?=($truck['Profit']['fuelTotal'] ?? '$0')?></span>
                            </div>
                            <div class="item-info">
                                <h6>Total trip</h6>
                                <span><?=($truck['Profit']['tripTotal'] ?? '$0')?></span>
                            </div>
                            <div class="item-info">
                                <h6>Dispatch fee (%)</h6>
                                <span><?=($truck['Profit']['dispatchFee'] ?? '$0')?></span>
                            </div>
                        </div>


                    </div>
            </div>


        </div>
    </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>