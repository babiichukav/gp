<?php $this->layout('layouts/default', [ 'title' => isset($load) ? 'Dashboard - Edit Product Details' : 'Dashboard - Add Product'  ]) ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="https://unpkg.com/location-picker/dist/location-picker.min.js"></script>


<div class="dashboard grid grid--wrapped">
   <div class="grid__item grid__item--whole">
      <h1 class="dashboard__title">Товары</h1>
   </div>
   <div class="grid__item grid__item--whole">
      <div class="box">
         <div class="box__header">
            <div class="box__header-circle">
               <img src="/img/load-white.svg" alt="" />
            </div>
            <?php if(isset($load)): ?>
            <h4>Редактировать товар #<?=$load['id']?></h4>
            <div class="box__header-item box__header-item--left">
               <?php if(!empty($trip_id)): ?>
               <a href="../../../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Назад</a>
               <?php else: ?>
               <a href="../../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Назад</a>
               <?php endif; ?>
            </div>
            <div class="box__header-item box__header-item--right">
               <a href="../delete/" data-js="confirm-btn" data-message="Вы уверены?" class="btn" style="background:#c33d3d;"><i class="mi mi-delete"></i></a>
            </div>
            <?php else: ?>
            <h4>Добавить нового сабюзера</h4>
            <div class="box__header-item box__header-item--left">
               <a href="../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Назад</a>
            </div>
            <?php endif; ?>
         </div>
         <div class="box__wrapper">
            <?=$this->insert('partials/form-messages')?>
            <form action="" enctype="multipart/form-data" method="post" data-js="form" class="<?=(isset($load) ? 'edit-form' : '')?>">
               <div class="grid">
                  <div class="grid__item grid__item--half">                     										 
					 
                     <div class="form__row">
                        <div class="field">
                           <input type="text" name="load[name]" placeholder="ФИО" autocomplete="off" value="<?=$load['name'] ?? ''?>"/>
                        </div>
                     </div>
                     
                     <div class="form__row">
                        <div class="field">
                           <input type="text" name="load[EDRPOU]" placeholder="EDRPOU Код" autocomplete="off" value="<?=$load['EDRPOU'] ?? ''?>"/>
                        </div>
                     </div>

                     
                                        
                  </div>
                  <div class="grid__item grid__item--half">
                  
                     <div class="form__row">
                        <div class="field">
                           <input type="text" name="load[code]" placeholder="Код" autocomplete="off" value="<?=$load['code'] ?? time()?>"/>
                        </div>
                     </div>
                     
                     <div class="form__row">
                        <div class="field">
                           <input type="text" name="load[address]" placeholder="Адрес" autocomplete="off" value="<?=$load['address'] ?? ''?>"/>
                        </div>
                     </div>


                     <div class="form__row hidden">
                        <div class="field">
                           <input type="text" name="load[id]" placeholder="ID" autocomplete="off" value="<?=$id ?? ''?>"/>
                        </div>
                     </div>
                                       
                    
                  </div>
                  <br><br>
               </div>
               <br>
               <div class="grid__item grid__item--whole">
                  <center>
                     <div class="form__row"><button class="btn">Сохранить</button></div>
                  </center>
         </div>
         </form> 
      </div>
   </div>
</div>


<?=$this->insert('partials/dashboard-nav')?> </div>