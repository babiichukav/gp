<?php $this->layout('layouts/default', ['title' => 'Dashboard - Trailer Details - #' . $trailer['TrailerNumber']])?>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Trailer Details</h1>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/trailer-white.svg" alt="" />
                    </div>
                    <h4>Trailer #<?=$trailer['TrailerNumber']?></h4>
                    <div class="box__header-item box__header-item--left">
                        <a href="../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Back</a>
                    </div>
                   
                    <div class="box__header-item box__header-item--right">
                        <a href="edit/" class="btn"><i class="mi mi-edit"></i></a>&nbsp;
                         <?php if($_SESSION['user'] == "admin"): ?>
                        <a href="delete/" data-js="confirm-btn" data-message="Are you sure? All trailer related data like trips and expenses will be also deleted." class="btn" style="background:#c33d3d;"><i class="mi mi-delete"></i></a>
                        <?php endif; ?>
                    </div>
                    
                </div>
                <?=$this->insert('partials/form-messages')?>
                    <div class="box__wrapper" style="padding-bottom:0;">

                        <div class="grid__item grid__item--one-quarter">
                            <div class="item-info">
                                <h6>Plate number</h6>
                                <span><?=$trailer['Plate']?></span>
                            </div>
                            <div class="item-info">
                                <h6>Make</h6>
                                <span><?=$trailer['Make']?></span>
                            </div>
                        </div>

                        <div class="grid__item grid__item--one-quarter">
                            <div class="item-info">
                                <h6>Inspection</h6>
                                <span><?=$trailer['Inspection']?></span>
                            </div>
                            <div class="item-info">
                                <h6>Insurance</h6>
                                <span><?=$trailer['Insurance']?></span>
                            </div>
                        </div>

                        <div class="grid__item grid__item--one-quarter">
                            <div class="item-info">
                                <h6>VIN</h6>
                                <span><?=$trailer['VIN']?></span>
                            </div>
                            <div class="item-info">
                            	<h6>Active</h6>
								<span><?=($trailer['Active'] ? 'Yes' : 'No')?></span>
                        	</div>
                        	<div class="item-info">
                            <h6>PDF</h6>
                            <span>
                            <?php if(!empty($trailer['PDF'])): ?>
                            <a href="/dashboard/download/trailer/<?=$trailer['PDF']?>/?filename=trailer_<?=$trailer["TrailerNumber"]?>.pdf" class="link">Download</a>
                            <?php else: ?>
                            -
                            <?php endif; ?>
                        </span>
                         </div>    
                        </div>  
                                         
                    </div>
        </div>
    </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>