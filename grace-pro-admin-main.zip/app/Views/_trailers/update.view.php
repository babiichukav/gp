<?php $this->layout('layouts/default', [
    'title' => isset($trailer) ? 'Dashboard - Edit Trailer #' . $trailer['TrailerNumber'] : 'Dashboard - Add Trailer'
    ])?>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <?php if(isset($trailer)): ?>
                <h1 class="dashboard__title">Edit Trailer</h1>
                <?php else: ?>
                    <h1 class="dashboard__title">Add Trailer</h1>
                    <?php endif; ?>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/trailer-white.svg" alt="" />
                    </div>
                    <?php if(isset($trailer)): ?>
                        <h4>Edit trailer №<?=$trailer['TrailerNumber']?></h4>
                        
                        <div class="box__header-item box__header-item--right">
	                        <?php if($_SESSION['user'] == "admin"): ?>
                            <a href="../delete/" data-js="confirm-btn" data-message="Are you sure? All trailer related data like trips and expenses will be also deleted." class="btn" style="background:#c33d3d;"><i class="mi mi-delete"></i></a>
                        <?php endif; ?>
                        </div>
                        <?php else: ?>
                            <h4>Add new trailer</h4>
                            <?php endif; ?>
                                <div class="box__header-item box__header-item--left">
                                    <a href="../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Back</a>
                                </div>
                </div>

                <div class="box__wrapper">
                    <?=$this->insert('partials/form-messages')?>
                    <form action="" enctype="multipart/form-data" method="post" data-js="form" class="<?=(isset($trailer) ? 'edit-form' : '')?>">
                            <div class="grid">
                                <div class="grid__item grid__item--half">

                                    <div class="form">
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="text" name="trailer[TrailerNumber]" placeholder="Trailer №" autocomplete="off" value="<?=$trailer['TrailerNumber'] ?? ''?>" <?=(isset($trailer) ? 'readonly' : '')?>/>
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="text" name="trailer[Make]" placeholder="Make & Model" autocomplete="off" value="<?=$trailer['Make'] ?? ''?>" />
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="text" name="trailer[Plate]" placeholder="Plate" autocomplete="off" value="<?=$trailer['Plate'] ?? ''?>" />
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="text" name="trailer[VIN]" placeholder="VIN" autocomplete="off" value="<?=$trailer['VIN'] ?? ''?>" />
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="field">
                                                <?php $options = ["true"=>"Active", "false"=>"Inactive"]; ?>
                                                    <select name="trailer[Active]" placeholder="Active">
                                                        <?php foreach($options as $value => $option): ?>
                                                            <option value="<?=$value?>" <?=(isset($trailer) && $value == $trailer['Active']) ? 'selected' : ''?>>
                                                                <?=$option?>
                                                            </option>
                                                            <?php endforeach; ?>
                                                    </select>
                                            </div>
                                        </div>

                                    </div>
                                </div>

                                <div class="grid__item grid__item--half">

                                    <div class="form">
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="text" data-js="datepicker" name="trailer[Insurance]" placeholder="Insurance" autocomplete="off" value="<?=$trailer['Insurance'] ?? ''?>" />
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="text" data-js="datepicker" name="trailer[Inspection]" placeholder="Inspection" autocomplete="off" value="<?=$trailer['Inspection'] ?? ''?>" />
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="file" name="trailer[PDF]" placeholder="PDF" autocomplete="off" value="<?=$trailer['PDF'] ?? ''?>" />
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="grid__item grid__item--whole">
                                    <div class="form__row">
                                        <button class="btn">Save</button>
                                    </div>

                                </div>
                            </div>

                        </form>

                </div>

            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>