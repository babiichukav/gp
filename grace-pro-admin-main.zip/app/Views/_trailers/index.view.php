<?php $this->layout('layouts/default', ['title' => 'Dashboard - Trailers'])?>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Trailers</h1>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/trailer-white.svg" alt="" />
                    </div>
                    <h4>Trailers</h4>
                    <div class="box__header-item box__header-item--right">
                        <a href="add/" class="btn"><i class="mi mi-add"></i></a>
                    </div>
                    <div class="box__header-item box__header-item--left">
                        <div class="field">
                            <input id="list-search" type="text" placeholder="Search" autocomplete="off" />
                        </div>
                    </div>
                </div>
                <?=$this->insert('partials/form-messages')?>
                    <?php if(empty($trailers)): ?>
                        <span class="box__message">No trailers</span>
                        <?php else: ?>

                            <div class="table">
                                <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
                                <table class="table__item" id="trailers-list" data-js="sortable-list">
                                    <tr class="no-user-select">
                                        <th class="sort" data-sort="trailer-id">№<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="plate">Plate<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="make">Make<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="vin">VIN<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort " data-sort="inspection">Inspection<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="insurance">Insurance<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="insurance">Active<i class="mi mi-unfold-more"></i></th>
                                        <th>&nbsp;</th>
                                    </tr>
                                    <tbody class="list">
                                        <?php foreach($trailers as $trailer_id => $trailer): ?>
                                            <tr>
                                                <td class="trailer-id">
                                                    <?=$trailer_id?>
                                                </td>
                                                <td class="plate">
                                                    <?=$trailer['Plate']?>
                                                </td>
                                                <td class="make">
                                                    <?=$trailer['Make'] ?? '-'?>
                                                </td>
                                                <td class="vin">
                                                    <?=$trailer['VIN']?>
                                                </td>
                                                <td class="inspection" data-order=<fmt:formatDate pattern="MM/dd/yyyy" value= "${myObject.myDate}" <?=($trailer['Active'] ? 'data-due-to' : '')?>>
                                                    <?=$trailer['Inspection']?>
                                                </td>
                                                <td class="insurance" data-order=<fmt:formatDate pattern="MM/dd/yyyy" value= "${myObject.myDate}" <?=($trailer['Active'] ? 'data-due-to' : '')?>>
                                                    <?=$trailer['Insurance']?>
                                                </td>
                                                <td class="active">
                                                    <?=($trailer['Active'] ? 'Yes' : 'No')?>
                                                </td>
                                                <td><a href="<?=$trailer_id?>/" class="link">Details</a></td>
                                            </tr>
                                            <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?>

            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>