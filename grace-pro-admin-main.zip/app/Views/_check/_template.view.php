<style>

li{
    clear:both;
}
li span:last-child{
    float:right;
}
li span:first-child{
    float:left;
}
table{
    position: relative;
    margin-left: -8px;
    font-family: sans-serif;
    font-size:12px;
    width:102%;
    border-collapse: collapse;
}
.frame{
    position: absolute;
    top:-20px;
    left:-34px;
    width:8in;
    height:3in;
    border:1px solid transparent;
}
table td{
    border:0px solid #000;
}
.field * {
    vertical-align: bottom;
}
.field{
    display: inline;
}
.field span{
    display:inline-block;
    color:inherit;
}
.field input{
    display: inline-block;
    text-align: center;
    border:none;
    outline:none;
    font-size:15px;
    margin-bottom: 4px;
    border-bottom: 1px solid #000;
}
</style>

<?php if($print_check=="1"): ?>
<table>
<tr>
    <td align="right" colspan="99" style="font-family:monospace;font-weight:bolder;letter-spacing:0px;font-size:15px;"><?=$check['num']?></td>
</tr>
<tr>
    <td width="65%" align="center"><img src="truck.png" alt="" width="120px" style="display:inline-block;"><div style="line-height:14px;margin-left:64px;text-align:center;display:inline-block;">
        <span style="font-weight: bold;">UKR TRANSPORT, LLC</span><br/>2437 SW 30TH CT<br/>GRESHAM, OR 97080<br/>5039120381</div></td>
    <td width="35%" align="center" valign="bottom">
<div class="field" style="margin-left:48px;">
        <span>DATE</span><input type="text" value="<?=$check['date']?>">
</div>
    </td>
</tr>
<tr>
    <td colspan="2" style="padding-top: 0px;">

        <div class="field">
        <span style="width:80px;display:inline-block;line-height:12px;margin-top: 2px;">PAY TO THE ORDER OF</span><input style="width:466px;border-right:1px solid #000;" type="text" value="<?=$check['to']?>">
</div>
&nbsp;
        <div style="display:inline-block;vertical-align: bottom;width:140px;">
        <span style="font-size:20px;margin-right:4px;">$</span>
        <input type="text" value="<?=$check['total']?>" style="width:100%;vertical-align: bottom;text-align:center;margin-top:1px;font-size:18px;border:3px solid #000;"></div>
    </div>

    </td>
</tr>

<tr>
    <td colspan="2" style="padding-top:2px;">
        <div class="field">
         <input type="text" value="<?=$check['total_text']?>" style="width:548px;"><span>DOLLARS</span>
     </div>
    </td>
</tr>
<tr>
    <td height="70px;" width="40%" style="vertical-align: middle;">
 <div class="field">
         <span style="padding-top: 20px;">FOR</span><input type="text" value="<?=$check['for']?>" style="width:260px;">
     </div>
    </td>
    <td height="70px;" width="60%" align="left" style="vertical-align: middle;">
         <div class="field">
            <span style="padding-top: 20px;">&nbsp;</span><input type="text" value="" style="width:250px;">
     </div>
    </td>
</tr>
<tr>
    <td colspan="99" align="center" style="padding-top: 14px;position: relative;">
        <img src="img/temp/<?=$check_font_image?>" alt="" style="width:400px;height:30px;position: absolute;top:40px;left:50%;transform: translateX(-50%);">
    </td>
</tr>
<div class="frame">
    
    <div style="opacity:0.2;display:none;width:8in;height:1.6in;background:red;position: absolute;top:0;left:0;"></div>

</div>
<img src="us-bank.png" alt="" width="130px" style="position: absolute;top:0px;right:68px;">
</table>
<br/>
<br/>
<hr style="border:none;border-top:1px dashed #ccc;"/>
<?php endif; ?>
<?php if(empty($check_only)): ?>
<br/>
<br/>
<b><center>Ukrtransport LLC - Check description</center></b>
<hr>
<ol type="1">
  <li><span>Total trip's</span><span style="float:right;"><?=number_format((float)$trips_total, 2, '.', ',')?></span></li>
  <?php foreach($loads as $load): ?>
    <li>
        <span><?=$load['From']?> to <?=$load['To']?></span>
        <span><?=number_format((float)$load['LoadTotal'], 2, '.', ',')?></span>
    </li>
  <?php endforeach; ?>
  <?php foreach($fields as $field): ?>
    <li>
        <span><?=$field['Name']?></span>
        <span><?=number_format((float)$field['Value'], 2, '.', ',')?></span>
    </li>
  <?php endforeach; ?>

    <li>
    <span>Total to pay</span>
    <span><?=number_format((float)$total_to_pay, 2, '.', ',')?></span>
    </li>
    <li>
    <span>Truck #<?=$truck_id?></span>
    </li>
    <li>
    <span>Trip #<?=$trip_id?></span>
    </li>
    <br><br>
    <span><?=date('d/m/y');?></span>
</ol>
<?php endif; ?>
