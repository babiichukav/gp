<?php $this->layout('layouts/default', ['title' => 'Page Not Found'])?>

    <style>
        .box__header {
            padding-top: 40px;
        }
        .box--year{
            display: inline-block;
            width:210px;
            margin-right: 20px;
        }
        .box--year a{
            padding: 10px;
            padding-top: 30px;
            text-align: right;
            font-weight: 200;
            display: block;
            color: #fff;
            font-size: 32px;
            transition: 200ms;
        }
        .box--year a span{
            display: block;
            font-size: 20px;
        }
        .box--year a:hover{
            color: #1261f2;
        }
        
    </style>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Archive</h1>
        </div>
        <div class="grid__item grid__item--whole">
            <?php if(empty($years)): ?>
            <div class="box">
                <div class="box__wrapper">
                    <p class="info-box">At the end of the year all current data will be placed here. It's empty for now.</p>
                </div>
            </div>
            <?php else: ?>
            <?php foreach($years as $year): ?>
                <div class="box box--year">
                        <a href="/dashboard/archive/<?=$year?>/"><span>Year</span><?=$year?></a>
                </div>
            <?php endforeach; ?>
            <?php endif; ?>
        </div>
        <?=$this->insert('partials/dashboard-nav')?>
    </div>