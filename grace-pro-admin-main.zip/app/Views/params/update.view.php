<?php $this->layout('layouts/default', [
    'title' => 'Dashboard - Edit Params #' . $brand . $id 
    ])?>
    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Парамеры товара</h1>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/expenses-white.svg" alt="" />
                    </div>
                    <h4><?=$brand?> | <?=$id?></h4>
                    <div class="box__header-item box__header-item--left">
                        <a href="../../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Back</a>
                    </div>
                </div>
                <div class="box__wrapper">
                    <?=$this->insert('partials/form-messages')?>
                                        <form action="" enctype="multipart/form-data" method="post" data-js="form" class="<?=(isset($promocodes) ? 'edit-form' : '')?>">

                    <div class="grid">
	                    
                    <div class="grid__item grid__item--half">
                        
                        <div class="form">
                            <div class="form__row">
                                <div class="field">
                                    <input type="text" name="promocodes[name]" placeholder="Название" autocomplete="off" value="<?=$data['name'] ?? ''?>"/>
                                </div>
                            </div>
                            <div class="form__row">
                                <div class="field">
                                    <input type="text" name="promocodes[price]" placeholder="Цена" autocomplete="off" value="<?=$data['price'] ?? ''?>"/>
                                </div>
                            </div>


							<div class="form__row">
                                <div class="field">
                                    <input type="text" name="promocodes[vendor]" placeholder="Артикул" autocomplete="off" value="<?=$data['vendor'] ?? ''?>"/>
                                </div>
                            </div>

							                            
                        </div>
                    </div>
                    <div class="grid__item grid__item--half">
                        <div class="form">
                            <div class="form__row">
                        <div class="field">
                           <input type="text" placeholder="Name" value="Фото" autocomplete="off" readonly />
                           <input type="file" name="promocodes[logo]" placeholder="Фото" accept="image/*" autocomplete="off" value="<?=$promocodes['logo'] ?? ''?>" />
                        </div>
                     </div>
                           
                           
                        </div>
                    </div>
                </div>
                

                    <div class="grid__item grid__item--whole">
                            <div class="form__row">
                                <button class="btn">Сохранить</button>
                            </div>

                    </div>

                    </form>




                            

                </div>



            </div>

        </div>
 


        <?=$this->insert('partials/dashboard-nav')?>

    </div>


