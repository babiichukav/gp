<?php $this->layout('layouts/default', [
    'title' => isset($contract) ? 'Dashboard - Edit Contract - ' . $contract['Company'] : 'Dashboard - Add Contract'
    ])?>
    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <?php if(isset($contract)): ?>
                <h1 class="dashboard__title">Edit Contract</h1>
                <?php else: ?>
                    <h1 class="dashboard__title">Add Contract</h1>
                    <?php endif; ?>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/contract-white.svg" alt="" />
                    </div>
                    <?php if(isset($contract)): ?>
                        <h4><?=$contract['Company']?></h4>
                        <div class="box__header-item box__header-item--left">
                            <a href="../../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Back</a>
                        </div>
                        <div class="box__header-item box__header-item--right">
                            <a href="../delete/" data-js="confirm-btn" data-message="Are you sure? All contract related data will be also deleted." class="btn" style="background:#c33d3d;"><i class="mi mi-delete"></i></a>
                        </div>
                        <?php else: ?>
                            <h4>Add new contract</h4>
                            <?php endif; ?>
                </div>
                <div class="box__wrapper">
                    <?=$this->insert('partials/form-messages')?>
                        <form action="" method="post" data-js="form" class="<?=(isset($contract) ? 'edit-form' : '')?>" enctype="multipart/form-data">
                            <div class="grid">
                                <div class="grid__item grid__item--half">

                                    <div class="form">
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="text" name="contract[Company]" placeholder="Company" autocomplete="off" value="<?=$contract['Company'] ?? ''?>" <?=(isset($contract) ? 'readonly' : '')?>/>
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="text" name="contract[ContractNumber]" placeholder="MC Number" autocomplete="off" value="<?=$contract['ContractNumber'] ?? ''?>" />
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="text" data-js="datepicker" name="contract[Start]" placeholder="Start" autocomplete="off" value="<?=$contract['Start'] ?? ''?>" />
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="text" data-js="datepicker" name="contract[End]" placeholder="End" autocomplete="off" value="<?=$contract['End'] ?? ''?>" />
                                            </div>
                                        </div>
                                        <div class="form__row">
                                            <div class="field">
                                                <input type="file" name="contract[PDF]" placeholder="PDF" autocomplete="off" value="<?=$contract['PDF'] ?? ''?>" />
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="grid__item grid__item--whole">
                                    <div class="form__row">
                                        <button class="btn">Save</button>
                                    </div>

                                </div>
                            </div>

                        </form>

                </div>

            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>