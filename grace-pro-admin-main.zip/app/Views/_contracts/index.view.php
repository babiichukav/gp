<?php $this->layout('layouts/default', ['title' => 'Dashboard - Contracts'])?>

    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Contracts</h1>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/contract-white.svg" alt="" />
                    </div>
                    <h4>Contracts</h4>
                    <div class="box__header-item box__header-item--right">
                        <a href="add/" class="btn"><i class="mi mi-add"></i></a>
                    </div>
                    <div class="box__header-item box__header-item--left">
                        <div class="field">
                            <input id="list-search" type="text" placeholder="Search" autocomplete="off" />
                        </div>
                    </div>
                </div>
                <?=$this->insert('partials/form-messages')?>
                    <?php if(empty($contracts)): ?>
                        <span class="box__message">No contracts</span>
                        <?php else: ?>

                            <div class="table">
                                <span class="table__message hidden show-on-mobile">Scroll left to view all data</span>
                                <table class="table__item" id="contracts-list" data-js="sortable-list">
                                    <tr class="no-user-select">
                                        <th class="sort" data-sort="company">Company<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="start">MC Number<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="start">Start<i class="mi mi-unfold-more"></i></th>
                                        <th class="sort" data-sort="end">End<i class="mi mi-unfold-more"></i></th>
                                        <th>PDF</th>
                                        <th>&nbsp;</th>
                                    </tr>
                                    <tbody class="list">
                                        <?php foreach($contracts as $contract_name => $contract): ?>
                                            <?php $contract['slug'] = slugify($contract_name) ?>
                                                <tr>
                                                    <td class="company">
                                                        <?=($contract['Company'] ?? '')?>
                                                    </td>
                                                    <td class="ContractNumber">
                                                        <?=($contract['ContractNumber'] ?? '')?>
                                                    </td>
                                                    <td class="start" data-type="date">
                                                        <?=($contract['Start'] ?? '')?>
                                                    </td>
                                                    <td class="end" data-type="date" data-due-to>
                                                        <?=($contract['End'] ?? '')?>
                                                    </td>
                                                    <td class="pdf">
                                                        <?php if(!empty($contract['PDF'])): ?>
                                                            <a href="/dashboard/download/contracts/<?=$contract['PDF']?>/?filename=<?=$contract['Company']?>.pdf" class="link">Download</a>
                                                            <?php else: ?>
                                                                -
                                                                <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($_SESSION['user'] == "admin"): ?>
                                                        <a href="<?=$contract['slug']?>/edit/" class="link">Edit</a>&nbsp;
                                                        <a href="<?=$contract['slug']?>/delete/" class="link">Delete</a>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?>

            </div>

        </div>

        <?=$this->insert('partials/dashboard-nav')?>

    </div>