<?php $this->layout('layouts/default', [
    'title' => 'Dashboard - Edit Addresses #' . $id 
    ])?>
    <div class="dashboard grid grid--wrapped">

        <div class="grid__item grid__item--whole">
            <h1 class="dashboard__title">Адресная доставка</h1>
        </div>

        <div class="grid__item grid__item--whole">

            <div class="box">
                <div class="box__header">
                    <div class="box__header-circle">
                        <img src="/img/users-white.svg" alt="" />
                    </div>
                    <h4>Адресная доставка | <?=$id?></h4>
                    <div class="box__header-item box__header-item--left">
                        <a href="../../" class="btn"><i class="mi mi-arrow-back"></i>&nbsp;Назад</a>
                    </div>
                </div>
                <div class="box__wrapper">
                    <?=$this->insert('partials/form-messages')?>
                                        <form action="" method="post" data-js="form" class="edit-form">

                    <div class="grid">
	                    
                    <div class="grid__item grid__item--half">
                        
                        <div class="form">
                            <div class="form__row">
                                <div class="field">
                                    <input type="text" name="np[name]" placeholder="Название" autocomplete="off" value=""/>
                                </div>
                            </div>
                            <div class="form__row">
                                <div class="field">
                                    <input type="text" name="np[city]" placeholder="Город" autocomplete="off" value=""/>
                                </div>
                            </div>
                            <div class="form__row">
                                <div class="field">
                                    <input type="text" name="np[note]" placeholder="Примечание" autocomplete="off" value=""/>
                                </div>
                            </div>
							                            
                        </div>
                    </div>
                    <div class="grid__item grid__item--half">
                        <div class="form">
                           
                            <div class="form__row">
                                <div class="field">
                                    <input type="text" name="np[street]" placeholder="Улица" autocomplete="off" value=""/>
                                </div>
                            </div>
                            <div class="form__row">
                                <div class="field">
                                    <input type="text" name="np[building]" placeholder="Дом" autocomplete="off" value=""/>
                                </div>
                            </div>
                            <div class="form__row">
                                <div class="field">
                                    <input type="text" name="np[apt]" placeholder="Квартира" autocomplete="off" value=""/>
                                </div>
                            </div>
                           
                        </div>
                    </div>
                </div>
                

                    <div class="grid__item grid__item--whole">
                            <div class="form__row">
                                <button class="btn">Сохранить</button>
                            </div>

                    </div>

                    </form>




                            

                </div>



            </div>

        </div>
 


        <?=$this->insert('partials/dashboard-nav')?>

    </div>


