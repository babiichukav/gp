<?php

use App\Middleware\ValidationErrorsMiddleware;
// Application middleware

$app->add(new ValidationErrorsMiddleware);
