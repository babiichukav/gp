<?php

namespace App\Middleware;

class ValidationErrorsMiddleware
{

    public function __invoke($request, $response, $next)
    {

        if (app('flash')->hasMessage('form_errors')) {
            app('view')->addData(['form_errors' => app('flash')->getFirstMessage('form_errors')]);
        }

        if (app('flash')->hasMessage('form_messages')) {
            app('view')->addData(['form_messages' => app('flash')->getFirstMessage('form_messages')]);
        }


        if (!empty($_POST)) {
            app('flash')->addMessage("old_input", $_POST);
        }

        if (app('flash')->hasMessage('old_input')) {
            app('view')->addData(['old_input' => app('flash')->getFirstMessage('old_input')]);
        }

        return $next($request, $response);
    }

}
