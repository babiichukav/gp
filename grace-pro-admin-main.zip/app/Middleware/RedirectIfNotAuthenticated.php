<?php

namespace App\Middleware;

class RedirectIfNotAuthenticated
{

    protected $redirectTo = '/';


    public function __invoke($request, $response, $next)
    {

        if (!isset($_SESSION['user'])) {
            return redirect($this->redirectTo);
        }

        return $next($request, $response);
    }
}
