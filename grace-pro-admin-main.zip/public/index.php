<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

set_time_limit(0);
date_default_timezone_set('UTC');

require __DIR__ . '/../vendor/autoload.php';

session_start();

define("EXPORT_BACKUP_EMAIL", "ukrtransinc2019@gmail.com");

$_POST = filter_var($_POST, FILTER_CALLBACK, ['options' => 'trim']);

// try{
    require __DIR__ . '/../app/bootstrap.php';
// }catch(Throwable $e){
//     $message = 'Message: ' . $e->getMessage() . "\n\n" . 
//                 'Stack Trace: '. $e->getTraceAsString();

//     $log = app('logger')->error($message);

//     echo 'Application error. See logs.';
// }


