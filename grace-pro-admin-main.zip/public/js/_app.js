/*! populate.js v1.0.2 by @dannyvankooten | MIT license */
;(function(root) {

    /**
     * Populate form fields from a JSON object.
     *
     * @param form object The form element containing your input fields.
     * @param data array JSON data to populate the fields with.
     * @param basename string Optional basename which is added to `name` attributes
     */
    var populate = function( form, data, basename) {

        for(var key in data) {

            if( ! data.hasOwnProperty( key ) ) {
                continue;
            }

            var name = key;
            var value = data[key];

                        if ('undefined' === typeof value) {
                            value = '';
                        }

                        if (null === value) {
                            value = '';
                        }

            // handle array name attributes
            if(typeof(basename) !== "undefined") {
                name = basename + "[" + key + "]";
            }

            if(value.constructor === Array) {
                name += '[]';
            } else if(typeof value == "object") {
                populate( form, value, name);
                continue;
            }

            // only proceed if element is set
            var element = form.elements.namedItem( name );
            if( ! element ) {
                continue;
            }

            var type = element.type || element[0].type;

            switch(type ) {
                default:
                    element.value = value;
                    break;

                case 'radio':
                case 'checkbox':
                    for( var j=0; j < element.length; j++ ) {
                        element[j].checked = ( value.indexOf(element[j].value) > -1 );
                    }
                    break;

                case 'select-multiple':
                    var values = value.constructor == Array ? value : [value];

                    for(var k = 0; k < element.options.length; k++) {
                        element.options[k].selected |= (values.indexOf(element.options[k].value) > -1 );
                    }
                    break;

                case 'select':
                case 'select-one':
                    element.value = value.toString() || value;
                    break;
                case 'date':
                        element.value = new Date(value).toISOString().split('T')[0];    
                    break;
            }

        }

    };

    // Play nice with AMD, CommonJS or a plain global object.
    if ( typeof define == 'function' && typeof define.amd == 'object' && define.amd ) {
        define(function() {
            return populate;
        });
    }   else if ( typeof module !== 'undefined' && module.exports ) {
        module.exports = populate;
    } else {
        root.populate = populate;
    }

}(this));
(function() {
    "use strict";

    function App() {
        this.events = {};

        this.environment = {
            debug: true,
            isMobile: function() {
                return (document.body.clientWidth <= 1400) ? true : false;
            },

        }

    }

    App.components = {};

    App.prototype.trigger = function(name, data) {
        var app = this;
        var execute = function() {
            var handlers = app.events[name];
            if (!!handlers === false) return;
            handlers.forEach(function(handler) {
                handler.call(this, data);
            });
        }
        return typeof Promise === 'undefined' ? execute() : new Promise(function(resolve, reject) {
            execute();
            resolve();
        });
    };
    App.prototype.on = function(name, handler) {
        var handlers = this.events[name];
        if (!!handlers === false) {
            handlers = this.events[name] = [];
        }
        handlers.push(handler);
    };
    App.prototype.off = function(name, handler) {
        var handlers = events[name];
        if (!!handlers === false) return;
        var handlerIdx = handlers.indexOf(handler);
        handlers.splice(handlerIdx);
    };




    App.components.sortableList = function(element, app) {

        function monthDate(param) {
          let dateValue  = Date.parse(param)/1000;
          return dateValue;
        }

        var getSortableItemKeys = function(){
            var items = [];
            [].forEach.call(element.querySelectorAll(".list tr:first-child td[class]"), function(item){
                var sortItem = item.className;
                if(item.hasAttribute("data-type") && item.getAttribute("data-type") === "date"){
                    item.setAttribute('data-timestamp', monthDate(item.innerText));
                    sortItem = {'name':sortItem, 'attr':'data-timestamp'};
                }
                items.push(sortItem);
            });
            return items;
        }

        var options = {
            valueNames: getSortableItemKeys()
        };

        var list = new List(element.id, options);

        var searchInput = document.querySelector("#list-search");

        searchInput && searchInput.addEventListener("keyup", function(e){
            list.search(e.target.value);
        });

        list.listContainer.addEventListener("click", function(e){
            if(e.target.classList.contains("sort")){
                var current = list.listContainer.querySelector(".sort-active:not([data-sort="+e.target.getAttribute("data-sort")+"])");
                current && current.classList.remove("sort-active");
                e.target.classList.toggle("sort-active");
            }
        });


        [].forEach.call(element.querySelectorAll("[data-due-to]"), function(dateField){
            var dueTo = Date.parse(dateField.innerText) + (14 * 24 * 60 * 60 * 60);
            var now = Date.now(); 
            if(now > dueTo){
                dateField.innerHTML = '<span class="due-to-date"> ' + dateField.innerText + '</span>';
            }
        });

    };


    App.components.addFormField = function(element, app) {
        var i = 7;


        element.addEventListener("click", function(e){
            e.preventDefault();

            var tpl = element.parentNode.parentNode.querySelector(".field-tpl");

            var newItem = tpl.cloneNode(true);

            [].forEach.call(newItem.querySelectorAll("input"), function(input){
                input.name = input.name.replace("[6]", "[" + i + "]");
                input.value = "";
            });

            element.parentNode.parentNode.insertBefore(newItem, element.parentNode);
            i++;
        });
    };

    App.components.selectTruck = function(element, app) {

        var onload = function(response){
            element.parentNode.classList.remove("field__loading");
            try {
                var trucks = JSON.parse(response);
                for (var truck in trucks){
                    var option = document.createElement("option");
                    option.value = truck;
                    option.innerText = truck + " ("+trucks[truck]['Make']+" "+trucks[truck]['Plate']+")";
                    element.appendChild(option);
                }
            } catch(e) {
                return;
            }
        }

        var sendXhr = function(url, handler){
            var xmlhttp = new XMLHttpRequest();
            var url = url;

            xmlhttp.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                handler(this.responseText);
                }
            };

            xmlhttp.open("GET", url, true);
            xmlhttp.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
            xmlhttp.send();
        }

        sendXhr("/dashboard/trucks/", onload);

        var tripsSelect = document.querySelector("#trip-select");

        element.addEventListener("change", function(e){
            tripsSelect.parentNode.classList.add("field__loading");
            tripsSelect.options.length = 1;
            tripsSelect.options[0].innerText = "Select Trip";
            tripsSelect.selectedIndex = 0;
            var truckId = element.value;
            sendXhr("/dashboard/trucks/" + truckId + "/", function(response){
                tripsSelect.parentNode.classList.remove("field__loading");
                try {
                    var trips = JSON.parse(response);
                    if(trips.length){
                        for (var trip in trips){
                        if (trips[trip] == null) continue;
                        var option = document.createElement("option");
                        option.value = trip;
                        option.innerText = trip + " ("+trips[trip]['Date']+", "+trips[trip]['From']+" to "+trips[trip]['To']+")";
                        tripsSelect.appendChild(option);
                        }
                    }else{
                        tripsSelect.options[0].innerText = "Truck has no trips";
                    }
                    
                } catch(e) {
                    return;
                }
            });
        });
    };

    App.components.confirmBtn = function(element, app) {
        element.addEventListener("click", function(e){
            if(!confirm(element.getAttribute("data-message"))) {
            e.preventDefault();
            }
        });
    };

    App.components.form = function(element, app) {

        element.classList.contains("edit-form") && [].forEach.call(element.querySelectorAll("[name]"), function(input){
            var el = document.createElement("div");
            el.classList.add("form__row-title");
            el.innerText = input.getAttribute("placeholder");
            input.parentNode.parentNode.insertBefore(el, input.parentNode);
        });

        populate(element, postData);
    };

    App.components.datepicker = function(element, app) {

        function addZ(n){
            return n<10? '0'+n:''+n;
        }
        function parseDate(dateString){
                const parts = dateString.split('/');
                const month = parseInt(parts[0], 10) - 1;
                const day = parseInt(parts[1], 10);
                const year = parseInt(parts[2], 10);
                return new Date(year, month, day);
        }

        var picker = new Pikaday({
            field: element,
            format: 'MM/DD/YYYY',
            toString: function(date, format) {
                const day = addZ(date.getDate());
                const month = addZ(date.getMonth() + 1);
                const year = date.getFullYear();
                return month + '/' + day + '/' + year;
            },
            parse: function(dateString, format) {
                return parseDate(dateString);
            }
        });
   

    };


    App.components.dashboardNav = function(element, app) {

        var stateHandler = function() {
            if (document.body.clientWidth < 1400) {
                element.classList.add("dashboard__nav--compact");
            } else {
                element.classList.remove("dashboard__nav--compact");
            }
        };

        app.on("window:resize", function() {
            stateHandler();
        });

        stateHandler();
    };


    App.components.body = function(element, app) {

        element.classList.remove("no-js");

        var stateHandler = function() {
            if (app.environment.isMobile()) {
                element.classList.remove("desktop");
                element.classList.add("mobile");
            } else {
                element.classList.remove("mobile");
                element.classList.add("desktop");
            }
        };

        app.on("window:resize", function() {
            stateHandler();
        });

        stateHandler();
    };

    App.prototype.init = function(context) {

        var elements = context.querySelectorAll("[data-js]");


        [].forEach.call(elements, function(element) {
            var c = element.getAttribute('data-js');
            c = c.replace(/-([a-z])/g, function(g) { return g[1].toUpperCase(); });
            if (App.components[c]) {
                App.components[c](element, this);
            } else {
                console.log('module not registered!');
            }
        }.bind(this));

        window.addEventListener('resize', function() {
            this.trigger('window:resize');
        }.bind(this));

        window.addEventListener('scroll', function() {
            this.trigger('window:scroll');
        }.bind(this));

        let timeout;

        var sendData = function(oForm){

            document.getElementById("ajax_loading").classList.remove("hidden");
            document.getElementById("ajax_total").classList.add("hidden");

            const formInputs = oForm.getElementsByTagName("input");
            let formData = new FormData();
            for (let input of formInputs) {
                formData.append(input.name, input.value);
            }

            fetch(oForm.action + "?total_only",
                {
                    method: oForm.method,
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    document.getElementById("ajax_total").innerText = "$" + data;
                    document.getElementById("ajax_total").classList.remove("hidden");
                    document.getElementById("ajax_loading").classList.add("hidden");
                })
                .catch(error => console.log(error.message))
                .finally(() => console.log("Done"));
        }


        var btns = document.querySelectorAll("button.btn");


        [].forEach.call(btns, function(btn){

            btn.addEventListener("click", function(e){
                btn.innerText = "Please wait...";
                setTimeout(function(){
                    btn.disabled = true;
                },200);
                
            });

        });

        

        var calcDiv = document.getElementById("calc_form");

        if(calcDiv){

            var oForm = document.getElementById("fform");

        calcDiv.addEventListener("input", function(e){


            if(typeof timeout != 'undefined'){ 
               clearTimeout(timeout);
           }

            timeout = setTimeout(function() {

                    sendData(oForm);

              },
              500);

        
        });

        sendData(oForm);


        }


 
    }

    window.App = App;
}());